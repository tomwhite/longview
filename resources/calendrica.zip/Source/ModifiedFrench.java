package calendrica;


public class ModifiedFrench extends StandardDate {

	//
	// constructors
	//

	public ModifiedFrench() { }
	
	public ModifiedFrench(int date) {
		super(date);
	}
	
	public ModifiedFrench(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public ModifiedFrench(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-modified-french (f-date)
		  ;; TYPE french-date -> fixed-date
		  ;; Fixed date of French Revolutionary date.
		  (let* ((month (first f-date))
		         (day (second f-date))
		         (year (third f-date)))
		    (+ french-epoch -1; Days before start of calendar.
		       ( * 365 (1- year)); Ordinary days in prior years.
		       ; Leap days in prior years.
		       (quotient (1- year) 4)
		       (- (quotient (1- year) 100))
		       (quotient (1- year) 400)
		       (- (quotient (1- year) 4000))
		       ( * 30 (1- month)); Days in prior months this year.
		       day))); Days this month.
		-*/
	public static int toFixed(int month, int day, int year) {
		return French.EPOCH - 1 +
			365 * (year - 1) +
			quotient(year - 1, 4) -
			quotient(year - 1, 100) +
			quotient(year - 1, 400) -
			quotient(year - 1, 4000) +
			30 * (month - 1) +
			day;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun modified-french-from-fixed (date)
		  ;; TYPE fixed-date -> french-year
		  ;; French Revolutionary date (month day year) of fixed
		  ;; date.
		  (let* ((approx   ; Approximate year (may be off by 1).
		          (quotient (- date french-epoch) 1460969/4000))
		         (year     ; Search forward.
		          (+ approx -1 ; Lower bound
		             (sum 1 y approx
		                  (>= date
		                      (fixed-from-modified-french
		                       (french-date 1 1 y))))))
		         (month    ; Calculate the month by division.
		          (1+ (quotient
		               (- date (fixed-from-modified-french
		                         (french-date 1 1 year)))
		               30)))
		         (day      ; Calculate the day by subtraction.
		          (1+ (- date
		                 (fixed-from-modified-french
		                  (french-date month 1 year))))))
		    (french-date month day year)))
		-*/
	public void fromFixed(int date) {
		int approx = quotient(date - French.EPOCH, 1460969d/4000);
		year = approx - 1;
		for(int i = approx; date >= toFixed(1, 1, i); i++)
			year++;

		month = quotient(date - toFixed(1, 1, year), 30) + 1;
		day = date - toFixed(month, 1, year) + 1;
	}
	
	//
	// support methods
	//

		/*-
		(defun modified-french-leap-year? (f-year)
		  ;; TYPE french-year -> boolean
		  ;; True if f-year is a leap year on the French Revolutionary
		  ;; calendar.
		  (and (= (mod f-year 4) 0)
		       (not (member (mod f-year 400) (list 100 200 300)))
		       (not (= (mod f-year 4000) 0))))
		-*/
	public static boolean isLeapYear(int fYear) {
		boolean result = false;
		
		if(mod(fYear, 4) == 0) {
			int m400 = mod(fYear, 400);
			if(m400 != 100 && m400 != 200 && m400 != 300) {
				if(!(mod(fYear, 4000) == 0))
					result = true;
			}
		}
		
		return result;
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof ModifiedFrench))
			return false;
		
		return internalEquals(obj);
	}
}
