package calendrica;


public class Bahai extends Date {
	
	//
	// fields
	//

	public int major;
	public int cycle;
	public int year;
	public int month;
	public int day;

	//
	// constructors
	//

	public Bahai() { }
	
	public Bahai(int date) {
		super(date);
	}
	
	public Bahai(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Bahai(int major, int cycle, int year, int month, int day) {
		this.major = major;
		this.cycle = cycle;
		this.year = year;
		this.month = month;
		this.day = day;
	}
	
	//
	// constants
	//

		/*-
		(defconstant bahai-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of Bahai calendar.
		  (fixed-from-gregorian (gregorian-date march 21 1844)))
		-*/
	public static final int EPOCH = Gregorian.toFixed(MARCH, 21, 1844);
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-bahai (b-date)
		  ;; TYPE bahai-date -> fixed-date
		  ;; Fixed date equivalent to the Bahai date b-date.
		  (let* ((major (bahai-major b-date))
		         (cycle (bahai-cycle b-date))
		         (year (bahai-year b-date))
		         (month (bahai-month b-date))
		         (day (bahai-day b-date))
		         (g-year; Corresponding Gregorian year.
		          (+ ( * 361 (1- major))
		             ( * 19 (1- cycle)) year -1
		             (gregorian-year-from-fixed bahai-epoch))))
		    (+ (fixed-from-gregorian ; Prior years.
		        (gregorian-date march 20 g-year))
		       ( * 19 (1- month))        ; Elapsed months.
		       ;; Subtract 14 or 15 if counted ayyam-i-ha.
		       (if (/= month 20)
		           0
		         (if (gregorian-leap-year? (1+ g-year))
		             -14
		           -15))
		       day)))                   ; Days in current month.
		-*/
	public static int toFixed(int major, int cycle, int year, int month, int day) {
		int gYear = 361 * (major - 1)
			+ 19 * (cycle - 1)
			+ year
			- 1
			+ Gregorian.yearFromFixed(EPOCH);
		return Gregorian.toFixed(MARCH, 20, gYear)
			+ 19 * (month - 1)
			+ (month != 20 ? 0 :
				(Gregorian.isLeapYear(gYear + 1) ? -14 : -15))
			+ day;
	}

	public int toFixed() {
		return toFixed(major, cycle, year, month, day);
	}
	
		/*-
		(defun bahai-from-fixed (date)
		  ;; TYPE fixed-date -> bahai-date
		  ;; Bahai (month day cycle year) corresponding to fixed
		  ;; date.
		  (let* ((g-year (gregorian-year-from-fixed date))
		         (start   ; 1844
		          (gregorian-year-from-fixed bahai-epoch))
		         (years ; Since start of Bahai calendar.
		          (- g-year start
		             (if (<= (fixed-from-gregorian
		                      (gregorian-date january 1 g-year))
		                     date
		                     (fixed-from-gregorian
		                      (gregorian-date march 20 g-year)))
		                 1 0)))
		         (major (1+ (quotient years 361)))
		         (cycle (1+ (quotient (mod years 361) 19)))
		         (year (1+ (mod years 19)))
		         (days; Since start of year
		          (- date (fixed-from-bahai
		                   (bahai-date major cycle year 1 1))))
		         (month (if (>= date
		                        (fixed-from-bahai
		                         (bahai-date major cycle year 20 1)))
		                    20
		                  (1+ (quotient days 19))))
		         (day (- date -1
		                 (fixed-from-bahai
		                  (bahai-date major cycle year month 1)))))
		    (bahai-date major cycle year month day)))
		-*/
	public void fromFixed(int date) {
		int gYear = Gregorian.yearFromFixed(date);
		int start = Gregorian.yearFromFixed(EPOCH);
		int years = gYear
			- start
			- (Gregorian.toFixed(JANUARY, 1, gYear) <= date && date <= Gregorian.toFixed(MARCH, 20, gYear) ? 1 : 0);
		major = 1 + quotient(years, 361);
		cycle = 1 + quotient(mod(years, 361), 19);
		year = 1 + mod(years, 19);
		int days = date - toFixed(major, cycle, year, 1, 1);
		month = date >= toFixed(major, cycle, year, 20, 1) ? 20 : 1 + quotient(days, 19);
		day = date + 1 - toFixed(major, cycle, year, month, 1);
	}
	
	public void fromArray(int[] a) {
		this.major	= a[0];
		this.cycle	= a[1];
		this.year	= a[2];
		this.month	= a[3];
		this.day	= a[4];
	}
	
	//
	// auxiliary methods
	//
	
		/*-
		(defun bahai-new-year (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Bahai New Year in Gregorian year.
		  (fixed-from-gregorian
		   (gregorian-date march 21 g-year)))
		-*/
	public static int newYear(int gYear) {
		return Gregorian.toFixed(MARCH, 21, gYear);
	}

		/*-
		(defun feast-of-ridvan (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Bahai New Year in Gregorian year.
		  (let* ((years (- g-year
		                   (gregorian-year-from-fixed
		                    bahai-epoch)))
		         (major (1+ (quotient years 361)))
		         (cycle (1+ (quotient (mod years 361) 19)))
		         (year (1+ (mod years 19))))
		    (fixed-from-bahai
		     (bahai-date major cycle year 2 13))))
		-*/
	public static int feastOfRidvan(int gYear) {
		int years = gYear - Gregorian.yearFromFixed(EPOCH);
		int major = 1 + quotient(years, 361);
		int cycle = 1 + quotient(mod(years, 361), 19);
		int year = 1 + mod(years, 19);
		return toFixed(major, cycle, year, 2, 13);
	}
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "major=" + major + ",cycle=" + cycle +
			",year=" + year + ",month=" + month + ",day=" + day;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof Bahai))
			return false;
		
		Bahai o = (Bahai)obj;
		
		return
			o.major	== major	&&
			o.cycle	== cycle	&&
			o.year	== year		&&
			o.month	== month	&&
			o.day	== day		;
	}
}
