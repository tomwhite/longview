package calendrica;

import java.io.Serializable;


public abstract class ProtoDate implements Cloneable, Serializable {
	
	//
	// constants
	//

		/*-	
		(defconstant january
		  ;; TYPE standard-month
		  ;; January on Julian/Gregorian calendar.
		  1)

		(defconstant february
		  ;; TYPE standard-month
		  ;; February on Julian/Gregorian calendar.
		  (1+ january))

		(defconstant march
		  ;; TYPE standard-month
		  ;; March on Julian/Gregorian calendar.
		  (+ january 2))

		(defconstant april
		  ;; TYPE standard-month
		  ;; April on Julian/Gregorian calendar.
		  (+ january 3))

		(defconstant may
		  ;; TYPE standard-month
		  ;; May on Julian/Gregorian calendar.
		  (+ january 4))

		(defconstant june
		  ;; TYPE standard-month
		  ;; June on Julian/Gregorian calendar.
		  (+ january 5))

		(defconstant july
		  ;; TYPE standard-month
		  ;; July on Julian/Gregorian calendar.
		  (+ january 6))

		(defconstant august
		  ;; TYPE standard-month
		  ;; August on Julian/Gregorian calendar.
		  (+ january 7))

		(defconstant september
		  ;; TYPE standard-month
		  ;; September on Julian/Gregorian calendar.
		  (+ january 8))

		(defconstant october
		  ;; TYPE standard-month
		  ;; October on Julian/Gregorian calendar.
		  (+ january 9))

		(defconstant november
		  ;; TYPE standard-month
		  ;; November on Julian/Gregorian calendar.
		  (+ january 10))

		(defconstant december
		  ;; TYPE standard-month
		  ;; December on Julian/Gregorian calendar.
		  (+ january 11))
		-*/
	public static final int JANUARY		= 1;
	public static final int FEBRUARY	= JANUARY + 1;
	public static final int MARCH		= JANUARY + 2;
	public static final int APRIL		= JANUARY + 3;
	public static final int MAY			= JANUARY + 4;
	public static final int JUNE		= JANUARY + 5;
	public static final int JULY		= JANUARY + 6;
	public static final int AUGUST		= JANUARY + 7;
	public static final int SEPTEMBER	= JANUARY + 8;
	public static final int OCTOBER		= JANUARY + 9;
	public static final int NOVEMBER	= JANUARY + 10;
	public static final int DECEMBER	= JANUARY + 11;

		/*-	
		(defconstant sunday
		  ;; TYPE day-of-week
		  ;; Residue class for Sunday.
		  0)

		(defconstant monday
		  ;; TYPE day-of-week
		  ;; Residue class for Monday.
		  (1+ sunday))

		(defconstant tuesday
		  ;; TYPE day-of-week
		  ;; Residue class for Tuesday.
		  (+ sunday 2))

		(defconstant wednesday
		  ;; TYPE day-of-week
		  ;; Residue class for Wednesday.
		  (+ sunday 3))

		(defconstant thursday
		  ;; TYPE day-of-week
		  ;; Residue class for Thursday.
		  (+ sunday 4))

		(defconstant friday
		  ;; TYPE day-of-week
		  ;; Residue class for Friday.
		  (+ sunday 5))

		(defconstant saturday
		  ;; TYPE day-of-week
		  ;; Residue class for Saturday.
		  (+ sunday 6))
		-*/
	public static final int SUNDAY		= 0;
	public static final int MONDAY		= SUNDAY + 1;
	public static final int TUESDAY		= SUNDAY + 2;
	public static final int WEDNESDAY	= SUNDAY + 3;
	public static final int THURSDAY	= SUNDAY + 4;
	public static final int FRIDAY		= SUNDAY + 5;
	public static final int SATURDAY	= SUNDAY + 6;

		/*-	
		(defconstant first
		  ;; TYPE integer
		  ;; Index for selecting a k-day.
		  1)

		(defconstant last
		  ;; TYPE integer
		  ;; Index for selecting a k-day.
		  -1)
		-*/
	public static final int FIRST = 1;
	public static final int LAST = -1;

		/*-
		(defconstant jd-start
		  ;; TYPE moment
		  ;; Fixed time of start of the julian day number.
		  -1721424.5)
		-*/
	public static final double JD_START = -1721424.5;

		/*-
		(defconstant j2000
		  ;; TYPE julian-day-number
		  ;; Julian day number (2451545) of Gregorian year 2000.
		  (jd-from-moment
		   (+ 0.5d0 (fixed-from-gregorian
		             (gregorian-date january 1 2000)))))
		-*/
	public static final double J2000 = jdFromMoment(0.5 + Gregorian.toFixed(JANUARY, 1, 2000));

		/*-
		(defconstant mean-tropical-year
		  ;; TYPE real
		  365.242199d0)
		-*/
	public static final double MEAN_TROPICAL_YEAR = 365.242199;

		/*-
		(defconstant mean-synodic-month
		  ;; TYPE real
		  29.530588853d0)
		-*/
	public static final double MEAN_SYNODIC_MONTH = 29.530588853;

		/*-
		(defconstant new
		  ;; TYPE phase
		  ;; Excess of lunar longitude over solar longitude at new
		  ;; moon.
		  0)
		-*/
	public static final double NEW = 0;

		/*-
		(defconstant first-quarter
		  ;; TYPE phase
		  ;; Excess of lunar longitude over solar longitude at first
		  ;; quarter moon.
		  90)
		-*/
	public static final double FIRST_QUARTER = 90;

		/*-
		(defconstant full
		  ;; TYPE phase
		  ;; Excess of lunar longitude over solar longitude at full
		  ;; moon.
		  180)
		-*/
	public static final double FULL = 180;

		/*-
		(defconstant last-quarter
		  ;; TYPE phase
		  ;; Excess of lunar longitude over solar longitude at last
		  ;; quarter moon.
		  270)
		-*/
	public static final double LAST_QUARTER = 270;

	//
	// constructors
	//
	
	public ProtoDate() { }
	
	public ProtoDate(int date) {
		fromFixed(date);
	}
	
	public ProtoDate(Date date)
		throws BogusDateException
	{
		fromDate(date);
	}

	//	
	// date conversion methods
	//

	public abstract void fromFixed(int date);
	
	public void fromDate(Date fromDate)
		throws BogusDateException
	{
		convert(fromDate, this);
	}

	public abstract void fromArray(int[] a);
	
	public static void convert(Date fromDate, ProtoDate toDate)
		throws BogusDateException
	{
		toDate.fromFixed(fromDate.toFixed());
	}
	
	//
	// support methods
	//

		/*-
		(defun gregorian-date-difference (g-date1 g-date2)
		  ;; TYPE (gregorian-date gregorian-date) -> integer
		  ;; Number of days from Gregorian date g-date1 until g-date2.
		  (- (fixed-from-gregorian g-date2)
		     (fixed-from-gregorian g-date1)))
		-*/
	public static int difference(Date date1, Date date2)
		throws BogusDateException
	{
		return date2.toFixed() - date1.toFixed();
	}
	
	public static int difference(int date1, Date date2)
		throws BogusDateException
	{
		return date2.toFixed() - date1;
	}
	
	public static int difference(Date date1, int date2)
		throws BogusDateException
	{
		return date2 - date1.toFixed();
	}
	
	public static int difference(int date1, int date2) {
		return date2 - date1;
	}

	public static double mod(double x, double y) {
		return x - y * Math.floor(x / y);
	}

	public static int mod(int x, int y) {
		return (int)(x - y * Math.floor((double)x / y));
	}

		/*-
		(defun quotient (m n)
		  ;; TYPE (real non-zero-real) -> integer
		  ;; Whole part of m/n.
		  (floor m n))
		-*/
	public static int quotient(double x, double y) {
		return (int)Math.floor(x / y);
	}

		/*-
		(defun adjusted-mod (m n)
		  ;; TYPE (integer positive-integer) -> positive-integer
		  ;; Positive remainder of m/n with n instead of 0.
		  (1+ (mod (1- m) n)))
		-*/
	public static int adjustedMod(int m, int n) {
		return mod(m - 1, n) + 1;
	}

		/*-
		(defun day-of-week-from-fixed (date)
		  ;; TYPE fixed-date -> day-of-week
		  ;; The residue class of the day of the week of date.
		  (mod date 7))
		-*/
	public static int dayOfWeekFromFixed(int date) {
		return mod(date, 7);
	}

		/*-
		(defun kday-on-or-before (date k)
		  ;; TYPE (fixed-date weekday) -> fixed-date
		  ;; Fixed date of the k-day on or before fixed date.
		  ;; k=0 means Sunday, k=1 means Monday, and so on.
		  (- date (day-of-week-from-fixed (- date k))))
		-*/
	public static int kDayOnOrBefore(int date, int k) {
		return date - dayOfWeekFromFixed(date - k);
	}

		/*-
		(defun kday-on-or-after (date k)
		  ;; TYPE (fixed-date weekday) -> fixed-date
		  ;; Fixed date of the k-day on or after fixed date.
		  ;; k=0 means Sunday, k=1 means Monday, and so on.
		  (kday-on-or-before (+ date 6) k))
		-*/
	public static int kDayOnOrAfter(int date, int k) {
		return kDayOnOrBefore(date + 6, k);
	}

		/*-
		(defun kday-nearest (date k)
		  ;; TYPE (fixed-date weekday) -> fixed-date
		  ;; Fixed date of the k-day nearest fixed date.  k=0
		  ;; means Sunday, k=1 means Monday, and so on.
		  (kday-on-or-before (+ date 3) k))
		-*/
	public static int kDayNearest(int date, int k) {
		return kDayOnOrBefore(date + 3, k);
	}

		/*-
		(defun kday-after (date k)
		  ;; TYPE (fixed-date weekday) -> fixed-date
		  ;; Fixed date of the k-day after fixed date.  k=0
		  ;; means Sunday, k=1 means Monday, and so on.
		  (kday-on-or-before (+ date 7) k))
		-*/
	public static int kDayAfter(int date, int k) {
		return kDayOnOrBefore(date + 7, k);
	}

		/*-
		(defun kday-before (date k)
		  ;; TYPE (fixed-date weekday) -> fixed-date
		  ;; Fixed date of the k-day before fixed date.  k=0
		  ;; means Sunday, k=1 means Monday, and so on.
		  (kday-on-or-before (1- date) k))
		-*/
	public static int kDayBefore(int date, int k) {
		return kDayOnOrBefore(date - 1, k);
	}

		/*-
		(defun nth-kday (n k date)
		  ;; TYPE (integer weekday gregorian-date) -> fixed-date
		  ;; Fixed date of n-th k-day after Gregorian date.  If
		  ;; n>0, return the n-th k-day on or after date.
		  ;; If n<0, return the n-th k-day on or before date.
		  ;; A k-day of 0 means Sunday, 1 means Monday, and so on.
		  (if (> n 0)
		      (+ ( * 7 n)
		         (kday-before (fixed-from-gregorian date) k))
		    (+ ( * 7 n)
		       (kday-after (fixed-from-gregorian date) k))))
		-*/
	public static int nthKDay(int n, int k, int date) {
		return n > 0 ?
			kDayBefore(date, k) + 7 * n :
			kDayAfter(date, k) + 7 * n;
	}

	public static int signum(double x) {
		if(x < 0)
			return -1;
		else if(x > 0)
			return 1;
		else
			return 0;
	}
	
	public static double square(double x) {
		return x * x;
	}

		/*-
		(defun poly (x a)
		  ;; TYPE (real list-of-reals) -> real
		  ;; Sum powers of x with coefficients (from order 0 up)
		  ;; in list a.
		  (if (equal a nil)
		      0
		    (+ (first a) ( * x (poly x (cdr a))))))
		-*/
	public static double poly(double x, double[] a) {
		double result = a[0];
		for(int i = 1; i < a.length; i++) {
			result += a[i] * Math.pow(x, i);
		}
		return result;
	}
	
		/*-
		(defun local-from-universal (u-time zone)
		  ;; TYPE (moment real-minute) -> moment
		  ;; Local time from u-time in universal time at time-zone
		  ;; zone.
		  (+ u-time (/ zone 24d0 60d0)))
		-*/
	public static double localFromUniversal(double uTime, double zone) {
		return uTime + zone / (24d * 60);
	}
	
		/*-
		(defun universal-from-local (l-time zone)
		  ;; TYPE (moment real-minute) -> moment
		  ;; Universal time from l-time in local time at time-zone
		  ;; zone.
		  (- l-time (/ zone 24d0 60d0)))
		-*/
	public static double universalFromLocal(double lTime, double zone) {
		return lTime - zone / (24d * 60);
	}
	
		/*-
		(defun location-offset (longitude zone)
		  ;; TYPE (angle real-minute) -> minute
		  ;; Offset of location at longitude
		  ;; from standard time at zone.
		  (- ( * 4 longitude) zone))
		-*/
	public static int locationOffset(double longitude, double zone) {
		return (int)(4 * longitude - zone);
	}
	
		/*-
		(defun local-from-standard (s-time offset)
		  ;; TYPE (moment real-minute) -> moment
		  ;; Local time from standard s-time at distance
		  ;; offset (in minutes) from time zone.
		  (+ s-time (/ offset 24d0 60d0)))
		-*/
	public static double localFromStandard(double sTime, double offset) {
		return sTime + offset / (24d * 60);
	}

		/*-
		(defun standard-from-local (l-time offset)
		  ;; TYPE (moment real-minute) -> moment
		  ;; Standard time from local l-time at distance
		  ;; offset (in minutes) from time zone.
		  (- l-time (/ offset 24d0 60d0)))
		-*/
	public static double standardFromLocal(double lTime, double offset) {
		return lTime - offset / (24d * 60);
	}

		/*-
		(defun moment-from-jd (jd)
		  ;; TYPE julian-day-number -> moment
		  ;; Fixed time of astronomical (julian) day number jd.
		  (+ jd jd-start))
		-*/
	public static double momentFromJD(double jd) {
		return jd + JD_START;
	}

		/*-
		(defun jd-from-moment (moment)
		  ;; TYPE moment -> julian-day-number
		  ;; Astronomical (julian) day number of fixed moment moment.
		  (- moment jd-start))
		-*/

	public static double jdFromMoment(double moment) {
		return moment - JD_START;
	}
	
		/*-
		(defun fixed-from-jd (jd)
		  ;; TYPE julian-day-number -> fixed-date
		  ;; Fixed date of astronomical (julian) day number jd.
		  (floor (moment-from-jd jd)))
		-*/
	public static int fixedFromJD(double jd) {
		return (int)Math.floor(momentFromJD(jd));
	}
	
	public static double jdFromFixed(int date) {
		return jdFromMoment(date);
	}

		/*-
		(defun degrees (theta)
		  ;; TYPE real -> angle
		  ;; Normalize angle theta to range 0-360 degrees.
		  (mod theta 360))
		-*/
	public static double degrees(double theta) {
		return mod(theta, 360);
	}

		/*-
		(defun radians-to-degrees (theta)
		  ;; TYPE radian -> angle
		  ;; Convert angle theta from radians to degrees.
		  (degrees (/ theta pi 1/180)))
		-*/
	public static double radiansToDegrees(double theta) {
		return degrees(theta / Math.PI * 180);
	}

		/*-
		(defun degrees-to-radians (theta)
		  ;; TYPE real -> radian
		  ;; Convert angle theta from degrees to radians.
		  ( * (degrees theta) pi 1/180))
		-*/
	public static double degreesToRadians(double theta) {
		return degrees(theta) * Math.PI / 180;
	}

		/*-
		(defun sin-degrees (theta)
		  ;; TYPE angle -> amplitude
		  ;; Sine of theta (given in degrees).
		  (sin (degrees-to-radians theta)))
		-*/
	public static double sinDegrees(double theta) {
		return Math.sin(degreesToRadians(theta));
	}

		/*-
		(defun cosine-degrees (theta)
		  ;; TYPE angle -> amplitude
		  ;; Cosine of theta (given in degrees).
		  (cos (degrees-to-radians theta)))
		-*/
	public static double cosDegrees(double theta) {
		return Math.cos(degreesToRadians(theta));
	}

		/*-
		(defun tangent-degrees (theta)
		  ;; TYPE angle -> real
		  ;; Tangent of theta (given in degrees).
		  (tan (degrees-to-radians theta)))
		-*/
	public static double tanDegrees(double theta) {
		return Math.tan(degreesToRadians(theta));
	}

		/*-
		(defun arctan-degrees (x quad)
		  ;; TYPE (real quadrant) -> angle
		  ;; Arctangent of x in degrees in quadrant quad.
		  (let* ((deg (radians-to-degrees (atan x))))
		    (if (or (= quad 1) (= quad 4))
		        deg
		      (+ deg 180))))
		-*/
	public static double arcTanDegrees(double x, int quad) {
		double deg = radiansToDegrees(Math.atan(x));
		return quad == 1 || quad == 4 ? deg : deg + 180;
	}

		/*-
		(defun arcsin-degrees (x)
		  ;; TYPE amplitude -> angle
		  ;; Arcsine of x in degrees.
		  (radians-to-degrees (asin x)))
		-*/
	public static double arcSinDegrees(double x) {
		return radiansToDegrees(Math.asin(x));
	}
	
		/*-
		(defun arccos-degrees (x)
		  ;; TYPE amplitude -> angle
		  ;; Arccosine of x in degrees.
		  (radians-to-degrees (acos x)))
		-*/
	public static double arcCosDegrees(double x) {
		return radiansToDegrees(Math.acos(x));
	}

		/*-
		(defun local-from-apparent (moment)
		  ;; TYPE moment -> moment
		  ;; Local time from sundial time.
		  (- moment (equation-of-time moment)))
		-*/
	public static double localFromApparent(double moment) {
		return moment - equationOfTime(moment);
	}

		/*-
		(defun apparent-from-local (moment)
		  ;; TYPE moment -> moment
		  ;; Sundial time at local time.
		  (+ moment (equation-of-time moment)))
		-*/
	public static double apparentFromLocal(double moment) {
		return moment + equationOfTime(moment);
	}

		/*-
		(defun solar-moment (date latitude longitude rise-or-set)
		  ;; TYPE (fixed-date angle angle real) -> moment
		  ;; Local time (fraction of day) of sunrise/sunset at
		  ;; latitude, longitude (in nonpolar regions) for fixed
		  ;; date.  rise-or-set is -0.25 for sunrise and +0.25 for
		  ;; sunset.
		  (let* ((approx  ; Approximate time of event.
		          (+ (day-number (gregorian-from-fixed date))
		             0.5 rise-or-set (/ longitude -360.0d0)))
		         (anomaly ; Anomaly of sun.
		          (- ( * 0.9856d0 approx) 3.289d0))
		         (sun     ; Longitude of sun.
		          (degrees (+ anomaly ( * 1.916d0
		                                 (sin-degrees anomaly))
		                      282.634d0
		                      ( * 0.020d0
		                         (sin-degrees ( * 2 anomaly))))))
		         (right-ascension ; Right ascension of sun.
		          (arctan-degrees
		           ( * (cosine-degrees 23.441884d0)
		              (tangent-degrees sun))
		           (1+ (quotient sun 90)))) ; Quadrant.
		         (declination ; Declination of sun.
		          (arcsin-degrees ( * (sin-degrees 23.441884d0)
		                             (sin-degrees sun))))
		         (local ( * (signum rise-or-set)
		                   (arccos-degrees
		                    (/ (- (cosine-degrees 90.833333d0)
		                          ( * (sin-degrees declination)
		                             (sin-degrees latitude)))
		                       (cosine-degrees declination)
		                       (cosine-degrees latitude))))))
		    (mod (- (/ (+ local right-ascension) 360)
		            0.27592d0 ( * 0.00273792d0 approx))
		         1)))
		-*/
	public static double solarMoment(int date, double latitude, double longitude, double riseOrSet) {
		double approx = new Gregorian(date).dayNumber() + 0.5 + riseOrSet + (longitude / -360.0);
		double anomaly = 0.9856 * approx - 3.289;
		double sun = degrees(anomaly +
			1.916 * sinDegrees(anomaly) + 
			282.634 +
			0.020 * sinDegrees(2 * anomaly));
		double rightAscension = arcTanDegrees(cosDegrees(23.441884) * tanDegrees(sun),
			1 + quotient(sun, 90));
		double declination = arcSinDegrees(sinDegrees(23.441884) * sinDegrees(sun));
		double local = signum(riseOrSet) * arcCosDegrees(
			(cosDegrees(90.833333) - sinDegrees(declination) * sinDegrees(latitude)) /
			cosDegrees(declination) /
			cosDegrees(latitude));
		return mod((local + rightAscension) / 360 - 0.27592 - 0.00273792 * approx, 1);
	}

		/*-
		(defun sunrise (date latitude longitude)
		  ;; TYPE (fixed-date angle angle) -> moment
		  ;; Local time (fraction of day) of sunrise at latitude,
		  ;; longitude (in nonpolar regions) for fixed date.
		  (solar-moment date latitude longitude -0.25d0))
		-*/
	public static double sunrise(int date, double latitude, double longitude) {
		return solarMoment(date, latitude, longitude, -0.25);
	}

		/*-
		(defun sunset (date latitude longitude)
		  ;; TYPE (fixed-date angle angle) -> moment
		  ;; Local time (fraction of day) of sunset at latitude,
		  ;; longitude (in nonpolar regions) for fixed date.
		  (solar-moment date latitude longitude 0.25d0))
		-*/
	public static double sunset(int date, double latitude, double longitude) {
		return solarMoment(date, latitude, longitude, 0.25);
	}

		/*-
		(defun universal-from-ephemeris (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Universal time from Ephemeris time.
		  (- jd (ephemeris-correction (moment-from-jd jd))))
		-*/
	public static double universalFromEphemeris(double jd) {
		return jd - ephemerisCorrection(momentFromJD(jd));
	}

		/*-
		(defun ephemeris-from-universal (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Ephemeris time at Universal time.
		  (+ jd (ephemeris-correction (moment-from-jd jd))))
		-*/
	public static double ephemerisFromUniversal(double jd) {
		return jd + ephemerisCorrection(momentFromJD(jd));
	}

		/*-
		(defun julian-centuries (moment)
		  ;; TYPE moment -> moment
		  ;; Julian centuries since j2000 at Universal time.
		  (/ (- (ephemeris-from-universal moment) j2000)
		     36525d0))
		-*/
	public static double julianCenturies(double moment) {
		return (ephemerisFromUniversal(moment) - J2000) / 36525;
	}

		/*-
		(defun ephemeris-correction (moment)
		  ;; TYPE moment -> fraction-of-day
		  ;; Ephemeris Time minus Universal Time (in days) for
		  ;; fixed time.  Adapted from "Astronomical Algorithms"
		  ;; by Jean Meeus, Willmann-Bell, Inc., 1991.
		  (let* ((year (gregorian-year-from-fixed moment))
		         (theta (/ (gregorian-date-difference
		                    (gregorian-date january 1 1900)
		                    (gregorian-date july 1 year))
		                   36525d0))
		         (coeff-19th
		          (list -0.00002d0 0.000297d0 0.025184d0
		                -0.181133d0 0.553040d0 -0.861938d0
		                0.677066d0 -0.212591d0))
		         (coeff-18th
		          (list -0.000009d0 0.003844d0 0.083563d0
		                0.865736d0 4.867575d0 15.845535d0
		                31.332267d0 38.291999d0 28.316289d0
		                11.636204d0 2.043794d0)))
		    (cond ((<= 1988 year 2019)
		           (/ (- year 1933) 24d0 60d0 60d0))
		          ((<= 1900 year 1987)
		           (poly theta coeff-19th))
		          ((<= 1800 year 1899)
		           (poly theta coeff-18th))
		          ((<= 1620 year 1799)
		           (/ (poly (- year 1600)
		                    (list 196.58333d0 -4.0675d0 0.0219167d0))
		              24d0 60d0 60d0))
		          (t (let* ((x (+ 0.5d0
		                          (gregorian-date-difference
		                           (gregorian-date january 1 1810)
		                           (gregorian-date january 1 year)))))
		               (/ (- (/ ( * x x) 41048480d0) 15)
		                  24d0 60d0 60d0))))))
		-*/
	public static double ephemerisCorrection(double moment) {
		int year = Gregorian.yearFromFixed((int)moment);
		double theta = difference(Gregorian.toFixed(JANUARY, 1, 1900), Gregorian.toFixed(JULY, 1, year)) / 36525d;
		double result;
		if(1988 <= year && year <= 2019) {
			result = (year - 1933) / (24d * 60 * 60);
		} else if (1900 <= year && year <= 1987) {
			result = poly(theta, ec.coeff19th);
		} else if (1800 <= year && year <= 1899) {
			result = poly(theta, ec.coeff18th);
		} else if (1620 <= year && year <= 1799) {
			result = poly(year - 1600, ec.coeff17th) / (24 * 60 * 60);
		} else {
			double x = 0.5 + difference(Gregorian.toFixed(JANUARY, 1, 1810), Gregorian.toFixed(JANUARY, 1, year));
			return (x * x / 41048480 - 15) / (24 * 60 * 60);
		}
		return result;
	}
	private static class ec {
		private static final double[] coeff19th = new double[] {-0.00002, 0.000297, 0.025184, -0.181133, 0.553040, -0.861938, 0.677066, -0.212591};
		private static final double[] coeff18th = new double[] {-0.000009, 0.003844, 0.083563, 0.865736, 4.867575, 15.845535, 31.332267, 38.291999, 28.316289, 11.636204, 2.043794};
		private static final double[] coeff17th = new double[] {196.58333, -4.0675, 0.0219167};
	}

		/*-
		(defun equation-of-time (jd)
		  ;; TYPE moment -> fraction-of-day
		  ;; Equation of time (in days) for julian day number jd.
		  ;; Adapted from "Astronomical Algorithms" by Jean Meeus,
		  ;; Willmann-Bell, Inc., 1991.
		  (let* ((c (/ (- jd j2000) 36525d0))
		         (longitude
		          (poly c
		                (list 280.46645d0 36000.76983d0 0.0003032d0)))
		         (anomaly
		          (poly c
		                (list 357.52910d0 35999.05030d0
		                      -0.0001559d0 -0.00000048d0)))
		         (inclination
		          (poly c
		                (list 23.43929111d0 -0.013004167d0
		                      -0.00000016389d0 0.0000005036d0)))
		         (eccentricity
		          (poly c
		                (list 0.016708617d0 -0.000042037d0
		                      -0.0000001236d0)))
		         (y (expt (tangent-degrees (/ inclination 2)) 2)))
		    (/ (+ ( * y (sin-degrees ( * 2 longitude)))
		          ( * -2 eccentricity (sin-degrees anomaly))
		          ( * 4 eccentricity y (sin-degrees anomaly)
		             (cosine-degrees ( * 2 longitude)))
		          ( * -0.5 y y (sin-degrees ( * 4 longitude)))
		          ( * -1.25 eccentricity eccentricity
		             (sin-degrees ( * 2 anomaly))))
		       2 pi)))
		-*/
	public static double equationOfTime(double jd) {
		double c = (jd - J2000) / 36525;
		double longitude = poly(c, et.coeffLongitude);
		double anomaly = poly(c, et.coeffAnomaly);
		double inclination = poly(c, et.coeffInclination);
		double eccentricity = poly(c, et.coeffEccentricity);
		double y = square(tanDegrees(inclination / 2));
		return (y * sinDegrees(2 * longitude) +
		-2 * eccentricity * sinDegrees(anomaly) +
		4 * eccentricity * y * sinDegrees(anomaly) * cosDegrees(2 * longitude) +
		-0.5 * y * y * sinDegrees(4 * longitude) +
		-1.25 * eccentricity * eccentricity * sinDegrees(2 * anomaly))
			/ (2 * Math.PI);
	}
	private static class et {
		private static final double[] coeffLongitude = new double[] {280.46645, 36000.76983, 0.0003032};
		private static final double[] coeffAnomaly = new double[] {357.52910, 35999.05030, -0.0001559, -0.00000048};
		private static final double[] coeffInclination = new double[] {23.43929111, -0.013004167, -0.00000016389, 0.0000005036};
		private static final double[] coeffEccentricity = new double[] {0.016708617, -0.000042037, -0.0000001236};
	}

		/*-
		(defun solar-longitude (jd)
		  ;; TYPE julian-day-number -> angle
		  ;; Longitude of sun on astronomical (julian) day number jd.
		  ;; Adapted from "Planetary Programs and Tables from -4000
		  ;; to +2800" by Pierre Bretagnon and Jean-Louis Simon,
		  ;; Willmann-Bell, Inc., 1986.
		  (let* ((c       ; Ephemeris time in Julian centuries
		          (julian-centuries jd))
		         (coefficients
		          (list 403406 195207 119433 112392 3891 2819 1721 0
		                660 350 334 314 268 242 234 158 132 129 114
		                99 93 86 78 72 68 64 46 38 37 32 29 28 27 27
		                25 24 21 21 20 18 17 14 13 13 13 12 10 10 10
		                10))
		         (multipliers
		          (list 0.01621043d0 628.30348067d0 628.30821524d0
		                628.29634302d0 1256.605691d0 1256.60984d0
		                628.324766d0 0.00813d0 1256.5931d0
		                575.3385d0 -0.33931d0 7771.37715d0
		                786.04191d0 0.05412d0 393.02098d0 -0.34861d0
		                1150.67698d0 157.74337d0 52.9667d0
		                588.4927d0 52.9611d0 -39.807d0 522.3769d0
		                550.7647d0 2.6108d0 157.7385d0 1884.9103d0
		                -77.5655d0 2.6489d0 1179.0627d0 550.7575d0
		                -79.6139d0 1884.8981d0 21.3219d0 1097.7103d0
		                548.6856d0 254.4393d0 -557.3143d0 606.9774d0
		                21.3279d0 1097.7163d0 -77.5282d0 1884.9191d0
		                2.0781d0 294.2463d0 -0.0799d0 469.4114d0
		                -0.6829d0 214.6325d0 1572.084d0))
		         (addends
		          (list 4.721964d0 5.937458d0 1.115589d0 5.781616d0
		                5.5474d0 1.512d0 4.1897d0 1.163d0 5.415d0
		                4.315d0 4.553d0 5.198d0 5.989d0 2.911d0
		                1.423d0 0.061d0 2.317d0 3.193d0 2.828d0
		                0.52d0 4.65d0 4.35d0 2.75d0 4.5d0 3.23d0
		                1.22d0 0.14d0 3.44d0 4.37d0 1.14d0 2.84d0
		                5.96d0 5.09d0 1.72d0 2.56d0 1.92d0 0.09d0
		                5.98d0 4.03d0 4.47d0 0.79d0 4.24d0 2.01d0
		                2.65d0 4.98d0 0.93d0 2.21d0 3.59d0 1.5d0
		                2.55d0))
		         (longitude
		          (+ 4.9353929d0
		             ( * 628.33196168d0 c)
		             ( * 0.0000001d0
		                (sigma ((x coefficients)
		                        (y addends)
		                        (z multipliers))
		                       ( * x (sin (+ y ( * z c)))))))))
		    (radians-to-degrees
		     (+ longitude (aberration c) (nutation c)))))
		-*/
	public static double solarLongitude(double jd) {
		double c = julianCenturies(jd);
		double sigma = 0;
		for(int i = 0; i < sl.coefficients.length; i++) {
			sigma += sl.coefficients[i] * Math.sin(sl.multipliers[i] * c + sl.addends[i]);
		}
		double longitude = 4.9353929 +
			628.33196168 * c +
			0.0000001 * sigma;
		return radiansToDegrees(longitude + aberration(c) + nutation(c));
	}
	private static class sl {
		private static final int[] coefficients = new int[] {
			403406, 195207, 119433, 112392, 3891, 2819, 1721, 0,
			660, 350, 334, 314, 268, 242, 234, 158, 132, 129, 114,
			99, 93, 86, 78, 72, 68, 64, 46, 38, 37, 32, 29, 28, 27, 27,
			25, 24, 21, 21, 20, 18, 17, 14, 13, 13, 13, 12, 10, 10, 10,
			10
		};
		private static final double[] multipliers = new double[] {
			0.01621043, 628.30348067, 628.30821524,
			628.29634302, 1256.605691, 1256.60984,
			628.324766, 0.00813, 1256.5931,
			575.3385, -0.33931, 7771.37715,
			786.04191, 0.05412, 393.02098, -0.34861,
			1150.67698, 157.74337, 52.9667,
			588.4927, 52.9611, -39.807, 522.3769,
			550.7647, 2.6108, 157.7385, 1884.9103,
			-77.5655, 2.6489, 1179.0627, 550.7575,
			-79.6139, 1884.8981, 21.3219, 1097.7103,
			548.6856, 254.4393, -557.3143, 606.9774,
			21.3279, 1097.7163, -77.5282, 1884.9191,
			2.0781, 294.2463, -0.0799, 469.4114,
			-0.6829, 214.6325, 1572.084
		};
		private static final double[] addends = new double[] {
			4.721964, 5.937458, 1.115589, 5.781616,
			5.5474, 1.512, 4.1897, 1.163, 5.415,
			4.315, 4.553, 5.198, 5.989, 2.911,
			1.423, 0.061, 2.317, 3.193, 2.828,
			0.52, 4.65, 4.35, 2.75, 4.5, 3.23,
			1.22, 0.14, 3.44, 4.37, 1.14, 2.84,
			5.96, 5.09, 1.72, 2.56, 1.92, 0.09,
			5.98, 4.03, 4.47, 0.79, 4.24, 2.01,
			2.65, 4.98, 0.93, 2.21, 3.59, 1.5,
			2.55
		};
	}

		/*-
		(defun nutation (c)
		  ;; TYPE julian-centuries -> radian
		  ;; Longitudinal nutation in radians at c Julian centuries.
		  (let* ((A (poly c (list 124.90d0 -1934.134d0 0.002063d0)))
		         (B (poly c (list 201.11d0 72001.5377d0 0.00057d0))))
		    (+ ( * -.0000834d0 (sin-degrees A))
		       ( * -.0000064d0 (sin-degrees B)))))
		-*/
	public static double nutation(double c) {
		double a = poly(c, nu.coeffa);
		double b = poly(c, nu.coeffb);
		return -0.0000834 * sinDegrees(a) +
		-0.0000064 * sinDegrees(b);
	}
	private static class nu {
		private static final double[] coeffa = new double[] {124.90, -1934.134, 0.002063};
		private static final double[] coeffb = new double[] {201.11, 72001.5377, 0.00057};
	}

		/*-
		(defun aberration (c)
		  ;; TYPE julian-centuries -> radian
		  ;; Aberration in radians at c Julian centuries.
		  (- ( * 0.0000017d0 (cosine-degrees 
		                     (+ 177.63d0 ( * 35999.01848d0 c))))
		     0.0000973d0))
		-*/
	public static double aberration(double c) {
		return 0.0000017 * cosDegrees(177.63 + 35999.01848 * c) - 0.0000973;
	}

		/*-
		(defun date-next-solar-longitude (jd l)
		  ;; TYPE (julian-day-number angle) -> julian-day-number
		  ;; Julian day number of the first date at or after julian
		  ;; day number jd (in Greenwich) when the solar longitude
		  ;; will be a multiple of l degrees; l must be a proper
		  ;; divisor of 360.
		  (let* ((next (double-float
		                (degrees
		                 ( * l (ceiling (/ (solar-longitude jd)
		                                  l)))))))
		    (binary-search
		     start jd
		     end   (+ jd ( * (/ l 360) 400d0))
		     x     (if (= next 0); Discontinuity at next=0
		               ;; Then test for drop in longitude
		               (>= l (solar-longitude x))
		             ;; Else test if we are past the desired
		             ;; longitude
		             (>= (solar-longitude x) next))
		     (>= 0.00001d0 (- end start)))))
		-*/
	public static double dateNextSolarLongitude(double jd, double l) {
		double next = degrees(l * Math.ceil(solarLongitude(jd) / l));
		double lo = jd, hi = jd + l / 360 * 400, x = (hi + lo) / 2;
		while(hi - lo > 0.00001) {
			if(next == 0 ? l >= solarLongitude(x) : solarLongitude(x) >= next)
				hi = x;
			else
				lo = x;

			x = (hi + lo) / 2;
		}
		return x;
	}
	
		/*-
		(defun lunar-longitude (u-time)
		  ;; TYPE moment -> angle
		  ;; Longitude of moon (in degrees) at u-time (Universal time).
		  ;; Adapted from "Astronomical Algorithms" by Jean Meeus,
		  ;; Willmann-Bell, Inc., 1991.
		  (let* ((c (julian-centuries u-time))
		         (mean-moon
		          (degrees
		           (poly c
		                 (list 218.3164591d0 481267.88134236d0
		                       -.0013268d0 1/538841 -1/65194000))))
		         (elongation
		          (degrees
		           (poly c
		                 (list 297.8502042d0 445267.1115168d0
		                       -.00163d0 1/545868 -1/113065000))))
		         (solar-anomaly
		          (degrees
		           (poly c
		                 (list 357.5291092d0 35999.0502909d0
		                       -.0001536d0 1/24490000))))
		         (lunar-anomaly
		          (degrees
		           (poly c
		                 (list 134.9634114d0 477198.8676313d0
		                       0.008997d0 1/69699 -1/14712000))))
		         (moon-from-node
		          (degrees
		           (poly c
		                 (list 93.2720993d0 483202.0175273d0
		                       -.0034029d0 -1/3526000 1/863310000))))
		         (e (poly c (list 1 -0.002516d0 -0.0000074d0)))
		         (args-lunar-elongation
		          (list 0 2 2 0 0 0 2 2 2 2 0 1 0 2 0 0 4 0 4 2 2 1
		                1 2 2 4 2 0 2 2 1 2 0 0 2 2 2 4 0 3 2 4 0 2
		                2 2 4 0 4 1 2 0 1 3 4 2 0 1 2 2))
		         (args-solar-anomaly
		          (list 0 0 0 0 1 0 0 -1 0 -1 1 0 1 0 0 0 0 0 0 1 1
		                0 1 -1 0 0 0 1 0 -1 0 -2 1 2 -2 0 0 -1 0 0 1
		                -1 2 2 1 -1 0 0 -1 0 1 0 1 0 0 -1 2 1 0 0))
		         (args-lunar-anomaly
		          (list 1 -1 0 2 0 0 -2 -1 1 0 -1 0 1 0 1 1 -1 3 -2
		                -1 0 -1 0 1 2 0 -3 -2 -1 -2 1 0 2 0 -1 1 0
		                -1 2 -1 1 -2 -1 -1 -2 0 1 4 0 -2 0 2 1 -2 -3
		                2 1 -1 3 -1))
		         (args-moon-from-node
		          (list 0 0 0 0 0 2 0 0 0 0 0 0 0 -2 2 -2 0 0 0 0 0
		                0 0 0 0 0 0 0 2 0 0 0 0 0 0 -2 2 0 2 0 0 0 0
		                0 0 -2 0 0 0 0 -2 -2 0 0 0 0 0 0 0 -2))
		         (sine-coefficients
		          (list 6288774 1274027 658314 213618 -185116 -114332
		                58793 57066 53322 45758 -40923 -34720 -30383
		                15327 -12528 10980 10675 10034 8548 -7888
		                -6766 -5163 4987 4036 3994 3861 3665 -2689
		                -2602 2390 -2348 2236 -2120 -2069 2048 -1773
		                -1595 1215 -1110 -892 -810 759 -713 -700 691
		                596 549 537 520 -487 -399 -381 351 -340 330
		                327 -323 299 294 0))
		         (longitude
		          ( * 1/1000000
		             (sigma ((v sine-coefficients)
		                     (w args-lunar-elongation)
		                     (x args-solar-anomaly)
		                     (y args-lunar-anomaly)
		                     (z args-moon-from-node))
		                    ( * v (expt e (abs x))
		                       (sin-degrees
		                        (+ ( * w elongation)
		                           ( * x solar-anomaly)
		                           ( * y lunar-anomaly)
		                           ( * z moon-from-node)))))))
		         (venus ( * 3958/1000000
		                   (sin-degrees
		                    (+ 119.75d0 ( * c 131.849d0)))))
		         (jupiter ( * 318/1000000
		                     (sin-degrees
		                      (+ 53.09d0 ( * c 479264.29d0)))))
		         (flat-earth
		          ( * 1962/1000000
		             (sin-degrees (- mean-moon moon-from-node)))))
		    (degrees (+ mean-moon longitude venus jupiter flat-earth
		                (radians-to-degrees (nutation c))))))
		-*/
	public static double lunarLongitude(double uTime) {
		double c = julianCenturies(uTime);
		double meanMoon = degrees(poly(c, ll.coeffMeanMoon));
		double elongation = degrees(poly(c, ll.coeffElongation));
		double solarAnomaly = degrees(poly(c, ll.coeffSolarAnomaly));
		double lunarAnomaly = degrees(poly(c, ll.coeffLunarAnomaly));
		double moonFromNode = degrees(poly(c, ll.coeffMoonFromNode));
		double e = poly(c, ll.coeffE);
		double sigma = 0;
		for(int i = 0; i < ll.argsLunarElongation.length; i++) {
			double x = ll.argsSolarAnomaly[i];
			sigma += ll.sineCoefficients[i] *
				Math.pow(e, Math.abs(x)) *
				sinDegrees(	ll.argsLunarElongation[i] * elongation + 
					x * solarAnomaly +
					ll.argsLunarAnomaly[i] * lunarAnomaly +
					ll.argsMoonFromNode[i] * moonFromNode);
		}
		double longitude = 1d/1000000 * sigma;
		double venus = 3958d/1000000 * sinDegrees(119.75 + c * 131.849);
		double jupiter = 318d/1000000 * sinDegrees(53.09 + c * 479264.29);
		double flatEarth = 1962d/1000000 * sinDegrees(meanMoon - moonFromNode);
		return degrees(meanMoon + longitude + venus + jupiter + flatEarth + radiansToDegrees(nutation(c)));
	}
	private static class ll {
		private static final double[] coeffMeanMoon = new double[] {218.3164591, 481267.88134236, -0.0013268, 1d/538841, -1d/65194000};
		private static final double[] coeffElongation = new double[] {297.8502042, 445267.1115168, -0.00163, 1d/545868, -1d/113065000};
		private static final double[] coeffSolarAnomaly = new double[] {357.5291092, 35999.0502909, -0.0001536, 1d/24490000};
		private static final double[] coeffLunarAnomaly = new double[] {134.9634114, 477198.8676313, 0.008997, 1d/69699, -1d/14712000};
		private static final double[] coeffMoonFromNode = new double[] {93.2720993, 483202.0175273, -0.0034029, -1d/3526000, 1d/863310000};
		private static final double[] coeffE = new double[] {1, -0.002516, -0.0000074};
		private static final byte[] argsLunarElongation = new byte[] {
			0, 2, 2, 0, 0, 0, 2, 2, 2, 2, 0, 1, 0, 2, 0, 0, 4, 0, 4, 2, 2, 1,
			1, 2, 2, 4, 2, 0, 2, 2, 1, 2, 0, 0, 2, 2, 2, 4, 0, 3, 2, 4, 0, 2,
			2, 2, 4, 0, 4, 1, 2, 0, 1, 3, 4, 2, 0, 1, 2, 2
		};
		private static final byte[] argsSolarAnomaly = new byte[] {
			0, 0, 0, 0, 1, 0, 0, -1, 0, -1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1,
			0, 1, -1, 0, 0, 0, 1, 0, -1, 0, -2, 1, 2, -2, 0, 0, -1, 0, 0, 1,
			-1, 2, 2, 1, -1, 0, 0, -1, 0, 1, 0, 1, 0, 0, -1, 2, 1, 0, 0
		};
		private static final byte[] argsLunarAnomaly = new byte[] {
			1, -1, 0, 2, 0, 0, -2, -1, 1, 0, -1, 0, 1, 0, 1, 1, -1, 3, -2,
			-1, 0, -1, 0, 1, 2, 0, -3, -2, -1, -2, 1, 0, 2, 0, -1, 1, 0,
			-1, 2, -1, 1, -2, -1, -1, -2, 0, 1, 4, 0, -2, 0, 2, 1, -2, -3,
			2, 1, -1, 3, -1
		};
		private static final byte[] argsMoonFromNode = new byte[] {
			0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, -2, 2, -2, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, -2, 2, 0, 2, 0, 0, 0, 0,
			0, 0, -2, 0, 0, 0, 0, -2, -2, 0, 0, 0, 0, 0, 0, 0, -2
		};
		private static final int[] sineCoefficients = new int[] {
			6288774, 1274027, 658314, 213618, -185116, -114332,
			58793, 57066, 53322, 45758, -40923, -34720, -30383,
			15327, -12528, 10980, 10675, 10034, 8548, -7888,
			-6766, -5163, 4987, 4036, 3994, 3861, 3665, -2689,
			-2602, 2390, -2348, 2236, -2120, -2069, 2048, -1773,
			-1595, 1215, -1110, -892, -810, 759, -713, -700, 691,
			596, 549, 537, 520, -487, -399, -381, 351, -340, 330,
			327, -323, 299, 294, 0
		};
	}

		/*-
		(defun new-moon-time (k)
		  ;; TYPE integer -> julian-day-number
		  ;; Astronomical (julian) day number (at Greenwich) of k-th
		  ;; new moon after (or before) the new moon of January 6,
		  ;; 2000.  Adapted from "Astronomical Algorithms" by Jean
		  ;; Meeus, Willmann-Bell, Inc., 1991.
		  (let* ((c (/ k 1236.85d0))
		         (JDE (poly c (list 2451550.09765d0
		                            ( * mean-synodic-month
		                               1236.85d0)
		                            0.0001337d0
		                            -0.000000150d0
		                            0.00000000073d0)))
		         (e (poly c (list 1 -0.002516d0 -0.0000074d0)))
		         (solar-anomaly
		          (poly c (list 2.5534d0 ( * 29.10535669d0 1236.85d0)
		                        -0.0000218d0 -0.00000011d0)))
		         (lunar-anomaly
		          (poly c (list 201.5643d0 ( * 385.81693528d0
		                                      1236.85d0)
		                        0.0107438d0 0.00001239d0
		                        -0.000000058d0)))
		         (moon-argument
		          (poly c (list 160.7108d0 ( * 390.67050274d0
		                                      1236.85d0)
		                        -0.0016341d0 -0.00000227d0
		                        0.000000011d0)))
		         (omega
		          (poly c (list 124.7746d0 ( * -1.56375580d0 1236.85d0)
		                        0.0020691d0 0.00000215d0)))
		         (e-factor (list 0 1 0 0 1 1 2 0 0 1 0 1 1 1 0 0 0 0
		                         0 0 0 0 0 0))
		         (solar-coeff (list 0 1 0 0 -1 1 2 0 0 1 0 1 1 -1 2
		                            0 3 1 0 1 -1 -1 1 0))
		         (lunar-coeff (list 1 0 2 0 1 1 0 1 1 2 3 0 0 2 1 2
		                            0 1 2 1 1 1 3 4))
		         (moon-coeff (list 0 0 0 2 0 0 0 -2 2 0 0 2 -2 0 0
		                           -2 0 -2 2 2 2 -2 0 0))
		         (sine-coeff
		          (list -0.40720d0 0.17241d0 0.01608d0 0.01039d0
		                0.00739d0 -0.00514d0 0.00208d0
		                -0.00111d0 -0.00057d0 0.00056d0
		                -0.00042d0 0.00042d0 0.00038d0
		                -0.00024d0 -0.00007d0 0.00004d0
		                0.00004d0 0.00003d0 0.00003d0
		                -0.00003d0 0.00003d0 -0.00002d0
		                -0.00002d0 0.00002d0))
		         (correction
		          (+ ( * -.00017d0 (sin-degrees omega))
		             (sigma ((v sine-coeff)
		                     (w e-factor)
		                     (x solar-coeff)
		                     (y lunar-coeff)
		                     (z moon-coeff))
		                    ( * v (expt e w)
		                       (sin-degrees
		                        (+ ( * x solar-anomaly)
		                           ( * y lunar-anomaly)
		                           ( * z moon-argument)))))))
		         (add-const
		          (list 299.77d0 251.88d0 251.83d0 349.42d0 84.66d0
		                141.74d0 207.14d0 154.84d0 34.52d0 207.19d0
		                291.34d0 161.72d0 239.56d0 331.55d0))
		         (add-coeff
		          (list 0.107408d0 0.016321d0 26.641886d0
		                36.412478d0 18.206239d0 53.303771d0
		                2.453732d0 7.306860d0 27.261239d0 0.121824d0
		                1.844379d0 24.198154d0 25.513099d0
		                3.592518d0))
		         (add-extra
		          (list -0.009173d0 0 0 0 0 0 0 0 0 0 0 0 0 0))
		         (add-factor
		          (list 0.000325d0 0.000165d0 0.000164d0 0.000126d0
		                0.000110d0 0.000062d0 0.000060d0 0.000056d0
		                0.000047d0 0.000042d0 0.000040d0 0.000037d0
		                0.000035d0 0.000023d0))
		         (additional
		          (sigma ((i add-const)
		                  (j add-coeff)
		                  (n add-extra)
		                  (l add-factor))
		                 ( * l (sin-degrees
		                       (+ i ( * j k) ( * n c c)))))))
		    (universal-from-ephemeris (+ JDE correction additional))))
		-*/
	public static double newMoonTime(int k) {
		double c = k / 1236.85d;
		double JDE = poly(c, nm.coeffJDE);
		double e = poly(c, nm.coeffE);
		double solarAnomaly = poly(c, nm.coeffSolarAnomaly);
		double lunarAnomaly = poly(c, nm.coeffLunarAnomaly);
		double moonArgument = poly(c, nm.coeffMoonArgument);
		double omega = poly(c, nm.coeffOmega);
		double correction = -0.00017 * sinDegrees(omega);
		for(int ix = 0; ix < nm.sineCoeff.length; ix++) {
			correction += nm.sineCoeff[ix] * Math.pow(e, nm.eFactor[ix]) *
				sinDegrees(nm.solarCoeff[ix] * solarAnomaly +
					nm.lunarCoeff[ix] * lunarAnomaly +
					nm.moonCoeff[ix] * moonArgument);
		}
		double additional = 0;
		for(int ix = 0; ix < nm.addConst.length; ix++) {
			additional += nm.addFactor[ix] *
				sinDegrees(nm.addConst[ix] + nm.addCoeff[ix] * k + nm.addExtra[ix] * c * c);
		}
		return universalFromEphemeris(JDE + correction + additional);
	}
	private static class nm {
		private static final double[] coeffJDE = new double[] {2451550.09765, MEAN_SYNODIC_MONTH * 1236.85, 0.0001337, -0.000000150, 0.00000000073};
		private static final double[] coeffE = new double[] {1, -0.002516, -0.0000074};
		private static final double[] coeffSolarAnomaly = new double[] {2.5534, 29.10535669 * 1236.85, -0.0000218, -0.00000011};
		private static final double[] coeffLunarAnomaly = new double[] {201.5643, 385.81693528 * 1236.85, 0.0107438, 0.00001239, -0.000000058};
		private static final double[] coeffMoonArgument = new double[] {160.7108, 390.67050274 * 1236.85, -0.0016341, -0.00000227, 0.000000011};
		private static final double[] coeffOmega = new double[] {124.7746, -1.56375580 * 1236.85, 0.0020691, 0.00000215};
		private static final byte[] eFactor = new byte[] {0, 1, 0, 0, 1, 1, 2, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		private static final byte[] solarCoeff = new byte[] {0, 1, 0, 0, -1, 1, 2, 0, 0, 1, 0, 1, 1, -1, 2, 0, 3, 1, 0, 1, -1, -1, 1, 0};
		private static final byte[] lunarCoeff = new byte[] {1, 0, 2, 0, 1, 1, 0, 1, 1, 2, 3, 0, 0, 2, 1, 2, 0, 1, 2, 1, 1, 1, 3, 4};
		private static final byte[] moonCoeff = new byte[] {0, 0, 0, 2, 0, 0, 0, -2, 2, 0, 0, 2, -2, 0, 0, -2, 0, -2, 2, 2, 2, -2, 0, 0};
		private static final double[] sineCoeff = new double[] {
			-0.40720, 0.17241, 0.01608, 0.01039, 0.00739, -0.00514, 0.00208,
			-0.00111, -0.00057, 0.00056, -0.00042, 0.00042, 0.00038, -0.00024,
			-0.00007, 0.00004, 0.00004, 0.00003, 0.00003, -0.00003, 0.00003,
			-0.00002, -0.00002, 0.00002
		};
		private static final double[] addConst = new double[] {
			299.77, 251.88, 251.83, 349.42, 84.66, 141.74, 207.14, 154.84, 34.52, 207.19,
			291.34, 161.72, 239.56, 331.55
		};
		private static final double[] addCoeff = new double[] {
			0.107408, 0.016321, 26.641886, 36.412478, 18.206239, 53.303771, 2.453732,
			7.306860, 27.261239, 0.121824, 1.844379, 24.198154, 25.513099, 3.592518
		};
		private static final double[] addExtra = new double[] {
			-0.009173, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
		};
		private static final double[] addFactor = new double[] {
			0.000325, 0.000165, 0.000164, 0.000126, 0.000110, 0.000062, 0.000060, 0.000056,
			0.000047, 0.000042, 0.000040, 0.000037, 0.000035, 0.000023
		};
	}

		/*-
		(defun new-moon-at-or-after (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Astronomical (julian) day number of first new moon at
		  ;; or after astronomical (julian) day number jd (in
		  ;; Greenwich).  The fractional part is the time of day.
		  (let* ((date; Gregorian date, Universal Time
		          (gregorian-from-fixed
		           (floor (moment-from-jd jd))))
		         (approx; Approximate number of new moons since
		                ; January 6, 2000
		          (1- (floor ( * (- (+ (standard-year date)
		                              (/ (day-number date) 365.25d0))
		                           2000.0d0)
		                        12.3685d0)))) ; New moons per year.
		         (error (sum 1 k approx (< (new-moon-time k) jd))))
		    (new-moon-time (+ approx error))))
		-*/
	public static double newMoonAtOrAfter(double jd) {
		Gregorian date = new Gregorian((int)Math.floor(momentFromJD(jd)));
		int approx = (int)Math.floor(((date.year + date.dayNumber() / 365.25) - 2000.0) * 12.3685) - 1;
		int error = 0;
		for(int i = approx; newMoonTime(i) < jd; i++)
			error++;
		return newMoonTime(approx + error);
	}
	
		/*-
		(defun new-moon-before (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Astronomical (julian) day number of last new moon
		  ;; before astronomical (julian) day number jd (in
		  ;; Greenwich).  The fractional part is the time of day.
		  (new-moon-at-or-after (- (new-moon-at-or-after jd) 45)))
		-*/
	public static double newMoonBefore(double jd) {
		return newMoonAtOrAfter(newMoonAtOrAfter(jd) - 45);
	}

		/*-
		(defun lunar-solar-angle (jd)
		  ;; TYPE julian-day-number -> phase
		  ;; Lunar phase, as an angle in degrees, at astronomical
		  ;; (julian) day number jd.  An angle of 0 means a new
		  ;; moon, 90 degrees means the first quarter, 180 means a
		  ;; full moon, and 270 degrees means the last quarter.
		  (degrees (- (lunar-longitude jd)
		              (solar-longitude jd))))
		-*/
	public static double lunarSolarAngle(double jd) {
		return degrees(lunarLongitude(jd) - solarLongitude(jd));
	}
	
		/*-
		(defun lunar-phase-at-or-before (phase jd)
		  ;; TYPE (phase julian-day-number) -> julian-day-number
		  ;; Astronomical (julian) day number of last time moon was
		  ;; in phase phase (in degrees) at or before astronomical
		  ;; (julian) day number jd (in Greenwich).  The fractional
		  ;; part is the time of day.
		  (let* ((close (< (degrees (- (lunar-solar-angle jd) 
		                               phase)) 
		                   40))
		         (yesterday (1- jd))
		         (orig (+ 2451550.26d0
		                  ( * mean-synodic-month (/ phase 360))))
		         (epsilon 0.000001d0)
		         (tau (- yesterday
		                 (mod (- yesterday orig)
		                      mean-synodic-month))))
		    (binary-search
		     l (if close (- jd 4) (- tau 2))
		     u (if close jd (+ tau 2))
		     x (<= phase (lunar-solar-angle x) (+ phase 90))
		     (< (- u l) epsilon))))
		-*/
	public static double lunarPhaseAtOrBefore(double phase, double jd) {
		boolean close = degrees(lunarSolarAngle(jd) - phase) < 40;
		double yesterday = jd - 1;
		double orig = 2451550.26 + MEAN_SYNODIC_MONTH * (phase / 360);
		double epsilon = 0.000001;
		double tau = yesterday - mod(yesterday - orig, MEAN_SYNODIC_MONTH);

		double lo = close ? jd - 4 : tau - 2, hi = close ? jd : tau + 2, x = (hi + lo) / 2;
		while(hi - lo > epsilon) {
			double lunSolAngle = lunarSolarAngle(x);
			if(phase <= lunSolAngle && lunSolAngle <= phase + 90)
				hi = x;
			else
				lo = x;

			x = (hi + lo) / 2;
		}
		return x;
	}
		
		/*-
		(defun new-moon-at-or-before (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Astronomical (julian) day number of last new moon
		  ;; at or before astronomical (julian) day number jd (in
		  ;; Greenwich).  The fractional part is the time of day.
		  (lunar-phase-at-or-before new jd))
		-*/
	public static double newMoonAtOrBefore(double jd) {
		return lunarPhaseAtOrBefore(NEW, jd);
	}

		/*-
		(defun full-moon-at-or-before (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Astronomical (julian) day number of last full moon
		  ;; at or before astronomical (julian) day number jd (in
		  ;; Greenwich).  The fractional part is the time of day.
		  (lunar-phase-at-or-before full jd))
		-*/
	public static double fullMoonAtOrBefore(double jd) {
		return lunarPhaseAtOrBefore(FULL, jd);
	}

		/*-
		(defun first-quarter-moon-at-or-before (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Astronomical (julian) day number of last first-quarter
		  ;; moon at or before astronomical (julian) day number jd
		  ;; (in Greenwich).  The fractional part is the time of
		  ;; day.
		  (lunar-phase-at-or-before first-quarter jd))
		-*/
	public static double firstQuarterMoonAtOrBefore(double jd) {
		return lunarPhaseAtOrBefore(FIRST_QUARTER, jd);
	}

		/*-
		(defun last-quarter-moon-at-or-before (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Astronomical (julian) day number of last last-quarter
		  ;; moon at or before astronomical (julian) day number jd
		  ;; (in Greenwich).  The fractional part is the time of
		  ;; day.
		  (lunar-phase-at-or-before last-quarter jd))
		-*/
	public static double lastQuarterMoonAtOrBefore(double jd) {
		return lunarPhaseAtOrBefore(LAST_QUARTER, jd);
	}

		/*-
		(defun sidereal-from-jd (jd)
		  ;; TYPE julian-day-number -> julian-day-number
		  ;; Sidereal Time from julian-day-number.
		  ;; Adapted from "Astronomical Algorithms"
		  ;; by Jean Meeus, Willmann-Bell, Inc., 1991.
		  (let* ((c (/ (- jd j2000) 36525))
		         (sidereal-coeff
		          (list 280.46061837d0 ( * 36525 360.98564736629d0)
		                0.000387933d0 1/38710000)))
		    (/ (poly c sidereal-coeff) 360)))
		-*/
	public static double siderealFromJD(double jd) {
		double c = (jd - J2000) / 36525;
		return poly(c, sfj.siderealCoeff) / 360;
	}
	private static class sfj {
		private static final double[] siderealCoeff = new double[] {280.46061837, 36525 * 360.98564736629, 0.000387933, 1d/38710000};
	}

	//
	// object methods
	//
	
	public String toString() {
		return this.getClass().getName() + "[" + toStringFields() + "]";
	}
	
	abstract protected String toStringFields();

	abstract public boolean equals(Object obj);
};
