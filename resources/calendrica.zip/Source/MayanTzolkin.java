package calendrica;

	
public class MayanTzolkin extends ProtoDate {

	//
	// fields
	//

		public int number;
		public int name;

	//
	// constants
	//

		/*-
		(defconstant mayan-tzolkin-at-epoch
		  ;; TYPE mayan-tzolkin-date
		  ;; Tzolkin date at long count 0.0.0.0.0.
		  (mayan-tzolkin-date 4 20))
		-*/
	public static final MayanTzolkin EPOCH = new MayanTzolkin(4, 20);

	//
	// constructors
	//

	public MayanTzolkin() { }
	
	public MayanTzolkin(int date) {
		super(date);
	}
	
	public MayanTzolkin(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public MayanTzolkin(int number, int name) {
		this.number	= number;
		this.name	= name;
	}
	
	//
	// date conversion methods
	//

		/*-
		(defun mayan-tzolkin-from-fixed (date)
		  ;; TYPE fixed-date -> mayan-tzolkin-date
		  ;; Mayan tzolkin date of fixed date.
		  (let* ((long-count (- date mayan-epoch))
		         (number
		          (adjusted-mod (+ long-count
		                           (mayan-tzolkin-number
		                            mayan-tzolkin-at-epoch))
		                        13))
		         (name
		          (adjusted-mod (+ long-count
		                           (mayan-tzolkin-name
		                            mayan-tzolkin-at-epoch))
		                        20)))
		    (mayan-tzolkin-date number name)))
		-*/
	public void fromFixed(int date) {
		int longCount = date - MayanLongCount.EPOCH;
		number = adjustedMod(longCount + EPOCH.number, 13);
		name = adjustedMod(longCount + EPOCH.name, 20);
	}
	
	public void fromArray(int[] a) {
		number	= a[0];
		name	= a[1];
	}

	
	//
	// auxiliary methods
	//

		/*-
		(defun mayan-tzolkin-difference (t-date1 t-date2)
		  ;; TYPE (mayan-tzolkin-date mayan-tzolkin-date) -> integer
		  ;; Number of days from Mayan tzolkin date t-date1 to the
		  ;; next occurrence of Mayan tzolkin date t-date2.
		  (let* ((number1 (mayan-tzolkin-number t-date1))
		         (number2 (mayan-tzolkin-number t-date2))
		         (name1 (mayan-tzolkin-name t-date1))
		         (name2 (mayan-tzolkin-name t-date2))
		         (number-difference (- number2 number1))
		         (name-difference (- name2 name1)))
		    (mod (+ number-difference
		            ( * 13 (mod ( * 3 (- number-difference
		                               name-difference))
		                       20)))
		         260)))
		-*/
	public static int difference(MayanTzolkin date1, MayanTzolkin date2) {
		int numberDifference = date2.number - date1.number;
		int nameDifference = date2.name - date1.name;
		return mod(numberDifference + 13 * mod(3 * (numberDifference - nameDifference), 20), 260);
	}
	
		/*-
		(defun mayan-tzolkin-on-or-before (tzolkin date)
		  ;; TYPE (mayan-tzolkin-date fixed-date) -> fixed-date
		  ;; Fixed date of latest date on or before fixed date
		  ;; that is Mayan tzolkin date tzolkin.
		  (- date
		     (mod (- date (mayan-tzolkin-difference
		                   (mayan-tzolkin-from-fixed 0)
		                   tzolkin))
		          260)))
		-*/
	public static int onOrBefore(MayanTzolkin tzolkin, int date) {
		return date - mod(date - difference(new MayanTzolkin(0), tzolkin), 260);
	}

		/*-
		(defun mayan-haab-tzolkin-on-or-before (haab tzolkin date)
		  ;; TYPE (mayan-haab-date mayan-tzolkin-date fixed-date)
		  ;; TYPE -> fixed-date
		  ;; Fixed date of latest date on or before date
		  ;; that is Mayan haab date haab and tzolkin date tzolkin;
		  ;; returns bogus if such a haab-tzolkin combination is
		  ;; impossible.
		  (let* ((haab-difference
		          (mayan-haab-difference (mayan-haab-from-fixed 0)
		                                 haab))
		         (tzolkin-difference
		          (mayan-tzolkin-difference
		           (mayan-tzolkin-from-fixed 0)
		           tzolkin))
		         (diff (- tzolkin-difference haab-difference)))
		    (if (= (mod diff 5) 0)
		        (- date
		           (mod (- date (+ haab-difference
		                           ( * 365 diff)))
		                18980))
		      bogus)));  haab-tzolkin combination is impossible.
		-*/
	public static int haabTzolkinOnOrBefore(MayanHaab haab, MayanTzolkin tzolkin, int date)
		throws BogusDateException
	{
		int haabDifference = MayanHaab.difference(new MayanHaab(0), haab);
		int tzolkinDifference = difference(new MayanTzolkin(0), tzolkin);
		int diff = tzolkinDifference - haabDifference;
		int result;
		if(mod(diff, 5) == 0)
			result = date - mod(date - (haabDifference + 365 * diff), 18980);
		else
			throw new BogusDateException();

		return result;
	}
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "number=" + number + ",name=" + name;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof MayanTzolkin))
			return false;
		
		MayanTzolkin o = (MayanTzolkin)obj;
		
		return
			o.number	== number	&&
			o.name		== name		;
	}
}
