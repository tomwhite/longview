package calendrica;


public class ISO extends Date {
	
	//
	// fields
	//

	public int week;
	public int day;
	public int year;

	//
	// constructors
	//

	public ISO() { }
	
	public ISO(int date) {
		super(date);
	}
	
	public ISO(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public ISO(int week, int day, int year) {
		this.week = week;
		this.day = day;
		this.year = year;
	}
	
	//
	// date conversion methods
	//

		/*-
		(defun fixed-from-iso (i-date)
		  ;; TYPE iso-date -> fixed-date
		  ;; Fixed date equivalent to ISO (week day year).
		  (let* ((week (iso-week i-date))
		         (day (iso-day i-date))
		         (year (iso-year i-date)))
		    ;; Add fixed date of Sunday preceding date plus day
		    ;; in week.
		    (+ (nth-kday
		        week sunday
		        (gregorian-date december 28 (1- year))) day)))
		-*/
	public static int toFixed(int week, int day, int year) {
		return nthKDay(week, SUNDAY, Gregorian.toFixed(DECEMBER, 28, year - 1)) + day;
	}
	
	public int toFixed() {
		return toFixed(week, day, year);
	}
	
		/*-
		(defun iso-from-fixed (date)
		  ;; TYPE fixed-date -> iso-date
		  ;; ISO (week day year) corresponding to the fixed date.
		  (let* ((approx ; Year may be one too small.
		          (gregorian-year-from-fixed (- date 3)))
		         (year (if (>= date
		                       (fixed-from-iso
		                        (iso-date 1 1 (1+ approx))))
		                   (1+ approx)
		                 approx))
		         (week (1+ (quotient
		                    (- date
		                       (fixed-from-iso (iso-date 1 1 year)))
		                    7)))
		         (day (adjusted-mod date 7)))
		    (iso-date week day year)))
		-*/
	public void fromFixed(int date) {
		int approx = Gregorian.yearFromFixed(date - 3);
		year = date >= toFixed(1, 1, approx + 1) ? approx + 1 : approx;
		week = quotient(date - toFixed(1, 1, year), 7) + 1;
		day = adjustedMod(date, 7);
	}
	
	public void fromArray(int[] a) {
		this.week	= a[0];
		this.day	= a[1];
		this.year	= a[2];
	}
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "week=" + week + ",day=" + day + ",year=" + year;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof ISO))
			return false;
		
		ISO o = (ISO)obj;
		
		return
			o.week	== week		&&
			o.day	== day		&&
			o.year	== year		;
	}
}
