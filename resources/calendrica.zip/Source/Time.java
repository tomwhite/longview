package calendrica;

import java.io.Serializable;


public class Time implements Cloneable, Serializable {
	
	//
	// fields
	//

	public int hour;
	public int minute;
	public double second;

	//
	// constructors
	//

	public Time() { }
	
	public Time(double moment) {
		fromMoment(moment);
	}
	
	public Time(int hour, int minute, double second) {
		this.hour	= hour;
		this.minute	= minute;
		this.second	= second;
	}
	
	//
	// time conversion methods
	//
	
	public static double toMoment(int hour, int minute, double second) {
		return hour / 24d + minute / (24d * 60) + second / (24d * 60 * 60);
	}

	public double toMoment() {
		return toMoment(hour, minute, second);
	}
	
		/*-
		(defun time-from-moment (moment)
		  ;; TYPE moment -> (hour minute second)
		  ;; Time of day (hour minute second) from moment moment.
		  (let* ((hour (floor (mod ( * moment 24) 24)))
		         (minute (floor (mod ( * moment 24 60) 60)))
		         (second (double-float (mod ( * moment 24 60 60) 60))))
		    (time-of-day hour minute second)))
		-*/
	public void fromMoment(double moment) {
		hour = (int)Math.floor(Date.mod(moment * 24, 24));
		minute = (int)Math.floor(Date.mod(moment * 24 * 60, 60));
		second = Date.mod(moment * 24 * 60 * 60, 60);
	}
	
	//
	// object methods
	//

	public String toString() {
		return this.getClass().getName() + "[hour=" + hour + ",minute=" + minute + ",second=" + second + "]";
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof Time))
			return false;
		
		Time o = (Time)obj;
		
		return
			o.hour		== hour		&&
			o.minute	== minute	&&
			o.second	== second	;
	}
}
