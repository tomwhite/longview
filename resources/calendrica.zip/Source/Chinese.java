package calendrica;


public class Chinese extends Date {
	
	//
	// fields
	//

	public int		cycle;
	public int		year;
	public int		month;
	public boolean	leap;
	public int		day;

	//
	// constructors
	//

	public Chinese() { }
	
	public Chinese(int date) {
		super(date);
	}
	
	public Chinese(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Chinese(int cycle, int year, int month, boolean leap, int day) {
		this.cycle	= cycle;
		this.year	= year;
		this.month	= month;
		this.leap	= leap;
		this.day	= day;
	}
	
	//
	// constants
	//
	
		/*-
		(defconstant chinese-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Chinese calendar.
		  (fixed-from-gregorian (gregorian-date february 15 -2636)))
		-*/
	public static final int EPOCH = Gregorian.toFixed(FEBRUARY, 15, -2636);

	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-chinese (c-date)
		  ;; TYPE chinese-date -> fixed-date
		  ;; Fixed date of Chinese date (cycle year month leap
		  ;; day).
		  (let* ((cycle (chinese-cycle c-date))
		         (year (chinese-year c-date))
		         (month (chinese-month c-date))
		         (leap (chinese-leap c-date))
		         (day (chinese-day c-date))
		         (g-year; Gregorian year at start of Chinese year
		          (+ ( * (1- cycle) 60); years in prior cycles
		             (1- year)        ; prior years this cycle
		             ;; Gregorian year at start of calendar
		             (gregorian-year-from-fixed chinese-epoch)))
		         (new-year (chinese-new-year g-year))
		         (p; new moon before date--a month too early if
		           ; there was prior leap month that year
		          (chinese-new-moon-on-or-after
		           (+ new-year ( * (1- month) 29))))
		         (d (chinese-from-fixed p))
		         (prior-new-moon
		          (if  ; If the months match...
		              (and (= month (chinese-month d))
		                   (equal leap (chinese-leap d)))
		              p; ...that's the right month
		            ;; otherwise, there was a prior leap month that
		            ;; year, so we want the next month
		            (chinese-new-moon-on-or-after (1+ p)))))
		    (+ prior-new-moon day -1)))
		-*/
	public static int toFixed(int cycle, int year, int month, boolean leap, int day) {
		int gYear = 60 * (cycle - 1) +
			(year - 1) +
			Gregorian.yearFromFixed(EPOCH);
		int theNewYear = newYear(gYear);
		int p = newMoonOnOrAfter(theNewYear + 29 * (month - 1));
		Chinese d = new Chinese(p);
		int priorNewMoon = month == d.month && leap == d.leap ?
			p :
			newMoonOnOrAfter(p + 1);
		return priorNewMoon + day - 1;
	}

	public int toFixed() {
		return toFixed(cycle, year, month, leap, day);
	}
	
		/*-
		(defun chinese-from-fixed (date)
		  ;; TYPE fixed-date -> chinese-date
		  ;; Chinese date (cycle year month leap day) of fixed
		  ;; date.
		  (let* ((g-year (gregorian-year-from-fixed date))
		         (s1; Prior solstice for most dates
		          (major-solar-term-on-or-after
		           (fixed-from-gregorian
		            (gregorian-date december 15 (1- g-year)))))
		         (s2; Following solstice for most dates--can be the
		            ; prior solstice if the date is at the end of
		            ; the Gregorian year, just after the solstice
		          (major-solar-term-on-or-after
		           (fixed-from-gregorian
		            (gregorian-date december 15 g-year))))
		         (m1     ; month after last 11th month
		          (if (and (<= s1 date) (< date s2))
		              (chinese-new-moon-on-or-after (1+ s1))
		            ;; Date is at end of the Gregorian year, just
		            ;; after the solstice, so we need the solstice
		            ;; of that year
		            (chinese-new-moon-on-or-after (1+ s2))))
		         (m2     ; next 11th month
		          (if (and (<= s1 date) (< date s2))
		              (chinese-new-moon-before (1+ s2))
		            ;; Date is at end of the Gregorian year, just
		            ;; after the solstice, so we need the solstice
		            ;; of the following year
		            (chinese-new-moon-before
		             (1+ (major-solar-term-on-or-after
		                  (fixed-from-gregorian
		                   (gregorian-date
		                    december 15 (1+ g-year))))))))
		         (m      ; start of month containing date
		          (chinese-new-moon-before (1+ date)))
		         (leap-year; if there are 13 new moons (12 full
		                   ; lunar months)
		          (= (round (/ (- m2 m1) mean-synodic-month)) 12))
		         (month  ; month number
		          (adjusted-mod
		           (-
		            ;; ordinal position of month in year
		            (round (/ (- m m1) mean-synodic-month))
		            ;; minus 1 during or after a leap month
		            (if (and leap-year (prior-leap-month? m1 m))
		                1
		              0))
		           12))
		         (leap-month    ; it's a leap month if...
		          (and leap-year; ...there are 13 months
		               (no-major-solar-term? m); no major solar term
		               (not (prior-leap-month?; and no prior leap month
		                     m1 (chinese-new-moon-before m)))))
		         (elapsed-years ;  since the epoch
		          (+ (- (gregorian-year-from-fixed date)
		                (gregorian-year-from-fixed chinese-epoch))
		             (if (or (< month 11)
		                     (> date (fixed-from-gregorian
		                              (gregorian-date july 1 g-year))))
		                 1 0)))
		         (cycle (1+ (quotient (1- elapsed-years) 60)))
		         (year (adjusted-mod elapsed-years 60))
		         (day (1+ (- date m))))
		    (chinese-date cycle year month leap-month day)))
		-*/
	public void fromFixed(int date) {
		int gYear = Gregorian.yearFromFixed(date);
		int s1 = majorSolarTermOnOrAfter(Gregorian.toFixed(DECEMBER, 15, gYear - 1));
		int s2 = majorSolarTermOnOrAfter(Gregorian.toFixed(DECEMBER, 15, gYear));
		int m1 = s1 <= date && date < s2 ?
			newMoonOnOrAfter(s1 + 1) :
			newMoonOnOrAfter(s2 + 1);
		int m2 = s1 <= date && date < s2 ?
			newMoonBefore(s2 + 1) :
			(newMoonBefore(
				majorSolarTermOnOrAfter(
					Gregorian.toFixed(DECEMBER, 15, gYear))) + 1);
		int m = newMoonBefore(date + 1);
		boolean leapYear = Math.round((m2 - m1) / MEAN_SYNODIC_MONTH) == 12;
		month = adjustedMod(
			(int)Math.round((m - m1) / MEAN_SYNODIC_MONTH) -
			(leapYear && hasPriorLeapMonth(m1, m) ? 1 : 0),
			12);
		leap = leapYear &&
			hasNoMajorSolarTerm(m) &&
			!hasPriorLeapMonth(m1, newMoonBefore(m));
		int elapsedYears = Gregorian.yearFromFixed(date) - Gregorian.yearFromFixed(EPOCH) +
			(month < 11 || date > Gregorian.toFixed(JULY, 1, gYear) ? 1 : 0);
		cycle = quotient(elapsedYears - 1, 60) + 1;
		year = adjustedMod(elapsedYears, 60);
		day = date - m + 1;
	}
	
	public void fromArray(int[] a) {
		this.cycle	= a[0];
		this.year	= a[1];
		this.month	= a[2];
		this.leap	= a[3] != 0;
		this.day	= a[4];
	}
	
	//
	// support methods
	//

		/*-
		(defun chinese-time-zone (date)
		  ;; TYPE fixed-date -> real
		  ;; The difference (in minutes) of the Beijing time zone
		  ;; from Universal Time on fixed date.
		  (let* ((year (gregorian-year-from-fixed date)))
		    (if (< year 1929)
		        (+ 465 40/60)
		      480)))
		-*/
	public static double timeZone(int date) {
		int year = Gregorian.yearFromFixed(date);
		return year < 1929 ? 465 + 40d/60 : 480;
	}
	
		/*-
		(defun chinese-date-next-solar-longitude (d l)
		  ;; (fixed-date angle) -> fixed-date
		  ;; Fixed date (Beijing time) of the first date on or
		  ;; after fixed date d (Beijing time) when the solar
		  ;; longitude will be a multiple of l degrees.
		  (fixed-from-jd
		   (local-from-universal
		    (date-next-solar-longitude
		     (universal-from-local (jd-from-moment d)
		                           (chinese-time-zone d))
		     l)
		    (chinese-time-zone d))))
		-*/
	public static int dateNextSolarLongitude(int d, double l) {
		return fixedFromJD(
			localFromUniversal(
				dateNextSolarLongitude(
					universalFromLocal(
						jdFromMoment(d),
						timeZone(d)),
					l
				),
			timeZone(d))
		);
	}
	
		/*-
		(defun current-major-solar-term (date)
		  ;; TYPE fixed-date -> integer
		  ;; Last Chinese major solar term (zhongqi) before fixed
		  ;; date.
		  (let ((s (solar-longitude
		            (universal-from-local
		             (jd-from-moment date)
		             (chinese-time-zone date)))))
		    (adjusted-mod (+ 2 (quotient s 30)) 12)))
		-*/
	public static int currentMajorSolarTerm(int date) {
		double s = solarLongitude(
			universalFromLocal(
				jdFromMoment(date),
				timeZone(date)));
		return adjustedMod(2 + quotient(s, 30), 12);
	}

		/*-
		(defun major-solar-term-on-or-after (date)
		  ;; TYPE fixed-date -> fixed-date
		  ;; Fixed date (in Beijing) of the first Chinese major
		  ;; solar term (zhongqi) on or after fixed date.  The
		  ;; major terms begin when the sun's longitude is a
		  ;; multiple of 30 degrees.
		  (chinese-date-next-solar-longitude date 30))
		-*/
	public static int majorSolarTermOnOrAfter(int date) {
		return dateNextSolarLongitude(date, 30);
	}
	
		/*-
		(defun current-minor-solar-term (date)
		  ;; TYPE fixed-date -> integer
		  ;; Last Chinese minor solar term (jieqi) before date.
		  (let* ((s (solar-longitude
		             (universal-from-local
		              (jd-from-moment date)
		              (chinese-time-zone date)))))
		    (adjusted-mod (+ 3 (quotient (- s 15) 30)) 12)))
		-*/
	public static int currentMinorSolarTerm(int date) {
		double s = solarLongitude(
			universalFromLocal(
				jdFromMoment(date),
				timeZone(date)));
		return adjustedMod(3 + quotient(s - 15, 30), 12);
	}

		/*-
		(defun minor-solar-term-on-or-after (date)
		  ;; TYPE fixed-date -> fixed-date
		  ;; Fixed date (in Beijing) of the first Chinese minor
		  ;; solar term (jieqi) on or after fixed date.  The
		  ;; minor terms begin when the sun's longitude is a
		  ;; multiple of 30 degrees.
		  (let* ((d (chinese-date-next-solar-longitude date 15))
		         (s (solar-longitude
		             (universal-from-local
		              (jd-from-moment d)
		              (chinese-time-zone d)))))
		    (if (= (mod (round s) 30) 0)
		        (chinese-date-next-solar-longitude d 15)
		      d)))
		-*/
	public static int minorSolarTermOnOrAfter(int date) {
		int d = dateNextSolarLongitude(date, 15);
		double s = solarLongitude(
			universalFromLocal(
				jdFromMoment(date),
				timeZone(date)));
		return mod((int)Math.round(s), 30) == 0 ? dateNextSolarLongitude(d, 15) : d;
	}

		/*-
		(defun chinese-new-moon-before (date)
		  ;; TYPE fixed-date -> fixed-date
		  ;; Fixed date (Beijing) of first new moon before
		  ;; fixed date.
		  (fixed-from-jd
		   (local-from-universal
		    (new-moon-before
		     (universal-from-local
		      (jd-from-moment date)
		      (chinese-time-zone date)))
		    (chinese-time-zone date))))
		-*/
	public static int newMoonBefore(int date) {
		return fixedFromJD(
			localFromUniversal(
				Date.newMoonBefore(
					universalFromLocal(
						jdFromMoment(date),
						timeZone(date))),
				timeZone(date))
		);
	}
	
		/*-
		(defun chinese-new-moon-on-or-after (date)
		  ;; TYPE fixed-date -> fixed-date
		  ;; Fixed date (Beijing) of first new moon on or after
		  ;; fixed date.
		  (fixed-from-jd
		   (local-from-universal
		    (new-moon-at-or-after
		     (universal-from-local
		      (jd-from-moment date)
		      (chinese-time-zone date)))
		    (chinese-time-zone date))))
		-*/
	public static int newMoonOnOrAfter(int date) {
		return fixedFromJD(
			localFromUniversal(
				newMoonAtOrAfter(
					universalFromLocal(
						jdFromMoment(date),
						timeZone(date))),
				timeZone(date))
		);
	}

		/*-
		(defun no-major-solar-term? (date)
		  ;; TYPE fixed-date -> boolean
		  ;; True if Chinese lunar month starting on date
		  ;; has no major solar term.
		  (= (current-major-solar-term date)
		     (current-major-solar-term
		      (chinese-new-moon-on-or-after (1+ date)))))
		-*/
	public static boolean hasNoMajorSolarTerm(int date) {
		return currentMajorSolarTerm(date) ==
			currentMajorSolarTerm(newMoonOnOrAfter(date + 1));
	}
	
		/*-
		(defun chinese-new-year (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Chinese New Year in Gregorian year.
		  (let* ((s1; prior solstice
		          (major-solar-term-on-or-after
		           (fixed-from-gregorian
		            (gregorian-date
		             december 15 (1- g-year)))))
		         (s2; following solstice
		          (major-solar-term-on-or-after
		           (fixed-from-gregorian
		            (gregorian-date december 15 g-year))))
		         (m1 ; month after last 11th month--either 12 or
		             ; leap 11
		          (chinese-new-moon-on-or-after (1+ s1)))
		         (m2 ; month after m2--either 1 or leap 12
		          (chinese-new-moon-on-or-after (1+ m1)))
		         (m11 ; next 11th month
		          (chinese-new-moon-before (1+ s2))))
		    (if ; Either m1 or m2 is a leap month if there are 13
		        ; new moons (12 full lunar months) and either m1 or
		        ; m2 has no major solar term
		        (and (= (round (/ (- m11 m1) mean-synodic-month)) 12)
		             (or (no-major-solar-term? m1)
		                 (no-major-solar-term? m2)))
		        (chinese-new-moon-on-or-after (1+ m2))
		      m2)))
		-*/
	public static int newYear(int gYear) {
		int s1 = majorSolarTermOnOrAfter(
			Gregorian.toFixed(DECEMBER, 15, gYear - 1));
		int s2 = majorSolarTermOnOrAfter(
			Gregorian.toFixed(DECEMBER, 15, gYear));
		int m1 = newMoonOnOrAfter(s1 + 1);
		int m2 = newMoonOnOrAfter(m1 + 1);
		int m11 = newMoonBefore(s2 + 1);
		return (int)Math.round((m11 - m1) / MEAN_SYNODIC_MONTH) == 12 &&
			(hasNoMajorSolarTerm(m1) || hasNoMajorSolarTerm(m2)) ?
				newMoonOnOrAfter(m2 + 1) :
				m2;
	}

		/*-
		(defun prior-leap-month? (m-prime m)
		  ;; TYPE (fixed-date fixed-date) -> boolean
		  ;; True if there is a Chinese leap month at or after lunar
		  ;; month m-prime and at or before lunar month m.
		  (and (>= m m-prime)
		       (or (prior-leap-month? m-prime
		                              (chinese-new-moon-before m))
		           (no-major-solar-term? m))))
		-*/
	/* RECURSIVE */
	public static boolean hasPriorLeapMonth(int mPrime, int m) {
		return m >= mPrime && (hasPriorLeapMonth(mPrime, newMoonBefore(m)) || hasNoMajorSolarTerm(m));
	}

	//
	// auxiliary methods
	//
	
		/*-
		(defun chinese-sexagesimal-name (n)
		  ;; TYPE integer -> ({1--10} {1-12})
		  ;; The n-th name of the Chinese sexagesimal cycle.
		  (list (adjusted-mod n 10)
		        (adjusted-mod n 12)))
		-*/
	public static int[] sexagesimalName(int n) {
		return new int[] {adjustedMod(n, 10), adjustedMod(n, 12)};
	}

		/*-
		(defun chinese-name-of-year (y)
		  ;; TYPE chinese-year -> ({1--10} {1-12})
		  ;; Sexagesimal name for Chinese year y of any cycle.
		  (chinese-sexagesimal-name y))
		-*/
	public static int[] nameOfYear(int y) {
		return sexagesimalName(y);
	}

		/*-
		(defun chinese-name-of-month (y m)
		  ;; TYPE (chinese-year chinese-month) -> ({1--10} {1-12})
		  ;; Sexagesimal name for Chinese month m in year y of any
		  ;; cycle.
		  (chinese-sexagesimal-name (+ ( * 12 y) m 44)))
		-*/
	public static int[] nameOfMonth(int y, int m) {
		return sexagesimalName(12 * y + m + 44);
	}

		/*-
		(defun chinese-name-of-day (date)
		  ;; TYPE chinese-date -> ({1--10} {1-12})
		  ;; Sexagesimal name for Chinese date.
		  (chinese-sexagesimal-name
		   (+ (fixed-from-chinese date) 15)))
		-*/
	public static int[] nameOfDay(int fixed) {
		return sexagesimalName(fixed + 15);
	}

	public int[] nameOfDay() {
		return nameOfDay(toFixed());
	}

		/*-
		(defun dragon-festival (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of the Dragon Festival occurring in
		  ;; Gregorian year.
		  (let* ((elapsed-years
		          (1+ (- g-year
		                 (gregorian-year-from-fixed
		                  chinese-epoch))))
		         (cycle (1+ (quotient (1- elapsed-years) 60)))
		         (year (adjusted-mod elapsed-years 60)))
		    (fixed-from-chinese (chinese-date cycle year 5 false 5))))
		-*/
	public static int dragonFestival(int gYear) {
		int elapsedYears = gYear - Gregorian.yearFromFixed(EPOCH) + 1;
		int cycle = quotient(elapsedYears - 1, 60) + 1;
		int year = adjustedMod(elapsedYears, 60);
		return toFixed(cycle, year, 5, false, 5);
	}

	//
	// object methods
	//

	protected String toStringFields() {
		return "cycle=" + cycle + ",year=" + year +
			",month=" + month + ",leap=" + leap + ",day=" + day;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof Chinese))
			return false;
		
		Chinese o = (Chinese)obj;
		
		return
			o.cycle	== cycle	&&
			o.year	== year		&&
			o.month	== month	&&
			o.leap	== leap		&&
			o.day	== day		;
	}
}
