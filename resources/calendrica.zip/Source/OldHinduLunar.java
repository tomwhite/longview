package calendrica;


public class OldHinduLunar extends Date {
	
	//
	// fields
	//

	public int month;
	public boolean leap;
	public int day;
	public int year;

	//
	// constructors
	//

	public OldHinduLunar() { }
	
	public OldHinduLunar(int date) {
		super(date);
	}
	
	public OldHinduLunar(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public OldHinduLunar(int month, boolean leap, int day, int year) {
		this.month	= month;
		this.leap	= leap;
		this.day	= day;
		this.year	= year;
	}
	
	//
	// constants
	//

		/*-
		(defconstant arya-lunar-month
		  ;; TYPE rational
		  ;; Length of Old Hindu lunar month.
		  1577917500/53433336)
		-*/
	public static final double ARYA_LUNAR_MONTH = 1577917500d/53433336;
	
		/*-
		(defconstant arya-lunar-day
		  ;; TYPE rational
		  ;; Length of Old Hindu lunar day.
		  (/ arya-lunar-month 30))
		-*/
	public static final double ARYA_LUNAR_DAY = ARYA_LUNAR_MONTH / 30;

	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-old-hindu-lunar (l-date)
		  ;; TYPE old-hindu-lunar-date -> fixed-date
		  ;; Fixed date corresponding to Old Hindu lunar date.
		  (let* ((year (old-hindu-lunar-year l-date))
		         (month (old-hindu-lunar-month l-date))
		         (leap (old-hindu-lunar-leap l-date))
		         (day (old-hindu-lunar-day l-date))
		         (mina ; One solar month before solar new year.
		          ( * (1- ( * 12 year)) arya-solar-month))
		         (lunar-new-year ; New moon after mina.
		          ( * arya-lunar-month
		             (1+ (quotient mina arya-lunar-month)))))
		    (floor
		     (+ hindu-epoch
		        lunar-new-year
		        ( * arya-lunar-month
		           (if ; If there was a leap month this year.
		               (and (not leap)
		                    (<= (ceiling (/ (- lunar-new-year mina)
		                                    (- arya-solar-month
		                                       arya-lunar-month)))
		                        month))
		               month
		             (1- month)))
		        ( * (1- day) arya-lunar-day) ; Lunar days.
		        3/4)))) ; Add one if lunar day begins after sunrise.
		-*/
	public static int toFixed(int month, boolean leap, int day, int year) {
		double mina = (12 * year - 1) * OldHinduSolar.ARYA_SOLAR_MONTH;
		double lunarNewYear = ARYA_LUNAR_MONTH * (quotient(mina, ARYA_LUNAR_MONTH) + 1);
		return (int)Math.floor(
			OldHinduSolar.EPOCH +
			lunarNewYear +
			ARYA_LUNAR_MONTH * (!leap &&
					Math.ceil((lunarNewYear - mina) / (OldHinduSolar.ARYA_SOLAR_MONTH - ARYA_LUNAR_MONTH)) <= month ?
						month : month - 1) +
			(day - 1) * ARYA_LUNAR_DAY +
			3d/4
		);
	}

	public int toFixed() {
		return toFixed(month, leap, day, year);
	}
	
		/*-
		(defun old-hindu-lunar-from-fixed (date)
		  ;; TYPE fixed-date -> old-hindu-lunar-date
		  ;; Old Hindu lunar date equivalent to fixed date.
		  (let* ((rise ; Sunrise on Hindu date.
		          (+ (hindu-day-count date) 1/4))
		         (new-moon ; Beginning of lunar month.
		          (- rise (mod rise arya-lunar-month)))
		         (leap ; If lunar contained in solar.
		          (and (>= (- arya-solar-month arya-lunar-month)
		                   (mod new-moon arya-solar-month))
		               (> (mod new-moon arya-solar-month) 0)))
		         (month ; Next solar month's name.
		          (1+ (mod (ceiling (/ new-moon
		                               arya-solar-month))
		                   12)))
		         (day ; Lunar days since beginning of lunar month.
		          (1+ (mod (quotient rise arya-lunar-day) 30)))
		         (year ; Solar year at end of lunar month(s).
		          (1- (ceiling (/ (+ new-moon arya-solar-month)
		                          arya-sidereal-year)))))
		    (old-hindu-lunar-date month leap day year)))
		-*/
	public void fromFixed(int date) {
		double rise = OldHinduSolar.dayCount(date) + 1d/4;
		double newMoon = rise - mod(rise, ARYA_LUNAR_MONTH);
		leap = OldHinduSolar.ARYA_SOLAR_MONTH - ARYA_LUNAR_MONTH >= mod(newMoon, OldHinduSolar.ARYA_SOLAR_MONTH) &&
			mod(newMoon, OldHinduSolar.ARYA_SOLAR_MONTH) > 0;
		month = 1 + (int)mod(Math.ceil(newMoon / OldHinduSolar.ARYA_SOLAR_MONTH), 12);
		day = 1 + mod(quotient(rise, ARYA_LUNAR_DAY), 30);
		year = (int)Math.ceil((newMoon + OldHinduSolar.ARYA_SOLAR_MONTH) / OldHinduSolar.ARYA_SIDEREAL_YEAR) - 1;
	}
	
	public void fromArray(int[] a) {
		this.month	= a[0];
		this.leap	= a[1] != 0;
		this.day	= a[2];
		this.year	= a[3];
	}
	
	//
	// support methods
	//

		/*-
		(defun old-hindu-lunar-leap-year? (l-year)
		  ;; TYPE old-hindu-lunar-year -> boolean
		  ;; True if year is a leap year on the 
		  ;; old Hindu calendar.
		  (>= (mod (- ( * l-year arya-sidereal-year)
		                 arya-solar-month)
		           arya-lunar-month)
		      (- arya-lunar-month
		         (mod arya-sidereal-year arya-lunar-month))))
		-*/
	public static boolean isLeapYear(int lYear) {
		return mod(lYear * OldHinduSolar.ARYA_SIDEREAL_YEAR - OldHinduSolar.ARYA_SOLAR_MONTH, ARYA_LUNAR_MONTH) >=
			ARYA_LUNAR_MONTH - mod(OldHinduSolar.ARYA_SIDEREAL_YEAR, ARYA_LUNAR_MONTH);
	}
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "month=" + month + ",leap=" + leap + ",day=" + day + ",year=" + year;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof OldHinduLunar))
			return false;
		
		OldHinduLunar o = (OldHinduLunar)obj;
		
		return
			o.month	== month	&&
			o.leap	== leap		&&
			o.day	== day		&&
			o.year	== year		;
	}
}
