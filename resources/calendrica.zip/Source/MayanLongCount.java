package calendrica;


public class MayanLongCount extends Date {
	
	//
	// fields
	//

	public int baktun;
	public int katun;
	public int tun;
	public int uinal;
	public int kin;

	//
	// constructors
	//

	public MayanLongCount() { }
	
	public MayanLongCount(int date) {
		super(date);
	}
	
	public MayanLongCount(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public MayanLongCount(int baktun, int katun, int tun, int uinal, int kin) {
		this.baktun	= baktun;
		this.katun	= katun;
		this.tun	= tun;
		this.uinal	= uinal;
		this.kin	= kin;
	}
	
	//
	// constants
	//
	
		/*-
		(defconstant mayan-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Mayan calendar, according
		  ;; to the Goodman-Martinez-Thompson correlation.
		  ;; That is, August 11, -3113.
		  (fixed-from-jd 584282.5))
		-*/
	public static final int EPOCH = fixedFromJD(584282.5);
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-mayan-long-count (count)
		  ;; TYPE mayan-long-count-date -> fixed-date
		  ;; Fixed date corresponding to the Mayan long count
		  ;; count, which is a list (baktun katun tun uinal kin).
		  (let* ((baktun (mayan-baktun count))
		         (katun (mayan-katun count))
		         (tun (mayan-tun count))
		         (uinal (mayan-uinal count))
		         (kin (mayan-kin count)))
		    (+ mayan-epoch      ; Fixed date at Mayan 0.0.0.0.0
		       ( * baktun 144000); Baktun.
		       ( * katun 7200)   ; Katun.
		       ( * tun 360)      ; Tun.
		       ( * uinal 20)     ; Uinal.
		       kin)))           ; Kin (days).
		-*/
	public static int toFixed(int baktun, int katun, int tun, int uinal, int kin) {
		return EPOCH +
			baktun * 144000 +
			katun * 7200 +
			tun * 360 +
			uinal * 20 +
			kin;
	}

	public int toFixed() {
		return toFixed(baktun, katun, tun, uinal, kin);
	}
	
		/*-
		(defun mayan-long-count-from-fixed (date)
		  ;; TYPE fixed-date -> mayan-long-count-date
		  ;; Mayan long count date of fixed date.
		  (let* ((long-count (- date mayan-epoch))
		         (baktun (quotient long-count 144000))
		         (day-of-baktun (mod long-count 144000))
		         (katun (quotient day-of-baktun 7200))
		         (day-of-katun (mod day-of-baktun 7200))
		         (tun (quotient day-of-katun 360))
		         (day-of-tun (mod day-of-katun 360))
		         (uinal (quotient day-of-tun 20))
		         (kin (mod day-of-tun 20)))
		    (mayan-long-count-date baktun katun tun uinal kin)))
		-*/
	public void fromFixed(int date) {
		int longCount = date - EPOCH;
		baktun = quotient(longCount, 144000);
		int dayOfBaktun = mod(longCount, 144000);
		katun = quotient(dayOfBaktun, 7200);
		int dayOfKatun = mod(dayOfBaktun, 7200);
		tun = quotient(dayOfKatun, 360);
		int dayOfTun = mod(dayOfKatun, 360);
		uinal = quotient(dayOfTun, 20);
		kin = mod(dayOfTun, 20);
	}
	
	public void fromArray(int[] a) {
		this.baktun	= a[0];
		this.katun	= a[1];
		this.tun	= a[2];
		this.uinal	= a[3];
		this.kin	= a[4];
	}
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "baktun=" + baktun + ",katun=" + katun +
			",tun=" + tun + ",uinal=" + uinal + ",kin=" + kin;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof MayanLongCount))
			return false;
		
		MayanLongCount o = (MayanLongCount)obj;
		
		return
			o.baktun	== baktun	&&
			o.katun		== katun	&&
			o.tun		== tun		&&
			o.uinal		== uinal	&&
			o.kin		== kin		;
	}
}
