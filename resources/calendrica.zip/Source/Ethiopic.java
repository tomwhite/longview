package calendrica;


public class Ethiopic extends StandardDate {

	//
	// constructors
	//

	public Ethiopic() { }
	
	public Ethiopic(int date) {
		super(date);
	}
	
	public Ethiopic(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Ethiopic(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant ethiopic-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Ethiopic calendar.
		  (fixed-from-julian (julian-date august 29 (ce 7))))
		-*/
	public static final int EPOCH = Julian.toFixed(AUGUST, 29, Julian.CE(7));
	
	//
	// date conversion methods
	//


		/*-
		(defun fixed-from-ethiopic (e-date)
		  ;; TYPE ethiopic-date -> fixed-date
		  ;; Fixed date of Ethiopic date.
		  (let* ((month (standard-month e-date))
		         (day (standard-day e-date))
		         (year (standard-year e-date)))
		    (+ ethiopic-epoch
		       (- (fixed-from-coptic
		           (coptic-date month day year)) coptic-epoch))))
		-*/
	public static int toFixed(int month, int day, int year) {
		return Coptic.toFixed(month, day, year) - Coptic.EPOCH + EPOCH;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
	public void fromFixed(int date) {
		Coptic coptic = new Coptic(date + Coptic.EPOCH - EPOCH);
		month = coptic.month;
		day = coptic.day;
		year = coptic.year;
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Ethiopic))
			return false;
		
		return internalEquals(obj);
	}
}
