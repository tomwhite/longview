package calendrica;


public class Islamic extends StandardDate {

	//
	// constructors
	//

	public Islamic() { }
	
	public Islamic(int date) {
		super(date);
	}
	
	public Islamic(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Islamic(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant islamic-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Islamic calendar.
		  (fixed-from-julian (julian-date july 16 (ce 622))))
		-*/
	public static final int EPOCH = Julian.toFixed(JULY, 16, Julian.CE(622));
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-islamic (i-date)
		  ;; TYPE islamic-date -> fixed-date
		  ;; Fixed date equivalent to Islamic date.
		  (let* ((month (standard-month i-date))
		         (day (standard-day i-date))
		         (year (standard-year i-date)))
		    (+ day                    ; Days so far this month.
		       (ceiling               ; Days in prior months.
		        ( * 29.5 (1- month)))
		       ( * (1- year) 354)      ; Nonleap days in prior years.
		       (quotient              ; Leap days in prior years.
		        (+ 3 ( * 11 year)) 30)
		       islamic-epoch -1)))  ; Days before start of calendar.
		-*/
	public static int toFixed(int month, int day, int year) {
		return day
			+ (int)Math.ceil(29.5 * (month - 1))
			+ (year - 1) * 354
			+ quotient(3 + 11 * year, 30)
			+ EPOCH - 1;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun islamic-from-fixed (date)
		  ;; TYPE fixed-date -> islamic-date
		  ;; Islamic date (month day year) corresponding to fixed
		  ;; date.
		  (let* ((year  ; Divide elapsed days by average year length.
		          (quotient (+ ( * 30 (- date islamic-epoch)) 10646)
		                    10631))
		         (month ; Months alternate between 29 and 30 days
		          (min 12 ; Last month can be longer
		               (1+ (ceiling
		                    (/ (- date 29
		                          (fixed-from-islamic
		                           (islamic-date 1 1 year)))
		                       29.5)))))
		         (day            ; Calculate the day by subtraction.
		          (1+ (- date (fixed-from-islamic
		                       (islamic-date month 1 year))))))
		      (islamic-date month day year)))
		-*/
	public void fromFixed(int date) {
		year = quotient(30 * (date - EPOCH) + 10646, 10631);
		month = Math.min( 12, 1 + (int)Math.ceil((date - 29 - toFixed(1, 1, year)) / 29.5) );
		day = 1 + date - toFixed(month, 1, year);
	}
	
	//
	// support methods
	//

		/*-
		(defun islamic-leap-year? (i-year)
		  ;; TYPE islamic-year -> boolean
		  ;; True if year is an Islamic leap year.
		  (< (mod (+ 14 ( * 11 i-year)) 30) 11))
		-*/
	public static boolean isLeapYear(int iYear) {
		return mod(11 * iYear + 14, 30) < 11;
	}	
	
	//
	// auxiliary methods
	//

		/*-
		(defun islamic-in-gregorian (i-month i-day g-year)
		  ;; TYPE (islamic-month islamic-day gregorian-year)
		  ;; TYPE -> list-of-fixed-dates
		  ;; List of the fixed dates of Islamic month, day
		  ;; that occur in Gregorian year.
		  (let* ((jan1 (fixed-from-gregorian
		                (gregorian-date january 1 g-year)))
		         (dec31 (fixed-from-gregorian
		                 (gregorian-date december 31 g-year)))
		         (y (standard-year (islamic-from-fixed jan1)))
		         ;; The possible occurrences in one year are
		         (date1 (fixed-from-islamic
		                 (islamic-date i-month i-day y)))
		         (date2 (fixed-from-islamic
		                 (islamic-date i-month i-day (1+ y))))
		         (date3 (fixed-from-islamic
		                 (islamic-date i-month i-day (+ 2 y)))))
		    ;; Combine in one list those that occur in current year
		    (append
		     (if (<= jan1 date1 dec31)
		         (list date1) nil)
		     (if (<= jan1 date2 dec31)
		         (list date2) nil)
		     (if (<= jan1 date3 dec31)
		         (list date3) nil))))
		-*/
	public static FixedVector inGregorian(int iMonth, int iDay, int gYear) {
		int jan1 = Gregorian.toFixed(JANUARY, 1, gYear);
		int dec31 = Gregorian.toFixed(DECEMBER, 31, gYear);
		int y = new Islamic(jan1).year;
		int date1 = toFixed(iMonth, iDay, y);
		int date2 = toFixed(iMonth, iDay, y + 1);
		int date3 = toFixed(iMonth, iDay, y + 2);
		FixedVector result = new FixedVector(1, 1);
		if(jan1 <= date1 && date1 <= dec31)
			result.addFixed(date1);
		if(jan1 <= date2 && date2 <= dec31)
			result.addFixed(date2);
		if(jan1 <= date3 && date3 <= dec31)
			result.addFixed(date3);
		return result;
	}

		/*-
		(defun mawlid-an-nabi (g-year)
		  ;; TYPE gregorian-year -> list-of-fixed-dates
		  ;; List of fixed dates of Mawlid-an-Nabi occurring in
		  ;; Gregorian year.
		  (islamic-in-gregorian 3 12 g-year))
		-*/
	public static FixedVector mawlidAnNabi(int gYear) {
		return inGregorian(3, 12, gYear);
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Islamic))
			return false;
		
		return internalEquals(obj);
	}
}
