package calendrica;


public class Coptic extends StandardDate {

	//
	// constructors
	//

	public Coptic() { }
	
	public Coptic(int date) {
		super(date);
	}
	
	public Coptic(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Coptic(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant coptic-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Coptic calendar.
		  (fixed-from-julian (julian-date august 29 (ce 284))))
		-*/
  	public static final int EPOCH = Julian.toFixed(AUGUST, 29, Julian.CE(284));
	
	//
	// date conversion methods
	//
	

		/*-
		(defun fixed-from-coptic (c-date)
		  ;; TYPE coptic-date -> fixed-date
		  ;; Fixed date of Coptic date.
		  (let* ((month (standard-month c-date))
		         (day (standard-day c-date))
		         (year (standard-year c-date)))
		    (+ coptic-epoch -1  ; Days before start of calendar
		       ( * 365 (1- year)); Ordinary days in prior years
		       (quotient year 4); Leap days in prior years
		       ( * 30 (1- month)); Days in prior months this year
		       day)))           ; Days so far this month
		-*/
	public static int toFixed(int month, int day, int year) {
		return EPOCH - 1
			+ 365 * (year - 1)
			+ quotient(year, 4)
			+ 30 * (month - 1)
			+ day;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun coptic-from-fixed (date)
		  ;; TYPE fixed-date -> coptic-date
		  ;; Coptic equivalent of fixed date.
		  (let* ((year ; Calculate the year by cycle-of-years formula
		          (quotient (+ ( * 4 (- date coptic-epoch)) 1463)
		                    1461))
		         (month; Calculate the month by division.
		          (1+ (quotient
		               (- date (fixed-from-coptic
		                        (coptic-date 1 1 year)))
		               30)))
		         (day  ; Calculate the day by subtraction.
		          (- date -1
		             (fixed-from-coptic
		              (coptic-date month 1 year)))))
		    (coptic-date month day year)))
		-*/
	public void fromFixed(int date) {
		year = quotient(4 * (date - EPOCH) + 1463, 1461);
		month = quotient(date - toFixed(1, 1, year), 30) + 1;
		day = date + 1 - toFixed(month, 1, year);
	}
	
	//
	// support methods
	//

		/*-
		(defun coptic-leap-year? (c-year)
		  ;; TYPE coptic-year -> boolean
		  ;; True if year is a leap year on the Coptic calendar.
		  (= (mod c-year 4) 3))
		-*/
	public static boolean isLeapYear(int cYear) {
		return mod(cYear, 4) == 3;
	}	
	
	//
	// auxiliary methods
	//

		/*-
		(defun coptic-in-gregorian (c-month c-day g-year)
		  ;; TYPE (coptic-month coptic-day gregorian-year)
		  ;; TYPE -> list-of-fixed-dates
		  ;; List of the fixed dates of Coptic month, day
		  ;; that occur in Gregorian year.
		  (let* ((jan1 (fixed-from-gregorian
		                (gregorian-date january 1 g-year)))
		         (dec31 (fixed-from-gregorian
		                 (gregorian-date december 31 g-year)))
		         (y (standard-year (coptic-from-fixed jan1)))
		         ;; The possible occurrences in one year are
		         (date1 (fixed-from-coptic
		                 (coptic-date c-month c-day y)))
		         (date2 (fixed-from-coptic
		                 (coptic-date c-month c-day (1+ y)))))
		    (append
		     (if ; date1 occurs in current year
		         (<= jan1 date1 dec31)
		         ;; Then that date; otherwise, none
		         (list date1) nil)
		     (if ; date2 occurs in current year
		         (<= jan1 date2 dec31)
		         ;; Then that date; otherwise, none
		         (list date2) nil))))
		-*/
	public static FixedVector inGregorian(int cMonth, int cDay, int gYear) {
		int jan1 = Gregorian.toFixed(JANUARY, 1, gYear);
		int dec31 = Gregorian.toFixed(DECEMBER, 31, gYear);
		int y = new Coptic(jan1).year;
		int date1 = toFixed(cMonth, cDay, y);
		int date2 = toFixed(cMonth, cDay, y + 1);
		FixedVector result = new FixedVector(1, 1);
		if(jan1 <= date1 && date1 <= dec31)
			result.addFixed(date1);
		if(jan1 <= date2 && date2 <= dec31)
			result.addFixed(date2);
		return result;
	}

		/*-
		(defun coptic-christmas (g-year)
		  ;; TYPE gregorian-year -> list-of-fixed-dates
		  ;; List of zero or one fixed dates of Coptic Christmas
		  ;; in Gregorian year.
		  (coptic-in-gregorian 4 29 g-year))
		-*/
	public static FixedVector christmas(int gYear) {
		return inGregorian(4, 29, gYear);
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Coptic))
			return false;
		
		return internalEquals(obj);
	}
}
