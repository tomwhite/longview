package calendrica;


public class Gregorian extends StandardDate {
	
	//
	// constructors
	//

	public Gregorian() { }
	
	public Gregorian(int date) {
		super(date);
	}
	
	public Gregorian(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Gregorian(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant gregorian-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the (proleptic) Gregorian
		  ;; calendar.
		  1)
		-*/
  	public static final int EPOCH = 1;
	
	//
	// date conversion methods
	//

		/*-
		(defun fixed-from-gregorian (g-date)
		  ;; TYPE gregorian-date -> fixed-date
		  ;; Fixed date equivalent to the Gregorian date.
		  (let* ((month (standard-month g-date))
		         (day (standard-day g-date))
		         (year (standard-year g-date)))
		      (+ (1- gregorian-epoch); Days before start of calendar
		         ( * 365 (1- year)); Ordinary days since epoch
		         (quotient (1- year)
		                   4); Julian leap days since epoch...
		         (-          ; ...minus century years since epoch...
		          (quotient (1- year) 100))
		         (quotient   ; ...plus years since epoch divisible...
		          (1- year) 400)  ; ...by 400.
		         (quotient        ; Days in prior months this year...
		          (- ( * 367 month) 362); ...assuming 30-day Feb
		          12)
		         (if (<= month 2) ; Correct for 28- or 29-day Feb
		             0
		           (if (gregorian-leap-year? year)
		               -1
		             -2))
		         day)))          ; Days so far this month.
		-*/
	public static int toFixed(int month, int day, int year) {
		return EPOCH - 1
			+ 365 * (year - 1)
			+ quotient(year - 1, 4)
			- quotient(year - 1, 100)
			+ quotient(year - 1, 400)
			+ quotient(367 * month - 362, 12)
			+ (month <= 2 ? 0 : (isLeapYear(year) ? -1 : -2))
			+ day;
	}
	
	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun gregorian-from-fixed (date)
		  ;; TYPE fixed-date -> gregorian-date
		  ;; Gregorian (month day year) corresponding to fixed date.
		  (let* ((year (gregorian-year-from-fixed date))
		         (prior-days; This year
		          (- date (fixed-from-gregorian
		                   (gregorian-date january 1 year))))
		         (correction; To simulate a 30-day Feb
		          (if (< date (fixed-from-gregorian
		                       (gregorian-date march 1 year)))
		              0
		            (if (gregorian-leap-year? year)
		                1
		              2)))
		         (month     ; Assuming a 30-day Feb
		          (quotient
		           (+ ( * 12 (+ prior-days correction)) 373)
		           367))
		         (day       ; Calculate the day by subtraction.
		          (1+ (- date
		                 (fixed-from-gregorian
		                  (gregorian-date month 1 year))))))
		    (gregorian-date month day year)))
		-*/
	public void fromFixed(int date) {
		year = yearFromFixed(date);
		int priorDays = date - toFixed(JANUARY, 1, year);
		int correction = date < toFixed(MARCH, 1, year) ? 0 :
			(isLeapYear(year) ? 1 : 2);
		month = quotient(12 * (priorDays + correction) + 373, 367);
		day = date - toFixed(month, 1, year) + 1;
	}
	
	//
	// support methods
	//

		/*-
		(defun gregorian-leap-year? (g-year)
		  ;; TYPE gregorian-year -> boolean
		  ;; True if year is a leap year on the Gregorian calendar.
		  (and (= (mod g-year 4) 0)
		       (not (member (mod g-year 400)
		                    (list 100 200 300)))))
		-*/
	public static boolean isLeapYear(int year) {
		boolean result = false;
		
		if(mod(year, 4) == 0) {
			int n = mod(year, 400);
			if(n != 100 && n != 200 && n != 300)
				result = true;
		}
		
		return result;
	}

		/*-
		(defun gregorian-year-from-fixed (date)
		  ;; TYPE fixed-date -> gregorian-year
		  ;; Gregorian year corresponding to the fixed date.
		  (let* ((d0        ; Prior days.
		          (- date gregorian-epoch))
		         (n400      ; Completed 400-year cycles.
		          (quotient d0 146097))
		         (d1        ; Prior days not in n400.
		          (mod d0 146097))
		         (n100      ; 100-year cycles not in n400.
		          (quotient d1 36524))
		         (d2        ; Prior days not in n400 or n100.
		          (mod d1 36524))
		         (n4        ; 4-year cycles not in n400 or n100.
		          (quotient d2 1461))
		         (d3        ; Prior days not in n400, n100, or n4.
		          (mod d2 1461))
		         (n1        ; Years not in n400, n100, or n4.
		          (quotient d3 365))
		         (d4        ; Prior days not in n400, n100, n4, or n1.
		          (1+ (mod d3 365)))
		         (year (+ ( * 400 n400)
		                  ( * 100 n100)
		                  ( * 4 n4)
		                  n1)))
		    (if (or (= n100 4) (= n1 4))
		        year      ; Date is December 31 in year.
		      (1+ year)))); Date is ordinal day (1+ d4) in (1+ year).
		-*/
	public static int yearFromFixed(int date) {
		int d0 = date - EPOCH;
		int n400 = quotient(d0, 146097);
		int d1 = mod(d0, 146097);
		int n100 = quotient(d1, 36524);
		int d2 = mod(d1, 36524);
		int n4 = quotient(d2, 1461);
		int d3 = mod(d2, 1461);
		int n1 = quotient(d3, 365);
		int d4 = mod(d3, 365) + 1;
		int year = 400 * n400 + 100 * n100 + 4 * n4 + n1;
		return n100 == 4 || n1 == 4 ? year : year + 1;
	}
	
	//
	// auxiliary methods
	//

		/*-
		(defun day-number (g-date)
		  ;; TYPE gregorian-date -> non-negative-integer
		  ;; Day number in year of Gregorian date g-date.
		  (gregorian-date-difference
		   (gregorian-date december 31 (1- (standard-year g-date)))
		   g-date))
		-*/
	public int dayNumber() {
		return difference(toFixed(DECEMBER, 31, year - 1), toFixed());
	}

		/*-
		(defun days-remaining (g-date)
		  ;; TYPE gregorian-date -> non-negative-integer
		  ;; Days remaining in year after Gregorian date g-date.
		  (gregorian-date-difference
		   g-date
		   (gregorian-date december 31 (standard-year g-date))))
		-*/
	public int daysRemaining() {
		return difference(toFixed(), toFixed(DECEMBER, 31, year));
	}

		/*-
		(defun independence-day (year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of American Independence Day in
		  ;; Gregorian year.
		  (fixed-from-gregorian (gregorian-date july 4 year)))
		-*/
	public static int independenceDay(int year) {
		return toFixed(JULY, 4, year);
	}

		/*-
		(defun labor-day (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of American Labor Day in Gregorian
		  ;; year--the first Monday in September.
		  (nth-kday first monday (gregorian-date september 1 g-year)))
		-*/
	public static int laborDay(int year) {
		return nthKDay(FIRST, MONDAY, toFixed(SEPTEMBER, 1, year));
	}

		/*-
		(defun memorial-day (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of American Memorial Day in Gregorian
		  ;; year--the last Monday in May.
		  (nth-kday last monday (gregorian-date may 31 g-year)))
		-*/
	public static int memorialDay(int year) {
		return nthKDay(LAST, MONDAY, toFixed(MAY, 31, year));
	}

		/*-
		(defun election-day (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of American Election Day in Gregorian
		  ;; year--the Tuesday after the first Monday in November.
		  (nth-kday first tuesday (gregorian-date november 2 g-year)))
		-*/
	public static int electionDay(int year) {
		return nthKDay(FIRST, TUESDAY, toFixed(NOVEMBER, 2, year));
	}

		/*-
		(defun daylight-savings-start (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of the start of American daylight savings
		  ;; time in Gregorian year--the first Sunday in April.
		  (nth-kday first sunday (gregorian-date april 1 g-year)))
		-*/
	public static int daylightSavingsStart(int year) {
		return nthKDay(FIRST, SUNDAY, toFixed(APRIL, 1, year));
	}
	
		/*-
		(defun daylight-savings-end (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of the end of American daylight savings time
		  ;; in Gregorian year--the last Sunday in October.
		  (nth-kday last sunday (gregorian-date october 31 g-year)))
		-*/
	public static int daylightSavingsEnd(int year) {
		return nthKDay(LAST, SUNDAY, toFixed(OCTOBER, 31, year));
	}

		/*-
		(defun christmas (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Christmas in Gregorian year.
		  (fixed-from-gregorian (gregorian-date december 25 g-year)))
		-*/
	public static int christmas(int year) {
		return toFixed(DECEMBER, 25, year);
	}

		/*-
		(defun advent (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Advent in Gregorian year.
		  (kday-nearest (fixed-from-gregorian
		                 (gregorian-date november 30 g-year))
		                sunday))
		-*/
	public static int advent(int year) {
		return kDayNearest(toFixed(NOVEMBER, 30, year), SUNDAY);
	}

		/*-
		(defun epiphany (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Epiphany in Gregorian year.
		  (+ 12 (christmas (1- g-year))))
		-*/
	public static int epiphany(int year) {
		return christmas(year - 1) + 12;
	}

	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Gregorian))
			return false;
		
		return internalEquals(obj);
	}
}
