package calendrica;


public class HinduSolar extends StandardDate {

	//
	// constructors
	//

	public HinduSolar() { }
	
	public HinduSolar(int date) {
		super(date);
	}
	
	public HinduSolar(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public HinduSolar(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant hindu-sidereal-year
		  ;; TYPE rational
		  ;; Mean length of Hindu sidereal year.
		  (+ 365 279457/1080000))
		-*/
	public static final double SIDEREAL_YEAR = 365 + 279457d/1080000;
	
		/*-
		(defconstant hindu-creation
		  ;; TYPE integer
		  ;; Days from creation to onset of Hindu epoch.
		  ( * 1955880000 hindu-sidereal-year))
		-*/
	public static final double CREATION = 1955880000 * SIDEREAL_YEAR;

		/*-
		(defconstant hindu-anomalistic-year
		  ;; TYPE rational
		  ;; Time from aphelion to aphelion.
		  (/ 1577917828000 (- 4320000000 387)))
		-*/
	public static final double ANOMALISTIC_YEAR = 1577917828000d / (4320000000d - 387);

		/*-
		(defconstant hindu-solar-era
		  ;; TYPE standard-year
		  ;; Years from Kali Yuga until Saka era.
		  3179)
		-*/
	public static final int SOLAR_ERA = 3179;

	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-hindu-solar (s-date)
		  ;; TYPE hindu-solar-date -> fixed-date
		  ;; Fixed date corresponding to Hindu solar date s-date
		  ;; (Saka era).  Returns bogus for nonexistent date.
		  (let* ((month (standard-month s-date))
		         (day (standard-day s-date))
		         (year (standard-year s-date))
		         (approx; Approximate date from below
		                ; by adding days...
		          (floor
		           (+ ( * (+ year hindu-solar-era ; in months...
		                    (/ (1- month) 12))
		                 hindu-sidereal-year)    ; ... and years
		              hindu-epoch   ; and days before fixed date 0.
		              day -9))); Potential discrepancy of mean date.
		         (try (+ approx ; Search forward to correct date,
		                 (sum 1 i approx; or just past it.
		                      (hindu-solar-precedes?
		                       (hindu-solar-from-fixed i)
		                       s-date)))))
		    (if (equal (hindu-solar-from-fixed try) s-date)
		        try
		      bogus))); Date nonexistent on Hindu solar calendar.
		-*/
	public static int toFixed(int month, int day, int year)
		throws BogusDateException
	{
		return new HinduSolar(month, day, year).toFixed();
	}

	public int toFixed()
		throws BogusDateException
	{
		int approx = (int)Math.floor((year + SOLAR_ERA + (month - 1) / 12) * SIDEREAL_YEAR + OldHinduSolar.EPOCH + day - 9);
		int aTry;
		HinduSolar tryDate;
		for(aTry = approx; precedes(tryDate = new HinduSolar(aTry), this); aTry++);
		int result;
		if(tryDate.equals(this))
			result = aTry;
		else
			throw new BogusDateException();
		
		return result;
	}
	
		/*-
		(defun hindu-solar-from-fixed (date)
		  ;; TYPE fixed-date -> hindu-solar-date
		  ;; Hindu solar date equivalent to fixed date.
		  (let* ((ky-time (hindu-day-count date)) ; Hindu date KY.
		         (rise    ; Sunrise on Hindu date.
		          (hindu-sunrise ky-time))
		         (month (hindu-zodiac rise))
		         (year (- (hindu-calendar-year rise)
		                  hindu-solar-era))
		         (approx ; 3 days before start of mean month.
		          (- ky-time 3
		             (quotient (mod (hindu-solar-longitude rise)
		                            1800)
		                       60)))
		         (begin (+ approx ; Search forward for beginning...
		                   (sum 1 i approx ; ... of month.
		                        (/= (hindu-zodiac (hindu-sunrise i))
		                            month))))
		         (day (- ky-time begin -1)))
		    (gregorian-date month day year)))
		-*/
	public void fromFixed(int date) {
		int kyTime = OldHinduSolar.dayCount(date);
		double rise = sunrise(kyTime);
		month = zodiac(rise);
		year = calendarYear(rise) - SOLAR_ERA;
		int approx = kyTime - 3 - quotient(mod(solarLongitude(rise), 1800), 60);
		int begin;
		for(begin = approx; zodiac(sunrise(begin)) != month; begin++);
		day = kyTime - begin + 1;
	}
	
	//
	// support methods
	//

		/*-
		(defun hindu-sine-table (entry)
		  ;; TYPE integer -> arcminute
		  ;; This simulates the Hindu sine table.
		  ;; entry is an angle given as a multiplier of 225'.
		  (let* ((exact ( * 3438 (sin-degrees ( * entry 225/60))))
		         (error ( * 0.215 (signum exact)
		                   (signum (- (abs exact) 1716)))))
		    (round (+ exact error))))
		-*/
	public static double hinduSineTable(int entry) {
		double exact = 3438 * sinDegrees(entry * 225d/60);
		double error = 0.215 * signum(exact) * signum(Math.abs(exact) - 1716);
		return Math.round(exact + error);
	}
	
		/*-
		(defun hindu-sine (theta)
		  ;; TYPE arcminute -> [-3438:3438]
		  ;; theta is in minutes of arc.
		  ;; Linear interpolation in Hindu table is used.
		  (let* ((entry (/ theta 225)) ; Interpolate in table.
		         (fraction (mod entry 1)))
		    (+ ( * fraction
		          (hindu-sine-table (ceiling entry)))
		       ( * (- 1 fraction)
		          (hindu-sine-table (floor entry))))))
		-*/
	public static double hinduSine(double theta) {
		double entry = theta / 225;
		double fraction = mod(entry, 1);
		return fraction * hinduSineTable((int)Math.ceil(entry)) +
			(1 - fraction) * hinduSineTable((int)Math.floor(entry));
	}

		/*-
		(defun hindu-arcsin (units)
		  ;; TYPE [-3438:3438] -> arcminute
		  ;; Inverse of Hindu sine function.
		  (if (< units 0) (- (hindu-arcsin (- units)))
		    (let* ((pos (sum 1 k 0 (> units (hindu-sine-table k))))
		           (val ; Lower value in table.
		            (hindu-sine-table (1- pos))))
		      ( * 225 (+ pos -1  ; Interpolate.
		                (/ (- units val)
		                   (- (hindu-sine-table pos) val)))))))
		-*/
	public static double hinduArcsin(double units) {
		boolean neg = units < 0;
		if(neg)
			units = -units;
			
		int pos = 0;
		for(; units > hinduSineTable(pos); pos++);
		double val = hinduSineTable(pos - 1);
		double result = 225 * (pos - 1 + (units - val) / (hinduSineTable(pos) - val));
		
		if(neg)
			result = -result;
		
		return result;
	}

		/*-
		(defun mean-position (ky-time period)
		  ;; TYPE (hindu-moment rational) -> arcminute
		  ;; Position in minutes of arc at ky-time
		  ;; in uniform circular orbit of period days.
		  ( * 21600 (mod (/ ky-time period) 1)))
		-*/
	public static double meanPosition(double kyTime, double period) {
		return 21600 * mod(kyTime / period, 1);
	}

		/*-
		(defun true-position (ky-time period size anomalistic change)
		  ;; TYPE (hindu-moment rational positive-real rational
		  ;; TYPE  non-negative-real) -> arcminute
		  ;; Longitudinal position (in arcminutes) at ky-time since
		  ;; Hindu epoch. period is period of mean motion.  size is
		  ;; ratio of radii of epicycle and deferent.  anomalistic
		  ;; is the period of retrograde revolution about epicycle.
		  ;; change is maximum decrease in epicycle size.
		  (let* ((long ; Position of epicycle center
		          (mean-position ky-time period))
		         (days (+ ky-time hindu-creation)) ; since creation
		         (offset ; Sine of anomaly
		          (hindu-sine (mean-position days anomalistic)))
		         (contraction ( * (abs offset) change size 1/3438))
		         (equation ; Equation of center
		          (hindu-arcsin ( * offset (- size contraction)))))
		    (mod (- long equation) 21600)))
		-*/
	public static double truePosition(double kyTime, double period, double size, double anomalistic, double change) {
		double aLong = meanPosition(kyTime, period);
		double days = kyTime + CREATION;
		double offset = hinduSine(meanPosition(days, anomalistic));
		double contraction = Math.abs(offset) * change * size * 1d/3438;
		double equation = hinduArcsin(offset * (size - contraction));
		return mod(aLong - equation, 21600);
	}
	
		/*-
		(defun hindu-solar-longitude (ky-time)
		  ;; TYPE hindu-moment -> arcminute
		  ;; Solar longitude in arcminutes at ky-time since epoch.
		  (true-position ky-time hindu-sidereal-year
		                 14/360 hindu-anomalistic-year 1/42))
		-*/
	public static double solarLongitude(double kyTime) {
		return truePosition(kyTime, SIDEREAL_YEAR, 14d/360, ANOMALISTIC_YEAR, 1d/42);
	}

		/*-
		(defun hindu-zodiac (ky-time)
		  ;; TYPE hindu-moment -> hindu-solar-month
		  ;; Zodiacal sign of the sun, as integer in range 1..12,
		  ;; at ky-time.
		  (1+ (quotient (hindu-solar-longitude ky-time) 1800)))
		-*/
	public static int zodiac(double kyTime) {
		return quotient(solarLongitude(kyTime), 1800) + 1;
	}

		/*-
		(defun hindu-solar-precedes? (s-date1 s-date2)
		  ;; TYPE (hindu-solar-date hindu-solar-date) -> boolean
		  ;; True if Hindu solar s-date1 precedes s-date2.
		  (let* ((month1 (standard-month s-date1))
		         (month2 (standard-month s-date2))
		         (day1 (standard-day s-date1))
		         (day2 (standard-day s-date2))
		         (year1 (standard-year s-date1))
		         (year2 (standard-year s-date2)))
		    (or (< year1 year2)
		        (and (= year1 year2)
		             (or (< month1 month2)
		                 (and (= month1 month2)
		                      (< day1 day2)))))))
		-*/
	public static boolean precedes(HinduSolar d1, HinduSolar d2) {
		return d1.year < d2.year || d1.year == d2.year && (d1.month < d2.month || d1.month == d2.month && d1.day < d2.day);
	}
	
		/*-
		(defun hindu-calendar-year (ky-time)
		  ;; TYPE hindu-moment -> hindu-solar-year
		  ;; Determine solar year at given time ky-time since Hindu
		  ;; epoch.
		  (let* ((mean; Mean solar longitude (arcminutes) at ky-time.
		          ( * 21600 (mod (/ ky-time hindu-sidereal-year) 1)))
		         (real; True longitude.
		          (hindu-solar-longitude ky-time))
		         (year; Mean year.
		          (quotient ky-time hindu-sidereal-year)))
		    (cond ((> real 20000 1000 mean); Really previous year.
		           (1- year))
		          ((> mean 20000 1000 real); Really next year.
		           (1+ year))
		          (t year))))
		-*/
	public static int calendarYear(double kyTime) {
		double mean = 21600 * mod(kyTime / SIDEREAL_YEAR, 1);
		double real = solarLongitude(kyTime);
		int year = quotient(kyTime, SIDEREAL_YEAR);
		if(real > 20000 && 1000 > mean)
			return year - 1;
		else if(mean > 20000 && 1000 > real)
			return year + 1;
		else
			return year;
	}
	
		/*-
		(defun hindu-equation-of-time (ky-time)
		  ;; TYPE hindu-moment -> hindu-moment
		  ;; Time from mean to true midnight.
		  ;; (This is a gross approximation to the correct value.)
		  (let* ((offset (hindu-sine (mean-position
		                              (+ hindu-creation ky-time)
		                              hindu-anomalistic-year)))
		         (equation-sun ; Sun's equation of center
		              ; Arcsin is not needed since small
		          ( * offset (- (/ (abs offset) 3713040) 14/360))))
		    ( * (daily-motion ky-time) equation-sun
		       hindu-sidereal-year 1/21600 1/21600)))
		-*/
	public static double equationOfTime(double kyTime) {
		double offset = hinduSine(meanPosition(CREATION + kyTime, ANOMALISTIC_YEAR));
		double equationSun = offset * (Math.abs(offset) / 3713040 - 14d/360);
		return dailyMotion(kyTime) * equationSun * SIDEREAL_YEAR * 1d/21600 * 1d/21600;
	}

		/*-
		(defun ascensional-difference (ky-time latitude)
		  ;; TYPE (hindu-moment arcminute) -> arcminute
		  ;; Difference between right and oblique ascension
		  ;; of sun (in arcminutes) at ky-time at latitude
		  ;; (in arcminutes).
		  (let* ((sin-decl
		          ( * 1397/3438
		             (hindu-sine (tropical-longitude ky-time))))
		         (diurnal-radius
		          (hindu-sine (- 5400 (hindu-arcsin sin-decl))))
		         (tan ; Tangent of latitude as rational number.
		          (/ (hindu-sine latitude)
		             (hindu-sine (+ 5400 latitude))))
		         (earth-sine ( * sin-decl tan)))
		    (hindu-arcsin ( * -3438 (/ earth-sine diurnal-radius)))))
		-*/
	public static double ascensionalDifference(double kyTime, double latitude) {
		double sinDecl = 1397d/3438 * hinduSine(tropicalLongitude(kyTime));
		double diurnalRadius = hinduSine(5400 - hinduArcsin(sinDecl));
		double tan = hinduSine(latitude) / hinduSine(5400 + latitude);
		double earthSine = sinDecl * tan;
		return hinduArcsin(-3438 * earthSine / diurnalRadius);
	}
	
		/*-
		(defun tropical-longitude (ky-time)
		  ;; TYPE hindu-moment -> arcminute
		  ;; Hindu tropical longitude at ky-time days since epoch.
		  ;; Assumes precession with maximum of 27 degrees (1620
		  ;; minutes) and period of 7200 sidereal years (=
		  ;; 1577917828/600 days).
		  (let* ((midnight (floor ky-time)) ; Whole days.
		         (precession
		          (- 1620
		             (abs (- 1620
		                     (mod ( * 6480 600/1577917828 midnight)
		                          6480))))))
		    (mod (- (hindu-solar-longitude ky-time) precession)
		         21600)))
		-*/
	public static double tropicalLongitude(double kyTime) {
		double midnight = Math.floor(kyTime);
		double precession = 1620 - Math.abs(1620 - mod(6480 * 600d/1577917828d * midnight, 6480));
		return mod(solarLongitude(kyTime) - precession, 21600);
	}
	
		/*-
		(defun rising-sign (ky-time)
		  ;; TYPE hindu-moment -> integer
		  ;; Tabulated speed of rising of current zodiacal sign.
		  (nth (mod (quotient (tropical-longitude ky-time) 1800) 6)
		       (list 1670 1795 1935 1935 1795 1670)))
		-*/
	public static int risingSign(double kyTime) {
		int index = mod(quotient(tropicalLongitude(kyTime), 1800), 6);
		return rs[index];
	}
	private static final short[] rs = new short[] {1670, 1795, 1935, 1935, 1795, 1670};

		/*-
		(defun daily-motion (ky-time)
		  ;; TYPE hindu-moment -> arcminute
		  ;; Sidereal daily motion (in arcminutes) of sun at ky-time.
		  (let* ((mean-motion ; mean daily motion in arcminutes.
		          (/ 21600 hindu-sidereal-year))
		         (anomaly (mean-position
		                   (+ hindu-creation ky-time)
		                   hindu-anomalistic-year))
		         (epicycle ; Current size of epicycle
		          (- 14/360 (/ (abs (hindu-sine anomaly)) 3713040)))
		         (entry (quotient anomaly 225))
		         (sine-table-step ; Marginal change in anomaly
		          (- (hindu-sine-table (1+ entry))
		             (hindu-sine-table entry)))
		         (equation-of-motion-factor
		          ( * sine-table-step -1/225 epicycle)))
		    ( * mean-motion (1+ equation-of-motion-factor))))
		-*/
	public static double dailyMotion(double kyTime) {
		double meanMotion = 21600 / SIDEREAL_YEAR;
		double anomaly = meanPosition(CREATION + kyTime, ANOMALISTIC_YEAR);
		double epicycle = 14d/360 - Math.abs(hinduSine(anomaly)) / 3713040;
		int entry = quotient(anomaly, 225);
		double sineTableStep = hinduSineTable(entry + 1) - hinduSineTable(entry);
		double equationOfMotionFactor = sineTableStep * (-1d/225) * epicycle;
		return meanMotion * (equationOfMotionFactor + 1);
	}
	
		/*-
		(defun solar-sidereal-difference (ky-time)
		  ;; TYPE hindu-moment -> arcminute
		  ;; Difference between solar and sidereal day at ky-time.
		  ( * (daily-motion ky-time) (rising-sign ky-time) 1/1800))
		-*/
	public static double solarSiderealDifference(double kyTime) {
		return dailyMotion(kyTime) * risingSign(kyTime) * 1d/1800;
	}

		/*-
		(defun hindu-sunrise (ky-time)
		  ;; TYPE hindu-moment -> hindu-moment
		  ;; Sunrise at Ujjain (latitude 1389 minutes)
		  ;; ky-time (whole) days since Hindu epoch.
		  (+ ky-time 1/4 ; Mean sunrise.
		     (hindu-equation-of-time ky-time) ; Apparent midnight.
		     ( * ; Convert sidereal arcminutes to fraction of civil
		        1577917828/1582237828 1/21600 ; ... day.
		      (+ (ascensional-difference ky-time 1389)
		         (/ (solar-sidereal-difference ky-time) 4)))))
		-*/
	public static double sunrise(double kyTime) {
		return kyTime + 1d/4 + equationOfTime(kyTime) +
			1577917828d/1582237828d * 1d/21600 *
				(ascensionalDifference(kyTime, 1389) + solarSiderealDifference(kyTime) / 4);
	}

	//
	// auxiliary methods
	//

		/*-
		(defun sunrise-at-ujjain (ky-time)
		  ;; TYPE hindu-moment -> hindu-moment
		  ;; Astronomical sunrise at Ujjain (latitude 1389 minutes)
		  ;; on ky-time (whole) days since Hindu epoch.
		  (let* ((d (+ ky-time hindu-epoch))
		         (latitude 1389/60)
		         (longitude 4546/60))
		    (+ ky-time (sunrise d latitude longitude))))
		-*/
	public static double sunriseAtUjjain(int kyTime) {
		int d = kyTime + OldHinduSolar.EPOCH;
		double latitude = 1389d/60;
		double longitude = 4546d/60;
		return kyTime + sunrise(d, latitude, longitude);
	}
	
		/*-
		(defun samkranti (g-year m)
		  ;; TYPE (gregorian-year hindu-solar-month) -> moment
		  ;; Fixed moment of start of m-th solar month
		  ;; of Hindu year beginning in Gregorian g-year.
		  (let* ((diff (+ hindu-solar-era
		                  (standard-year
		                   (gregorian-from-fixed hindu-epoch))))
		         (h-year (- g-year diff)) ; Since K.Y.
		         (ny (- (fixed-from-hindu-solar ; First of month.
		                 (hindu-solar-date m 1 h-year))
		                hindu-epoch))
		         (begin
		          (binary-search ; Search for exact time.
		             start (- ny 7/8)
		             end   (+ ny 3/8)
		             x     (if (= m 1) ; Look for 360-0 break.
		                       (< (hindu-solar-longitude x)
		                          1800)
		                     (>= (hindu-solar-longitude x)
		                         ( * (1- m) 1800)))
		             (>= 1/1000000 (- end start)))))
		    (+ begin hindu-epoch)))
		-*/
	public static double samkranti(int gYear, int m)
		throws BogusDateException
	{
		int diff = SOLAR_ERA + new Gregorian(OldHinduSolar.EPOCH).year;
		int hYear = gYear - diff;
		int ny = HinduSolar.toFixed(m, 1, hYear) - OldHinduSolar.EPOCH;

		double lo = ny - 7d/8, hi = ny + 3d/8, begin = (hi + lo) / 2;
		while(hi - lo >= 1d/10000000) {
			if(m == 1 ? solarLongitude(begin) < 1800 : solarLongitude(begin) >= (m - 1) * 1800)
				hi = begin;
			else
				lo = begin;
			
			begin = (hi + lo) / 2;
		}
		
		return begin + OldHinduSolar.EPOCH;
	}

		/*-
		(defun mesha-samkranti (g-year)
		  ;; TYPE gregorian-year -> moment
		  ;; Fixed moment of Mesha samkranti (Vernal equinox)
		  ;; in Gregorian g-year.
		  (samkranti g-year 1))
		-*/
	public static double meshaSamkranti(int gYear) {
		double result = 0;
		try {
			result = samkranti(gYear, 1);
		} catch(BogusDateException ex) {
			// this should never happen
		}
		return result;
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof HinduSolar))
			return false;
		
		return internalEquals(obj);
	}
}
