package calendrica;


public class BogusDateException extends Exception {
	public BogusDateException() { super(); }
	public BogusDateException(String s) { super(s); }
}
