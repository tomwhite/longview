package calendrica;

	
public class MayanHaab extends ProtoDate {

	//
	// fields
	//

		public int day;
		public int month;

	//
	// constants
	//

		/*-
		(defconstant mayan-haab-at-epoch
		  ;; TYPE mayan-haab-date
		  ;; Haab date at long count 0.0.0.0.0.
		  (mayan-haab-date 8 18))
		-*/
	public static final MayanHaab EPOCH = new MayanHaab(8, 18);

	//
	// constructors
	//

	public MayanHaab() { }
	
	public MayanHaab(int date) {
		super(date);
	}
	
	public MayanHaab(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public MayanHaab(int day, int month) {
		this.day	= day;
		this.month	= month;
	}
	
	//
	// date conversion methods
	//

		/*-
		(defun mayan-haab-from-fixed (date)
		  ;; TYPE fixed-date -> mayan-haab-date
		  ;; Mayan haab date of fixed date.
		  (let* ((long-count (- date mayan-epoch))
		         (day-of-haab
		          (mod (+ long-count
		                  (mayan-haab-day mayan-haab-at-epoch)
		                  ( * 20 (1- (mayan-haab-month
		                             mayan-haab-at-epoch))))
		               365))
		         (day (mod day-of-haab 20))
		         (month (1+ (quotient day-of-haab 20))))
		    (mayan-haab-date day month)))
		-*/
	public void fromFixed(int date) {
		int longCount = date - MayanLongCount.EPOCH;
		int dayOfHaab = mod(longCount + EPOCH.day + 20 * (EPOCH.month - 1), 365);
		day = mod(dayOfHaab, 20);
		month = 1 + quotient(dayOfHaab, 20);
	}
	
	public void fromArray(int[] a) {
		day		= a[0];
		month	= a[1];
	}

	
	//
	// auxiliary methods
	//

		/*-
		(defun mayan-haab-difference (h-date1 h-date2)
		  ;; TYPE (mayan-haab-date mayan-haab-date) -> integer
		  ;; Number of days from Mayan haab date h-date1 to the next
		  ;; occurrence of Mayan haab date h-date2.
		  (let* ((day1 (mayan-haab-day h-date1))
		         (day2 (mayan-haab-day h-date2))
		         (month1 (mayan-haab-month h-date1))
		         (month2 (mayan-haab-month h-date2)))
		    (mod (+ ( * 20 (- month2 month1))
		            (- day2 day1))
		         365)))
		-*/
	public static int difference(MayanHaab date1, MayanHaab date2) {
		return mod(20 * (date2.month - date1.month) + (date2.day - date1.day), 365);
	}
	
		/*-
		(defun mayan-haab-on-or-before (haab date)
		  ;; TYPE (mayan-haab-date fixed-date) -> fixed-date
		  ;; Fixed date of latest date on or before fixed date
		  ;; that is Mayan haab date haab.
		  (- date
		     (mod (- date
		             (mayan-haab-difference
		              (mayan-haab-from-fixed 0) haab))
		          365)))
		-*/
	public static int onOrBefore(MayanHaab haab, int date) {
		return date - mod(date - difference(new MayanHaab(0), haab), 365);
	}
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "day=" + day + ",month=" + month;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof MayanHaab))
			return false;
		
		MayanHaab o = (MayanHaab)obj;
		
		return
			o.day	== day		&&
			o.month	== month	;
	}
}
