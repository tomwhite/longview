package calendrica;


public class French extends StandardDate {

	//
	// constructors
	//

	public French() { }
	
	public French(int date) {
		super(date);
	}
	
	public French(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public French(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//
	
		/*-
		(defconstant french-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the French Revolutionary
		  ;; calendar.
		  (fixed-from-gregorian (gregorian-date september 22 1792)))
		-*/
	public static final int EPOCH = Gregorian.toFixed(SEPTEMBER, 22, 1792);

		/*-
		(defconstant french-time-zone
		  ;; TYPE minute
		  ;; The difference (in minutes) of the Paris time zone
		  ;; from Universal Time.
		  (+ 9 21/60))
		-*/
	public static final double TIME_ZONE = 9 + 21d/60;
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-french (f-date)
		  ;; TYPE french-date -> fixed-date
		  ;; Fixed date of French Revolutionary date.
		  (let* ((month (standard-month f-date))
		         (day (standard-day f-date))
		         (year (standard-year f-date))
		         (new-year
		          (french-autumnal-equinox-on-or-before
		           (ceiling (+ french-epoch
		                       ( * mean-tropical-year
		                          (1- year)))))))
		    (+ (1- new-year)    ;  Days in prior years
		       ( * 30 (1- month));  Days in prior months
		       day)))           ;  Days this month
		-*/
	public static int toFixed(int month, int day, int year) {
		int newYear = autumnalEquinoxOnOrBefore(
			(int)Math.ceil(EPOCH + MEAN_TROPICAL_YEAR * (year - 1)));
		return (newYear - 1) + 30 * (month - 1) + day;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun french-from-fixed (date)
		  ;; TYPE fixed-date -> french-date
		  ;; French Revolutionary date of fixed date.
		  (let* ((new-year
		          (french-autumnal-equinox-on-or-before date))
		         (year (1+ (round (/ (- new-year french-epoch)
		                             mean-tropical-year))))
		         (month (1+ (quotient (- date new-year) 30)))
		         (day (1+ (mod (- date new-year) 30))))
		    (french-date month day year)))
		-*/
	public void fromFixed(int date) {
		int newYear = autumnalEquinoxOnOrBefore(date);
		year = (int)Math.round((newYear - EPOCH) / MEAN_TROPICAL_YEAR) + 1;
		month = quotient(date - newYear, 30) + 1;
		day = mod(date - newYear, 30) + 1;
	}
	
	//
	// support methods
	//

		/*-
		(defun french-autumnal-equinox-on-or-before (date)
		  ;; TYPE fixed-date -> fixed-date
		  ;; Fixed date, in Paris local time, of autumnal equinox
		  ;; on or before fixed date.
		  (let* ((theta; solar longitude at end of date in Paris
		          (solar-longitude
		           (universal-from-local
		            (jd-from-moment (1+ date))
		            french-time-zone)))
		         (d-prime; date shortly before previous autumnal
		                 ; equinox
		          (if (< 150d0 theta 180d0); if date is in August or
		                                   ; in September before the
		                                   ; autumnal equinox...
		              (- date 370); ...then pick a date before the
		                       ; prior autumnal equinox
		            ; ...otherwise, if date is beyond the autumnal
		            ; equinox, pick a date before the last autumnal
		            ; equinox
		            (- date (mod (- date 260) mean-tropical-year)))))
		    (fixed-from-jd
		     (apparent-from-local
		      (local-from-universal
		       (date-next-solar-longitude
		        (universal-from-local
		         (jd-from-moment d-prime)
		         french-time-zone)
		        90)
		       french-time-zone)))))
		-*/
	public static int autumnalEquinoxOnOrBefore(int date) {
		double theta = solarLongitude(universalFromLocal(jdFromMoment(date + 1), TIME_ZONE));
		double dPrime = 150 < theta && theta < 180 ?
			date - 370 :
			date - mod(date - 260, MEAN_TROPICAL_YEAR);
		return fixedFromJD(
			apparentFromLocal(
				localFromUniversal(
					dateNextSolarLongitude(
						universalFromLocal(
							jdFromMoment(dPrime),
						TIME_ZONE),
					90),
				TIME_ZONE)
			)
		);
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof French))
			return false;
		
		return internalEquals(obj);
	}
}
