package calendrica;


public class Julian extends StandardDate {

	//
	// constants
	//

		/*-
		(defconstant julian-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Julian calendar.
		  (fixed-from-gregorian (gregorian-date december 30 0)))
		-*/
	public static final int EPOCH = Gregorian.toFixed(DECEMBER, 30, 0);

	//
	// constructors
	//

	public Julian() { }
	
	public Julian(int date) {
		super(date);
	}
	
	public Julian(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Julian(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// date conversion methods
	//

		/*-
		(defun fixed-from-julian (j-date)
		  ;; TYPE julian-date -> fixed-date
		  ;; Fixed date equivalent to the Julian date.
		  (let* ((month (standard-month j-date))
		         (day (standard-day j-date))
		         (year (standard-year j-date))
		         (y (if (< year 0)
		                (1+ year) ; No year zero
		              year)))
		    (+ (1- julian-epoch)  ; Days before start of calendar
		       ( * 365 (1- y))     ; Ordinary days since epoch.
		       (quotient (1- y) 4); Leap days since epoch...
		       (quotient          ; Days in prior months this year...
		        (- ( * 367 month) 362); ...assuming 30-day Feb
		        12)
		       (if (<= month 2)   ; Correct for 28- or 29-day Feb
		           0
		         (if (julian-leap-year? year)
		             -1
		           -2))
		       day)))             ; Days so far this month.
		-*/
	public static int toFixed(int month, int day, int year) {
		int y = year < 0 ? year + 1 : year;
		return EPOCH - 1
			+ 365 * (y - 1)
			+ quotient(y - 1, 4)
			+ quotient(367 * month - 362, 12)
			+ (month <= 2 ? 0 :
				(isLeapYear(year) ? -1 : -2))
			+ day;
	}
	
	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun julian-from-fixed (date)
		  ;; TYPE fixed-date -> julian-date
		  ;; Julian (month day year) corresponding to fixed date.
		  (let* ((approx      ; Nominal year.
		          (quotient (+ ( * 4 (- date julian-epoch)) 1464)
		                    1461))
		         (year (if (<= approx 0)
		                   (1- approx) ; No year 0.
		                 approx))
		         (prior-days; This year
		          (- date (fixed-from-julian
		                   (julian-date january 1 year))))
		         (correction; To simulate a 30-day Feb
		          (if (< date (fixed-from-julian
		                       (julian-date march 1 year)))
		              0
		            (if (julian-leap-year? year)
		                1
		              2)))
		         (month     ; Assuming a 30-day Feb
		          (quotient
		           (+ ( * 12 (+ prior-days correction)) 373)
		           367))
		         (day       ; Calculate the day by subtraction.
		          (1+ (- date
		                 (fixed-from-julian
		                  (julian-date month 1 year))))))
		    (julian-date month day year)))
		-*/
	public void fromFixed(int date) {
		int approx = quotient(4 * (date - EPOCH) + 1464, 1461);
		year = approx <= 0 ? approx - 1 : approx;
		int priorDays = date - toFixed(JANUARY, 1, year);
		int correction = date < toFixed(MARCH, 1, year) ? 0 : (isLeapYear(year) ? 1 : 2);
		month = quotient(12 * (priorDays + correction) + 373, 367);
		day = date - toFixed(month, 1, year) + 1;
	}
	
	//
	// support methods
	//

		/*-
		(defun bce (n)
		  ;; TYPE standard-year -> julian-year
		  ;; Negative value to indicate a BCE Julian year.
		  (- n))
		-*/

	public static int BCE(int n) {
		return -n;
	}

		/*-
		(defun ce (n)
		  ;; TYPE standard-year -> julian-year
		  ;; Positive value to indicate a CE Julian year.
		  n)
		-*/
	public static int CE(int n) {
		return n;
	}

		/*-
		(defun julian-leap-year? (j-year)
		  ;; TYPE julian-year -> boolean
		  ;; True if year is a leap year on the Julian calendar.
		  (= (mod j-year 4) (if (> j-year 0) 0 3)))
		-*/
	public static boolean isLeapYear(int jYear) {
		return mod(jYear, 4) == (jYear > 0 ? 0 : 3);
	}
	
	//
	// auxiliary methods
	//

		/*-
		(defun nicaean-rule-easter (j-year)
		  ;; TYPE julian-year -> fixed-date
		  ;; Fixed date of Easter in positive Julian year, according
		  ;; to the rule of the Council of Nicaea.
		  (let* ((shifted-epact ; Age of moon for April 5.
		          (mod (+ 14 ( * 11 (mod j-year 19)))
		               30))
		         (paschal-moon  ; Day after full moon on
		                        ; or after March 21.
		          (- (fixed-from-julian (julian-date april 19 j-year))
		             shifted-epact)))
		    ;; Return the Sunday following the Paschal moon
		    (kday-after paschal-moon sunday)))
		-*/
	public static int nicaeanRuleEaster(int jYear) {
		int shiftedEpact = mod(14 + 11 * mod(jYear, 19), 30);
		int paschalMoon = toFixed(APRIL, 19, jYear) - shiftedEpact;
		return kDayAfter(paschalMoon, SUNDAY);
	}

		/*-
		(defun easter (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Easter in Gregorian year.
		  (let* ((century (1+ (quotient g-year 100)))
		         (shifted-epact        ; Age of moon for April 5...
		          (mod
		           (+ 14 ( * 11 (mod g-year 19));   ...by Nicaean rule
		              (- ;...corrected for the Gregorian century rule
		               (quotient ( * 3 century) 4))
		              (quotient; ...corrected for Metonic
		                       ; cycle inaccuracy.
		               (+ 5 ( * 8 century)) 25))
		           30))
		         (adjusted-epact       ;  Adjust for 29.5 day month.
		          (if (or (= shifted-epact 0)
		                  (and (= shifted-epact 1)
		                       (< 10 (mod g-year 19))))
		              (1+ shifted-epact)
		            shifted-epact))
		         (paschal-moon; Day after full moon on
		                      ; or after March 21.
		          (- (fixed-from-gregorian
		              (gregorian-date april 19 g-year))
		             adjusted-epact)))
		    ;; Return the Sunday following the Paschal moon.
		    (kday-after paschal-moon sunday)))
		-*/
	public static int easter(int gYear) {
		int century = 1 + quotient(gYear, 100);
		int shiftedEpact = mod(14
								+ 11 * mod(gYear, 19)
								- quotient(3 * century, 4)
								+ quotient(5 + 8 * century, 25),
							30);
		int adjustedEpact = shiftedEpact == 0 || (shiftedEpact == 1 && 10 < mod(gYear, 19)) ?
			shiftedEpact + 1 :
			shiftedEpact;
		int paschalMoon = Gregorian.toFixed(APRIL, 19, gYear) - adjustedEpact;
		return kDayAfter(paschalMoon, SUNDAY);
	}

		/*-
		(defun pentecost (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Pentecost in Gregorian year.
		  (+ (easter g-year) 49))
		-*/
	public static int pentecost(int gYear) {
		return easter(gYear) + 49;
	}

		/*-
		(defun julian-in-gregorian (j-month j-day g-year)
		  ;; TYPE (julian-month julian-day gregorian-year)
		  ;; TYPE -> list-of-fixed-dates
		  ;; List of the fixed dates of Julian month, day
		  ;; that occur in Gregorian year.
		  (let* ((jan1 (fixed-from-gregorian
		                (gregorian-date january 1 g-year)))
		         (dec31 (fixed-from-gregorian
		                 (gregorian-date december 31 g-year)))
		         (y (standard-year (julian-from-fixed jan1)))
		         ;; The possible occurrences in one year are
		         (date1 (fixed-from-julian
		                 (julian-date j-month j-day y)))
		         (date2 (fixed-from-julian
		                 (julian-date j-month j-day (1+ y)))))
		    (append
		     (if ; date1 occurs in current year
		         (<= jan1 date1 dec31)
		         ;; Then that date; otherwise, none
		         (list date1) nil)
		     (if ; date2 occurs in current year
		         (<= jan1 date2 dec31)
		         ;; Then that date; otherwise, none
		         (list date2) nil))))
		-*/
	public static FixedVector inGregorian(int jMonth, int jDay, int gYear) {
		int jan1 = Gregorian.toFixed(JANUARY, 1, gYear);
		int dec31 = Gregorian.toFixed(DECEMBER, 31, gYear);
		int y = new Julian(jan1).year;
		int date1 = toFixed(jMonth, jDay, y);
		int date2 = toFixed(jMonth, jDay, y + 1);
		FixedVector result = new FixedVector(1, 1);
		if(jan1 <= date1 && date1 <= dec31)
			result.addFixed(date1);
		if(jan1 <= date2 && date2 <= dec31)
			result.addFixed(date2);
		return result;
	}

		/*-
		(defun eastern-orthodox-christmas (g-year)
		  ;; TYPE gregorian-year -> list-of-fixed-dates
		  ;; List of zero or one fixed dates of Eastern Orthodox
		  ;; Christmas in Gregorian year.
		  (julian-in-gregorian december 25 g-year))
		-*/
	public static FixedVector easternOrthodoxChristmas(int gYear) {
		return inGregorian(DECEMBER, 25, gYear);
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Julian))
			return false;
		
		return internalEquals(obj);
	}
}
