package calendrica;


public class HinduLunar extends Date {
	
	//
	// fields
	//

	public int		month;
	public boolean	leapMonth;
	public int		day;
	public boolean	leapDay;
	public int		year;

	//
	// constructors
	//

	public HinduLunar() { }
	
	public HinduLunar(int date) {
		super(date);
	}
	
	public HinduLunar(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public HinduLunar(int month, boolean leapMonth, int day, boolean leapDay, int year) {
		this.month		= month;
		this.leapMonth	= leapMonth;
		this.day		= day;
		this.leapDay	= leapDay;
		this.year		= year;
	}
	
	//
	// constants
	//

		/*-
		(defconstant hindu-lunar-era
		  ;; TYPE standard-year
		  ;; Years from Kali Yuga until Vikrama era
		  3044)
		-*/
	public static final int LUNAR_ERA = 3044;

		/*-
		(defconstant hindu-synodic-month
		  ;; TYPE rational
		  ;; Mean time from new moon to new moon.
		  (+ 29 7087771/13358334))
		-*/
	public static final double SYNODIC_MONTH = 29 + 7087771d/13358334;

		/*-
		(defconstant hindu-sidereal-month
		  ;; TYPE rational
		  ;; Mean length of Hindu sidereal month.
		  (+ 27 4644439/14438334))
		-*/
	public static final double SIDEREAL_MONTH = 27 + 4644439d/14438334;

		/*-
		(defconstant hindu-anomalistic-month
		  ;; TYPE rational
		  ;; Time from apogee to apogee, with bija correction.
		  (/ 1577917828 (- 57753336 488199)))
		-*/
	public static final double ANOMALISTIC_MONTH = 1577917828d / (57753336 - 488199);
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-hindu-lunar (l-date)
		  ;; TYPE hindu-lunar-date -> fixed-date
		  ;; Fixed date corresponding to Hindu lunar date l-date;
		  ;; returns bogus if no such date exists.
		  (let* ((year (hindu-lunar-year l-date))
		         (month (hindu-lunar-month l-date))
		         (leap (hindu-lunar-leap-month l-date))
		         (leap-day (hindu-lunar-leap-day l-date))
		         (day (hindu-lunar-day l-date))
		         (ky-year (+ year hindu-lunar-era))
		         (mean; Approximate date.
		           (fixed-from-old-hindu-lunar
		            (old-hindu-lunar-date month leap day ky-year)))
		          (approx; Check if one month off either way.
		          (cond ((hindu-lunar-precedes?
		                  (hindu-lunar-from-fixed (+ mean 15))
		                  l-date)
		                 (+ mean hindu-synodic-month))
		                ((hindu-lunar-precedes?
		                  l-date
		                  (hindu-lunar-from-fixed (- mean 15)))
		                 (- mean hindu-synodic-month))
		                (t mean)))
		          (try ; Search for correct date
		              ;  or just before or after it.
		          (floor (binary-search
		                  l (- approx 4)
		                  u (+ approx 4)
		                  d (not (hindu-lunar-precedes?
		                          (hindu-lunar-from-fixed (floor d))
		                          l-date))
		                  (<= (- u l) 2)))))
		    (cond ((equal (hindu-lunar-from-fixed try) l-date)
		           try)
		          ((equal (hindu-lunar-from-fixed (1+ try)) l-date)
		           (1+ try))
		          ((equal (hindu-lunar-from-fixed (1- try)) l-date)
		           (1- try))
		          (t bogus)))); Nonexistent Hindu lunar calendar date.
		-*/
	public static int toFixed(int month, boolean leapMonth, int day, boolean leapDay, int year)
		throws BogusDateException
	{
		return new HinduLunar(month, leapMonth, day, leapDay, year).toFixed();
	}

	public int toFixed()
		throws BogusDateException
	{
		int kyYear = year + LUNAR_ERA;
		int mean = OldHinduLunar.toFixed(month, leapMonth, day, kyYear);
		double approx;
		if(precedes(new HinduLunar(mean + 15), this))
			approx = mean + SYNODIC_MONTH;
		else if(precedes(this, new HinduLunar(mean - 15)))
			approx = mean - SYNODIC_MONTH;
		else
			approx = mean;
		
		double lo = approx - 4, hi = approx + 4, d = (lo + hi) / 2;
		while(!(hi - lo <= 2)) {
			if(!precedes(new HinduLunar((int)Math.floor(d)), this))
				hi = d;
			else
				lo = d;

			d = (lo + hi) / 2;
		}
		int aTry = (int)Math.floor(d);

		int result;
		if(new HinduLunar(aTry).equals(this))
			result = aTry;
		else if(new HinduLunar(aTry + 1).equals(this))
			result = aTry + 1;
		else if(new HinduLunar(aTry - 1).equals(this))
			result = aTry - 1;
		else
			throw new BogusDateException();
		
		return result;
	}
	
		/*-
		(defun hindu-lunar-from-fixed (date)
		  ;; TYPE fixed-date -> hindu-lunar-date
		  ;; Hindu lunar date equivalent to fixed date.
		  (let* ((ky-time (hindu-day-count date))   ; Hindu date.
		         (rise (hindu-sunrise ky-time)) ; Sunrise that day.
		         (day (lunar-day rise)); Day of month.
		         (leapday             ; If previous day the same.
		          (= day (lunar-day (hindu-sunrise (1- ky-time)))))
		         (last-new-moon (hindu-new-moon rise))
		         (next-new-moon
		          (hindu-new-moon (+ (floor last-new-moon) 35)))
		         (solar-month         ; Solar month name.
		          (hindu-zodiac last-new-moon))
		         (leapmonth       ; If begins and ends in same sign.
		          (= solar-month (hindu-zodiac next-new-moon)))
		         (month                     ; Month of lunar year.
		          (adjusted-mod (1+ solar-month) 12))
		         (year ; Solar year at next new moon.
		          (- (hindu-calendar-year next-new-moon)
		             hindu-lunar-era ; Era
		             ;; If month is leap, it belongs to next month's
		             ;; year.
		             (if (and leapmonth (= month 1)) -1 0))))
		    (hindu-lunar-date month leapmonth day leapday year)))
		-*/
	public void fromFixed(int date) {
		int kyTime = OldHinduSolar.dayCount(date);
		double rise = HinduSolar.sunrise(kyTime);
		day = lunarDay(rise);
		leapDay = day == lunarDay(HinduSolar.sunrise(kyTime - 1));
		double lastNewMoon = newMoon(rise);
		double nextNewMoon = newMoon(Math.floor(lastNewMoon) + 35);
		int solarMonth = HinduSolar.zodiac(lastNewMoon);
		leapMonth = solarMonth == HinduSolar.zodiac(nextNewMoon);
		month = adjustedMod(solarMonth + 1, 12);
		year = HinduSolar.calendarYear(nextNewMoon) -
			LUNAR_ERA -
			(leapMonth && month == 1 ? -1 : 0);
	}
	
	public void fromArray(int[] a) {
		this.month		= a[0];
		this.leapMonth	= a[1] != 0;
		this.day		= a[2];
		this.leapDay	= a[3] != 0;
		this.year		= a[4];
	}
	
	//
	// support methods
	//
	
		/*-
		(defun hindu-new-moon (ky-time)
		  ;; TYPE hindu-moment -> hindu-moment
		  ;; Last new moon preceding ky-time since epoch.
		  (let* ((tomorrow (1+ ky-time))
		         (estimate  ; Can be off by 2/3 day.
		          (- tomorrow (mod tomorrow hindu-synodic-month)))
		         (try (binary-search ; Search for phase start.
		               l (- estimate 2/3)
		               u (+ estimate 2/3)
		               x (< (hindu-lunar-phase x) 10800)
		               (or (< ky-time l) ; Wrong new moon
		                   (and (<= u ky-time)
		                        (= (hindu-zodiac l)
		                           (hindu-zodiac u)))))))
		    (if (> try ky-time); Check whether before/after ky-time.
		        (hindu-new-moon ; It's previous month.
		         (- (floor ky-time) 20))
		      try)))
		-*/
	/* RECURSIVE */
	public static double newMoon(double kyTime) {
		double tomorrow = kyTime + 1;
		double estimate = tomorrow - mod(tomorrow, SYNODIC_MONTH);
		double lo = estimate - 2d/3, hi = estimate + 2d/3, aTry = (hi + lo) / 2;
		while(!(kyTime < lo || (hi <= kyTime && HinduSolar.zodiac(lo) == HinduSolar.zodiac(hi)))) {
			if(lunarPhase(aTry) < 10800)
				hi = aTry;
			else
				lo = aTry;
			
			aTry = (hi + lo) / 2;
		}
		return aTry > kyTime ?
			newMoon(Math.floor(kyTime) - 20) :
			aTry;
	}

		/*-
		(defun hindu-lunar-precedes? (l-date1 l-date2)
		  ;; TYPE (hindu-lunar-date hindu-lunar-date) -> boolean
		  ;; True if Hindu lunar l-date1 precedes l-date2.
		  (let* ((month1 (hindu-lunar-month l-date1))
		         (month2 (hindu-lunar-month l-date2))
		         (leap1 (hindu-lunar-leap-month l-date1))
		         (leap2 (hindu-lunar-leap-month l-date2))
		         (day1 (hindu-lunar-day l-date1))
		         (day2 (hindu-lunar-day l-date2))
		         (leapday1 (hindu-lunar-leap-day l-date1))
		         (leapday2 (hindu-lunar-leap-day l-date2))
		         (year1 (hindu-lunar-year l-date1))
		         (year2 (hindu-lunar-year l-date2)))
		    (or (< year1 year2)
		        (and (= year1 year2)
		             (or (< month1 month2)
		                 (and (= month1 month2)
		                      (or (and leap1 (not leap2))
		                          (and (equal leap1 leap2)
		                               (or (< day1 day2)
		                                   (and (= day1 day2)
		                                        (not leapday1)
		                                        leapday2))))))))))
		-*/
	public static boolean precedes(HinduLunar d1, HinduLunar d2) {
		return d1.year < d2.year || d1.year == d2.year && (d1.month < d2.month || 
			d1.month == d2.month && (d1.leapMonth && !d2.leapMonth || 
				d1.leapMonth == d2.leapMonth && (d1.day < d2.day || d1.day == d2.day && !d1.leapDay && d2.leapDay)));
	}
	
		/*-
		(defun lunar-day-start (ky-time k accuracy)
		  ;; TYPE (hindu-moment rational real) -> hindu-moment
		  ;; Time lunar-day (tithi) number k begins before or at
		  ;; ky-time in days since onset of Hindu epoch.  k can be
		  ;; fractional (for karanas).  accuracy is in fraction of
		  ;; (civil) day.
		  (let* ((tomorrow (1+ ky-time))
		         (part ; Mean time from start of month.
		          ( * (1- k) 1/30 hindu-synodic-month))
		         (estimate ; Mean occurrence of lunar-day.
		          (- tomorrow (mod (- tomorrow part)
		                           hindu-synodic-month)))
		         (try (binary-search ; Search for phase.
		               l (- estimate 2/3)
		               u (+ estimate 2/3)
		               x (let* ((diff-x (- (hindu-lunar-phase x)
		                                 ( * (1- k) 720))))
		                   (or (< 0 diff-x 10800) ; Past the lunar-day
		                       (< diff-x -10800)))  ; Over the edge
		               (or (< ky-time l) (< (- u l) accuracy)))))
		    (if (> try ky-time) ; Too late.
		        (lunar-day-start  ; Previous month.
		         (- ky-time 20) k accuracy)
		      try)))
		-*/
	/* RECURSIVE */
	public static double lunarDayStart(double kyTime, double k, double accuracy) {
		double tomorrow = kyTime + 1;
		double part = (k - 1) * 1d/30 * SYNODIC_MONTH;
		double estimate = tomorrow - mod(tomorrow - part, SYNODIC_MONTH);
		double lo = estimate - 2d/3, hi = estimate + 2d/3, aTry = (hi + lo) / 2;
		while(!(kyTime < lo || (hi - lo) < accuracy)) {
			double diffX = lunarPhase(aTry) - (k - 1) * 720;
			if(0 < diffX && diffX < 10800 || diffX < -10800)
				hi = aTry;
			else
				lo = aTry;
			
			aTry = (hi + lo) / 2;
		}
		return aTry > kyTime ?
			lunarDayStart(kyTime - 20, k, accuracy) :
			aTry;
	}
	
		/*-
		(defun hindu-lunar-longitude (ky-time)
		  ;; TYPE hindu-moment -> arcminute
		  ;; Lunar longitude in arcminutes at ky-time.
		  (true-position ky-time hindu-sidereal-month
		                 32/360 hindu-anomalistic-month 1/42))
		-*/
	public static double lunarLongitude(double kyTime) {
		return HinduSolar.truePosition(kyTime, SIDEREAL_MONTH, 32d/360, ANOMALISTIC_MONTH, 1d/42);
	}

		/*-
		(defun hindu-lunar-phase (ky-time)
		  ;; TYPE hindu-moment -> arcminute
		  ;; Longitudinal distance between the sun and moon
		  ;; in arcminutes at ky-time since Hindu epoch.
		  (mod (- (hindu-lunar-longitude ky-time)
		          (hindu-solar-longitude ky-time))
		       21600))
		-*/
	public static double lunarPhase(double kyTime) {
		return mod(lunarLongitude(kyTime) - HinduSolar.solarLongitude(kyTime), 21600);
	}

		/*-
		(defun lunar-day (ky-time)
		  ;; TYPE hindu-moment -> hindu-lunar-day
		  ;; Phase of moon (tithi) at ky-time,
		  ;; as an integer in the range 1..30.
		  (1+ (quotient (hindu-lunar-phase ky-time) 720)))
		-*/
	public static int lunarDay(double kyTime) {
		return quotient(lunarPhase(kyTime), 720) + 1;
	}

	//
	// auxiliary methods
	//

		/*-
		(defun lunar-mansion (date)
		  ;; TYPE fixed-date -> positive-integer
		  ;; Hindu lunar mansion (nakshatra) at sunrise on fixed date.
		  (let* ((rise (hindu-sunrise (hindu-day-count date))))
		    (1+ (quotient (hindu-lunar-longitude rise) 800))))
		-*/
	public static int lunarMansion(int date) {
		double rise = HinduSolar.sunrise(OldHinduSolar.dayCount(date));
		return quotient(lunarLongitude(rise), 800) + 1;
	}
	
		/*-
		(defun hindu-lunar-new-year (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Hindu luni-solar new year
		  ;; in Gregorian g-year.
		  (let* ((mesha ; Moment of vernal equinox.
		          (mesha-samkranti g-year))
		         (m1 ; Prior new moon.
		          (lunar-day-start (hindu-day-count mesha)
		                           1 1/100000))
		         (m0 ; New moon before that.
		          (lunar-day-start (- m1 27) 1 1/100000))
		         (new-moon ; First new moon of year.
		          (if ; leap month...
		              (= (hindu-zodiac m0) (hindu-zodiac m1))
		              m0 m1))
		         (h-day (floor new-moon))
		         (rise ; Sunrise that day.
		          (hindu-sunrise h-day)))
		    (+ hindu-epoch h-day
		       ;; Next day if new moon after sunrise,
		       ;; unless lunar day ends before next sunrise.
		       (if (or (< new-moon rise)
		               (= (lunar-day 
		                   (hindu-sunrise (1+ h-day))) 2))
		           0 1))))
		-*/
	public static int newYear(int gYear) {
		double mesha = HinduSolar.meshaSamkranti(gYear);
		double m1 = lunarDayStart(OldHinduSolar.dayCount(mesha), 1, 1d/100000);
		double m0 = lunarDayStart(m1 - 27, 1, 1d/100000);
		double aNewMoon = HinduSolar.zodiac(m0) == HinduSolar.zodiac(m1) ? m0 : m1;
		int hDay = (int)Math.floor(aNewMoon);
		double rise = HinduSolar.sunrise(hDay);
		return OldHinduSolar.EPOCH + hDay +
			(aNewMoon < rise || lunarDay(HinduSolar.sunrise(hDay + 1)) == 2 ? 0 : 1);
	}
	
		/*-
		(defun karana (n)
		  ;; TYPE {1-60} -> {0-10}
		  ;; Number (0-10) of the name of the n-th (1-60) Hindu karana.
		  (cond ((= n 1) 0)
		        ((> n 57) (- n 50))
		        (t (adjusted-mod (1- n) 7))))
		-*/
	public static int karana(int n) {
		if(n == 1)
			return 0;
		else if(n > 57)
			return n - 50;
		else
			return adjustedMod(n - 1, 7);
	}

		/*-
		(defun yoga (ky-time)
		  ;; TYPE hindu-moment -> {1-27}
		  ;; Hindu yoga at ky-time days since Hindu epoch.
		  (1+ (floor (mod (/ (+ (hindu-solar-longitude ky-time)
		                        (hindu-lunar-longitude ky-time))
		                     800)
		                  27))))
		-*/
	public static int yoga(double kyTime) {
		return (int)Math.floor(
			mod((HinduSolar.solarLongitude(kyTime) +
				lunarLongitude(kyTime)) / 800, 27)
		) + 1;
	}

		/*-
		(defun sacred-wednesdays-in-gregorian (g-year)
		  ;; TYPE gregorian-year -> list-of-fixed-dates
		  ;; List of Wednesdays in Gregorian year g-year
		  ;; that are day 8 of Hindu lunar months.
		  (sacred-wednesdays
		   (fixed-from-gregorian ; From beginning of year.
		    (gregorian-date january 1 g-year))
		   (fixed-from-gregorian ; To end.
		    (gregorian-date december 31 g-year))))
		-*/
	public static FixedVector sacredWednesdaysInGregorian(int gYear) {
		return sacredWednesdays(
			Gregorian.toFixed(JANUARY, 1, gYear),
			Gregorian.toFixed(DECEMBER, 31, gYear)
		);
	}

		/*-
		(defun sacred-wednesdays (start end)
		  ;; TYPE (fixed-date fixed-date) -> list-of-fixed-dates
		  ;; List of Wednesdays between fixed dates start and end
		  ;; (inclusive) that are day 8 of Hindu lunar months.
		  (if (> start end)
		      nil
		    (let* ((wed (kday-on-or-after start wednesday))
		           (h-date (hindu-lunar-from-fixed wed)))
		      (append
		       (if (= (hindu-lunar-day h-date) 8)
		           (list wed)
		         nil)
		       (sacred-wednesdays (1+ wed) end)))))
		-*/
	public static FixedVector sacredWednesdays(int start, int end) {
		int wed = kDayOnOrAfter(start, WEDNESDAY);
		FixedVector result = new FixedVector();
		while(wed <= end) {
			HinduLunar hDate = new HinduLunar(wed);
			if(hDate.day == 8)
				result.addFixed(wed);
			wed += 7;
		}
		return result;
	}

	//
	// object methods
	//

	protected String toStringFields() {
		return "month=" + month + ",leapMonth=" + leapMonth + ",day=" + day +
			",leapDay=" + leapDay + ",year=" + year;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof HinduLunar))
			return false;
		
		HinduLunar o = (HinduLunar)obj;
		
		return
			o.month		== month		&&
			o.leapMonth	== leapMonth	&&
			o.day		== day			&&
			o.leapDay	== leapDay		&&
			o.year		== year			;
	}
}
