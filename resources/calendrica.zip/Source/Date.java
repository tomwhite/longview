package calendrica;


public abstract class Date extends ProtoDate {

	//
	// constructors
	//
	
	public Date() { }
	
	public Date(int date) {
		super(date);
	}
	
	public Date(Date date)
		throws BogusDateException
	{
		super(date);
	}

	//	
	// date conversion methods
	//

	public abstract int toFixed()
		throws BogusDateException;
	
	public void convertTo(ProtoDate toDate)
		throws BogusDateException
	{
		convert(this, toDate);
	}
}
