package calendrica;


public class OldHinduSolar extends StandardDate {

	//
	// constructors
	//

	public OldHinduSolar() { }
	
	public OldHinduSolar(int date) {
		super(date);
	}
	
	public OldHinduSolar(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public OldHinduSolar(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant hindu-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Hindu calendar (Kali Yuga).
		  (fixed-from-julian (julian-date february 18 (bce 3102))))
		-*/
	public static final int EPOCH = Julian.toFixed(FEBRUARY, 18, Julian.BCE(3102));

		/*-
		(defconstant arya-sidereal-year
		  ;; TYPE rational
		  ;; Length of Old Hindu solar year.
		  1577917500/4320000)
		-*/
	public static final double ARYA_SIDEREAL_YEAR = 1577917500d/4320000;

		/*-
		(defconstant arya-solar-month
		  ;; TYPE rational
		  ;; Length of Old Hindu solar month.
		  (/ arya-sidereal-year 12))
		-*/
	public static final double ARYA_SOLAR_MONTH = ARYA_SIDEREAL_YEAR / 12;

		/*-
		(defconstant arya-jovian-period
		  ;; TYPE rational
		  ;; Number of days in one revolution of Jupiter around the
		  ;; Sun.
		  1577917500/364224)
		-*/
	public static final double ARYA_JOVIAN_PERIOD = 1577917500d/364224;
	
	//
	// date conversion methods
	//
	
	public static int toFixed(int month, int day, int year) {
		return (int)Math.floor(
			EPOCH +
			year * ARYA_SIDEREAL_YEAR +
			(month - 1) * ARYA_SOLAR_MONTH +
			day - 1d/4
		);
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun old-hindu-solar-from-fixed (date)
		  ;; TYPE fixed-date -> hindu-solar-date
		  ;; Old Hindu solar date equivalent to fixed date.
		  (let* ((rise ; Sunrise on Hindu date.
		          (+ (hindu-day-count date) 1/4))
		         (year    ; Elapsed years.
		          (quotient rise arya-sidereal-year))
		         (month (1+ (mod (quotient rise arya-solar-month)
		                         12)))
		         (day (1+ (floor (mod rise arya-solar-month)))))
		    (hindu-solar-date month day year)))
		-*/
	public void fromFixed(int date) {
		double rise = dayCount(date) + 1d/4;
		year = quotient(rise, ARYA_SIDEREAL_YEAR);
		month = 1 + mod(quotient(rise, ARYA_SOLAR_MONTH), 12);
		day = 1 + (int)Math.floor(mod(rise, ARYA_SOLAR_MONTH));
	}
	
	//
	// support methods
	//

		/*-
		(defun hindu-day-count (hindu-moment)
		  ;; TYPE hindu-moment -> hindu-moment
		  ;; Elapsed days (Ahargana) to date since Hindu epoch (K.Y.).
		  (- date hindu-epoch))
		-*/
	public static int dayCount(int date) {
		return date - EPOCH;
	}
	
	public static double dayCount(double date) {
		return date - EPOCH;
	}
	
	//
	// auxiliary methods
	//

		/*-
		(defun jovian-year (date)
		  ;; TYPE fixed-date -> {1-60}
		  ;; Year of Jupiter cycle at fixed date.
		  (1+ (mod (quotient (hindu-day-count date)
		                     (/ arya-jovian-period 12))
		           60)))
		-*/
	public static int jovianYear(int date) {
		return mod(quotient(dayCount(date), ARYA_JOVIAN_PERIOD / 12), 60) + 1;
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof OldHinduSolar))
			return false;
		
		return internalEquals(obj);
	}
}
