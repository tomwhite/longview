package calendrica;


public class Hebrew extends StandardDate {
	//
	// constructors
	//

	public Hebrew() { }
	
	public Hebrew(int date) {
		super(date);
	}
	
	public Hebrew(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Hebrew(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant hebrew-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Hebrew calendar, that is,
		  ;; Tishri 1, 1 AM.
		  (fixed-from-julian (julian-date october 7 (bce 3761))))
		-*/
	public static final int EPOCH = Julian.toFixed(OCTOBER, 7, Julian.BCE(3761));
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-hebrew (h-date)
		  ;; TYPE hebrew-date -> fixed-date
		  ;; Fixed date of Hebrew date.  This function is designed
		  ;; so that it works for Hebrew dates month, day, year even
		  ;; if the month has fewer than day days--in that case the
		  ;; function returns the (day-1)st day after month 1, year.
		  ;; This property is required by the functions
		  ;; hebrew-birthday and yahrzeit.
		  (let* ((month (standard-month h-date))
		         (day (standard-day h-date))
		         (year (standard-year h-date)))
		    (+ hebrew-epoch         ; Days before fixed date 1.
		       (hebrew-calendar-elapsed-days; Days in prior years.
		        year)
		       (hebrew-new-year-delay year)
		       day -1               ; Days so far this month.
		       (if ;; before Tishri
		           (< month 7)
		           ;; Then add days in prior months this year before
		           ;; and after Nisan.
		           (+ (sum (last-day-of-hebrew-month m year)
		                   m 7 (<= m (last-month-of-hebrew-year year)))
		              (sum (last-day-of-hebrew-month m year)
		                   m 1 (< m month)))
		         ;; Else add days in prior months this year
		         (sum (last-day-of-hebrew-month m year)
		              m 7 (< m month))))))
		-*/
	public static int toFixed(int month, int day, int year) {
		int date = EPOCH
			+ calendarElapsedDays(year)
			+ newYearDelay(year)
			+ day - 1;
		
		if(month < 7) {
			for(int m = 7; m <= lastMonthOfYear(year); m++)
				date += lastDayOfMonth(m, year);

			for(int m = 1; m < month; m++)
				date += lastDayOfMonth(m, year);

		} else {
			for(int m = 7; m < month; m++)
				date += lastDayOfMonth(m, year);
		}
		
		return date;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun hebrew-from-fixed (date)
		  ;; TYPE fixed-date -> hebrew-date
		  ;; Hebrew (month day year) corresponding to fixed date.
		  ;; The fraction can be approximated by 365.25.
		  (let* ((approx    ; Approximate year (may be off by 1)
		          (quotient (- date hebrew-epoch) 35975351/98496))
		         ;; The value 35975351/98496, the average length of
		         ;; a Hebrew year, can be approximated by 365.25
		         (year      ; Search forward.
		          (+ approx -1 ; Lower bound.
		             (sum 1 y approx
		                  (>= date
		                      (fixed-from-hebrew
		                       (hebrew-date 7 1 y))))))
		         (start     ; Starting month for search for month.
		          (if (< date (fixed-from-hebrew
		                       (hebrew-date 1 1 year)))
		              7 ; Tishri
		            1)) ; Nisan
		         (month ; Search forward from either Tishri or Nisan.
		          (+ start
		             (sum 1 m start
		                  (> date
		                     (fixed-from-hebrew
		                      (hebrew-date m
		                            (last-day-of-hebrew-month m year)
		                            year))))))
		         (day   ; Calculate the day by subtraction.
		          (1+ (- date (fixed-from-hebrew
		                       (hebrew-date month 1 year))))))
		    (hebrew-date month day year)))
		-*/

	public void fromFixed(final int date) {
		int approx = quotient(date - EPOCH, 35975351d/98496);
		year = approx - 1;
		for(int y = approx; date >= toFixed(7, 1, y); y++)
			year++;

		int start = date < toFixed(1, 1, year) ? 7 : 1;
		month = start;
		for(int m = start; date > toFixed(m, lastDayOfMonth(m, year), year); m++)
			month++;

		day = 1 + date - toFixed(month, 1, year);
	}
	
	//
	// support methods
	//

		/*-
		(defun hebrew-leap-year? (h-year)
		  ;; TYPE hebrew-year -> boolean
		  ;; True if year is a leap year on Hebrew calendar.
		  (< (mod (1+ ( * 7 h-year)) 19) 7))
		-*/
	public static boolean isLeapYear(int hYear) {
		return mod(1 + 7 * hYear, 19) < 7;
	}

		/*-
		(defun last-month-of-hebrew-year (h-year)
		  ;; TYPE hebrew-year -> hebrew-month
		  ;; Last month of Hebrew year.
		  (if (hebrew-leap-year? h-year)
		      13
		    12))
		-*/
	public static int lastMonthOfYear(int hYear) {
		return isLeapYear(hYear) ? 13 : 12;
	}

		/*-
		(defun last-day-of-hebrew-month (h-month h-year)
		  ;; TYPE (hebrew-month hebrew-year) -> hebrew-day
		  ;; Last day of month in Hebrew year.
		  (if (or (member h-month (list 2 4 6 10 13))
		          (and (= h-month 12)
		               (not (hebrew-leap-year? h-year)))
		          (and (= h-month 8) (not (long-heshvan? h-year)))
		          (and (= h-month 9) (short-kislev? h-year)))
		      29
		    30))
		-*/
	public static int lastDayOfMonth(int hMonth, int hYear) {
		return ( (hMonth == 2 || hMonth == 4 || hMonth == 6 || hMonth == 10 || hMonth == 13)
			|| (hMonth == 12 && !isLeapYear(hYear))
			|| (hMonth == 8 && !hasLongHeshvan(hYear))
			|| (hMonth == 9 && hasShortKislev(hYear)) ) ? 29 : 30;
	}

		/*-
		(defun hebrew-calendar-elapsed-days (h-year)
		  ;; TYPE hebrew-year -> integer
		  ;; Number of days elapsed from the (Sunday) noon prior
		  ;; to the epoch of the Hebrew calendar to the mean
		  ;; conjunction (molad) of Tishri of Hebrew year h-year,
		  ;; or one day later.
		  (let* ((months-elapsed  ; Since start of Hebrew calendar.
		          (quotient (- ( * 235 h-year) 234) 19))
		         (parts-elapsed; Fractions of days since prior noon.
		          (+ 12084 ( * 13753 months-elapsed)))
		         (day  ; Whole days since prior noon.
		          (+ ( * 29 months-elapsed)
		             (quotient parts-elapsed 25920)))
		      ;; If ( * 13753 months-elapsed) causes integers that 
		      ;; are to large, use instead:
		      ;; (parts-elapsed
		      ;;  (+ 204 ( * 793 (mod months-elapsed 1080))))
		      ;; (hours-elapsed
		      ;;  (+ 11 ( * 12 months-elapsed)
		      ;;     ( * 793 (quotient months-elapsed 1080))
		      ;;     (quotient parts-elapsed 1080)))
		      ;; (day                
		      ;;  (+ ( * 29 months-elapsed)
		      ;;     (quotient hours-elapsed 24)))
		         )
		    (if (< (mod ( * 3 (1+ day)) 7) 3); Sun, Wed, or Fri
		        (1+ day) ; Delay one day.
		      day)))
		-*/
	public static int calendarElapsedDays(int hYear) {
		int monthsElapsed = quotient(235 * hYear - 234, 19);
		double partsElapsed = 12084 + 13753d * monthsElapsed;
		int day = 29 * monthsElapsed + quotient(partsElapsed, 25920);
		return mod(3 * (day + 1), 7) < 3 ? day + 1 : day;
	}

		/*-
		(defun hebrew-new-year-delay (h-year)
		  ;; TYPE hebrew-year -> {0,1,2}
		  ;; Delays to start of Hebrew year to keep ordinary year in
		  ;; range 353-356 and leap year in range 383-386.
		  (let* ((ny0 (hebrew-calendar-elapsed-days (1- h-year)))
		         (ny1 (hebrew-calendar-elapsed-days h-year))
		         (ny2 (hebrew-calendar-elapsed-days (1+ h-year))))
		    (cond
		     ((= (- ny2 ny1) 356) 2); Next year would be too long.
		     ((= (- ny1 ny0) 382) 1); Previous year too short.
		     (t 0))))
		-*/
	public static int newYearDelay(int hYear) {
		int ny0 = calendarElapsedDays(hYear - 1);
		int ny1 = calendarElapsedDays(hYear);
		int ny2 = calendarElapsedDays(hYear + 1);
		if(ny2 - ny1 == 356)
			return 2;
		else if(ny1 - ny0 == 382)
			return 1;
		else
			return 0;
	}

		/*-
		(defun days-in-hebrew-year (h-year)
		  ;; TYPE hebrew-year -> {353,354,355,383,384,385}
		  ;; Number of days in Hebrew year.  Calls fixed-from-hebrew
		  ;; for value that does not in turn require
		  ;; days-in-hebrew-year.
		  (- (fixed-from-hebrew (hebrew-date 7 1 (1+ h-year)))
		     (fixed-from-hebrew (hebrew-date 7 1 h-year))))
		-*/
	public static int daysInYear(int hYear) {
		return toFixed(7, 1, hYear + 1) - toFixed(7, 1, hYear);
	}

		/*-
		(defun long-heshvan? (h-year)
		  ;; TYPE hebrew-year -> boolean
		  ;; True if Heshvan is long in Hebrew year.
		  (= (mod (days-in-hebrew-year h-year) 10) 5))
		-*/
	public static boolean hasLongHeshvan(int hYear) {
		return mod(daysInYear(hYear), 10) == 5;
	}

		/*-
		(defun short-kislev? (h-year)
		  ;; TYPE hebrew-year -> boolean
		  ;; True if Kislev is short in Hebrew year.
		  (= (mod (days-in-hebrew-year h-year) 10) 3))
		-*/
	public static boolean hasShortKislev(int hYear) {
		return mod(daysInYear(hYear), 10) == 3;
	}

	//
	// auxiliary methods
	//

		/*-
		(defun yom-kippur (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Yom Kippur occurring in Gregorian year.
		  (let* ((hebrew-year
		          (1+ (- g-year
		                 (gregorian-year-from-fixed
		                  hebrew-epoch)))))
		    (fixed-from-hebrew (hebrew-date 7 10 hebrew-year))))
		-*/
	public static int yomKippur(int gYear) {
		int hYear = 1 + gYear - Gregorian.yearFromFixed(EPOCH);
		return toFixed(7, 10, hYear);
	}

		/*-
		(defun passover (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Passover occurring in Gregorian year.
		  (let* ((hebrew-year
		          (- g-year
		             (gregorian-year-from-fixed hebrew-epoch))))
		    (fixed-from-hebrew (hebrew-date 1 15 hebrew-year))))
		-*/
	public static int passover(int gYear) {
		int hYear = gYear - Gregorian.yearFromFixed(EPOCH);
		return toFixed(1, 15, hYear);
	}

		/*-
		(defun omer (date)
		  ;; TYPE fixed-date -> omer-count
		  ;; Number of elapsed weeks and days in the omer at date.
		  ;; Returns bogus if that date does not fall during the
		  ;; omer.
		  (let* ((c (- date
		               (fixed-from-hebrew
		                (hebrew-date
		                 1 15 (standard-year
		                       (hebrew-from-fixed date)))))))
		    (if (<= 1 c 49)
		        (list (quotient c 7) (mod c 7))
		      bogus)))
		-*/
	public static int[] omer(int date)
		throws BogusDateException
	{
		int[] result;
		
		int c = date - toFixed(1, 15, new Hebrew(date).year);
		if(1 <= c && c <= 49)
			result = new int[] {quotient(c, 7), mod(c, 7)};
		else
			throw new BogusDateException();
		
		return result;
	}
	
		/*-
		(defun purim (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Purim occurring in Gregorian year.
		  (let* ((hebrew-year
		          (- g-year
		             (gregorian-year-from-fixed hebrew-epoch)))
		         (last-month  ; Adar or Adar II
		          (last-month-of-hebrew-year hebrew-year)))
		    (fixed-from-hebrew
		     (hebrew-date last-month 14 hebrew-year))))
		-*/
	public static int purim(int gYear) {
		int hYear = gYear - Gregorian.yearFromFixed(EPOCH);
		int lastMonth = lastMonthOfYear(hYear);
		return toFixed(lastMonth, 14, hYear);
	}

		/*-
		(defun ta-anith-esther (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Ta'anith Esther occurring in
		  ;; Gregorian year.
		  (let* ((purim-date (purim g-year)))
		    (if ; Purim is on Sunday
		        (= (day-of-week-from-fixed purim-date) sunday)
		        ;; Then prior Thursday
		        (- purim-date 3)
		      ;; Else previous day
		      (1- purim-date))))
		-*/
	public static int taAnithEsther(int gYear) {
		int purimDate = purim(gYear);
		return dayOfWeekFromFixed(purimDate) == SUNDAY ? purimDate - 3 : purimDate - 1;
	}
	
		/*-
		(defun tisha-b-av (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Tisha B'Av occurring in Gregorian year.
		  (let* ((hebrew-year
		          (- g-year
		             (gregorian-year-from-fixed hebrew-epoch)))
		         (ninth-of-av
		          (fixed-from-hebrew
		           (hebrew-date 5 9 hebrew-year))))
		    (if ; Ninth of Av is Saturday
		        (= (day-of-week-from-fixed ninth-of-av) saturday)
		        ;; Then the next day
		        (1+ ninth-of-av)
		      ninth-of-av)))
		-*/
	public static int tishBAv(int gYear) {
		int hYear = gYear - Gregorian.yearFromFixed(EPOCH);
		int ninthOfAv = toFixed(5, 9, hYear);
		return dayOfWeekFromFixed(ninthOfAv) == SATURDAY ? ninthOfAv + 1 : ninthOfAv;
	}

		/*-
		(defun birkath-ha-hama (g-year)
		  ;; TYPE gregorian-year -> list-of-fixed-dates
		  ;; List of fixed date of Birkath HaHama occurring in
		  ;; Gregorian year, if it occurs.
		  (let* ((mar26 (julian-in-gregorian
		                 march 26 g-year)))
		    (if (and (not (equal mar26 nil))
		             (= (mod (standard-year
		                      (julian-from-fixed (first mar26)))
		                     28)
		                21))
		        mar26
		      nil)))
		-*/
	public static FixedVector birkathHaHama(int gYear) {
		FixedVector mar26 = Julian.inGregorian(MARCH, 26, gYear);
		if(mar26.size() != 0 && mod(new Julian(mar26.fixedAt(0)).year, 28) == 21)
			return mar26;
		else
			return new FixedVector();
	}

		/*-
		(defun sh-ela (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Sh'ela occurring in Gregorian year.
		  (- (first (julian-in-gregorian march 26 (1+ g-year)))
		     124))
		-*/
	public static int shEla(int gYear) {
		return Julian.inGregorian(MARCH, 26, gYear + 1).fixedAt(0) - 124;
	}
	
		/*-
		(defun yom-ha-zikaron (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Yom HaZikaron occurring in Gregorian year.
		  (let* ((hebrew-year
		          (- g-year
		             (gregorian-year-from-fixed hebrew-epoch)))
		         (h; Ordinarily Iyar 4
		          (fixed-from-hebrew
		           (hebrew-date 2 4 hebrew-year))))
		    (if (< wednesday (day-of-week-from-fixed h))
		        ;; But prior Wednesday if Iyar 5 is Friday or
		        ;; Saturday
		        (kday-before h wednesday)
		      h)))
		-*/
	public static int yomHaZikaron(int gYear) {
		int hYear = gYear - Gregorian.yearFromFixed(EPOCH);
		int h = toFixed(2, 4, hYear);
		return WEDNESDAY < dayOfWeekFromFixed(h) ? kDayBefore(h, WEDNESDAY) : h;
	}
	
		/*-
		(defun hebrew-birthday (birthdate h-year)
		  ;; TYPE (hebrew-date hebrew-year) -> fixed-date
		  ;; Fixed date of the anniversary of Hebrew birthdate
		  ;; occurring in Hebrew year.  This function assumes
		  ;; that the function fixed-from-hebrew works for Hebrew
		  ;; dates month, day, year even if the month has fewer than
		  ;; day days--in that case the function returns the
		  ;; (day-1)st day after month 1, year.
		  (let* ((birth-day (standard-day birthdate))
		         (birth-month (standard-month birthdate))
		         (birth-year (standard-year birthdate)))
		    (if ; It's Adar in a normal Hebrew year or Adar II
		        ; in a Hebrew leap year,
		        (= birth-month (last-month-of-hebrew-year birth-year))
		        ;; Then use the same day in last month of Hebrew year.
		        (fixed-from-hebrew
		         (hebrew-date (last-month-of-hebrew-year h-year)
		                      birth-day
		                      h-year))
		      ;; Else use the normal anniversary of the birth date,
		      ;; or the corresponding day in years without that date
		      (fixed-from-hebrew
		       (hebrew-date birth-month birth-day h-year)))))
		-*/
	public static int birthday(Hebrew birthDate, int hYear) {
		return birthDate.month == lastMonthOfYear(birthDate.year) ?
			toFixed(lastMonthOfYear(hYear), birthDate.day, hYear) :
			toFixed(birthDate.month, birthDate.day, hYear);
	}
	
		/*-
		(defun yahrzeit (death-date h-year)
		  ;; TYPE (hebrew-date hebrew-year) -> fixed-date
		  ;; Fixed date of the anniversary of Hebrew death-date
		  ;; occurring in Hebrew year.  This function assumes
		  ;; that the function fixed-from-hebrew works for Hebrew
		  ;; dates month, day, year even if the month has fewer than
		  ;; day days--in that case the function returns the
		  ;; (day-1)st day after month 1, year.
		  (let* ((death-day (standard-day death-date))
		         (death-month (standard-month death-date))
		         (death-year (standard-year death-date)))
		    (cond
		     ;; If it's Heshvan 30 it depends on the first
		     ;; anniversary; if that was not Heshvan 30, use
		     ;; the day before Kislev 1.
		     ((and (= death-month 8)
		           (= death-day 30)
		           (not (long-heshvan? (1+ death-year))))
		      (1- (fixed-from-hebrew
		           (hebrew-date 9 1 h-year))))
		     ;; If it's Kislev 30 it depends on the first
		     ;; anniversary; if that was not Kislev 30, use
		     ;; the day before Teveth 1.
		     ((and (= death-month 9)
		           (= death-day 30)
		           (short-kislev? (1+ death-year)))
		      (1- (fixed-from-hebrew
		           (hebrew-date 10 1 h-year))))
		     ;; If it's Adar II, use the same day in last
		     ;; month of Hebrew year (Adar or Adar II).
		     ((= death-month 13)
		      (fixed-from-hebrew
		       (hebrew-date (last-month-of-hebrew-year h-year)
		             death-day
		             h-year)))
		     ;; If it's the 30th in Adar I and Hebrew year is not a
		     ;; Hebrew leap year (so Adar has only 29 days), use the
		     ;; last day in Shevat.
		     ((and (= death-day 30)
		           (= death-month 12)
		           (not (hebrew-leap-year? h-year)))
		      (fixed-from-hebrew (hebrew-date 11 30 h-year)))
		     ;; In all other cases, use the normal anniversary of
		     ;; the date of death.
		     (t (fixed-from-hebrew
		         (hebrew-date death-month death-day h-year))))))
		-*/
	public static int yahrzeit(Hebrew deathDate, int hYear) {
		int result;
		
		if(deathDate.month == 8 && deathDate.day == 30 && !hasLongHeshvan(deathDate.year + 1))
			result = toFixed(9, 1, hYear) - 1;
		else if(deathDate.month == 9 && deathDate.day == 30 && hasShortKislev(deathDate.year + 1))
			result = toFixed(10, 1, hYear) - 1;
		else if(deathDate.month == 13)
			result = toFixed(lastMonthOfYear(hYear), deathDate.day, hYear);
		else if(deathDate.day == 30 && deathDate.month == 12 && !isLeapYear(hYear))
			result = toFixed(11, 30, hYear);
		else
			result = toFixed(deathDate.month, deathDate.day, hYear);
	
		return result;
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Hebrew))
			return false;
		
		return internalEquals(obj);
	}
}
