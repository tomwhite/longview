package calendrica;


public class Persian extends StandardDate {

	//
	// constructors
	//

	public Persian() { }
	
	public Persian(int date) {
		super(date);
	}
	
	public Persian(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Persian(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//

		/*-
		(defconstant persian-epoch
		  ;; TYPE fixed-date
		  ;; Fixed date of start of the Persian calendar.
		  (fixed-from-julian (julian-date march 19 (ce 622))))
		-*/
	public static final int EPOCH = Julian.toFixed(MARCH, 19, Julian.CE(622));
	
	//
	// date conversion methods
	//
	
		/*-
		(defun fixed-from-persian (p-date)
		  ;; TYPE persian-date -> fixed-date
		  ;; Fixed date equivalent to Persian date.
		  (let* ((day (standard-day p-date))
		         (month (standard-month p-date))
		         (p-year (standard-year p-date))
		         (y ; Years since start of 2820-year cycle
		          (if (< 0 p-year)
		              (- p-year 474)
		            (- p-year 473))); No year zero
		         (year ; Equivalent year in the range 474...3263
		          (+ (mod y 2820) 474)))
		    (+ (1- persian-epoch); Days before epoch
		       ( * 1029983        ; Days in 2820-year cycles
		                         ; before Persian year 474
		          (quotient y 2820))
		       ( * 365 (1- year)) ; Nonleap days in prior years this
		                         ; 2820-year cycle
		       (quotient         ; Leap days in prior years this
		                         ; 2820-year cycle
		        (- ( * 682 year) 110) 2816)
		       (if (<= month 7)  ; Days in prior months this year
		           ( * 31 (1- month))
		         (+ ( * 30 (1- month)) 6))
		       day)))            ; Days so far this month
		-*/
	public static int toFixed(int month, int day, int pYear) {
		int y = 0 < pYear ? pYear - 474 : pYear - 473;
		int year = mod(y, 2820) + 474;
		return EPOCH - 1
			+ 1029983 * quotient(y, 2820)
			+ 365 * (year - 1)
			+ quotient(682 * year - 110, 2816)
			+ (month <= 7 ? 31 * (month - 1) : 30 * (month - 1) + 6)
			+ day;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
		/*-
		(defun persian-from-fixed (date)
		  ;; TYPE fixed-date -> persian-date
		  ;; Persian (month day year) corresponding to fixed date.
		  (let* ((year (persian-year-from-fixed date))
		         (day-of-year (1+ (- date
		                             (fixed-from-persian
		                              (persian-date 1 1 year)))))
		         (month (if (<= day-of-year 186)
		                    (ceiling (/ day-of-year 31))
		                  (ceiling (/ (- day-of-year 6) 30))))
		         (day           ; Calculate the day by subtraction
		          (- date (1- (fixed-from-persian
		                       (persian-date month 1 year))))))
		    (persian-date month day year)))
		-*/
	public void fromFixed(int date) {
		year = yearFromFixed(date);
		int dayOfYear = 1 + date - toFixed(1, 1, year);
		month = (int)(dayOfYear < 186 ? Math.ceil(dayOfYear / 31d) : Math.ceil((dayOfYear - 6) / 30d));
		day = date - (toFixed(month, 1, year) - 1);
	}
	
	//
	// support methods
	//

		/*-
		(defun persian-leap-year? (p-year)
		  ;; TYPE persian-year -> boolean
		  ;; True if year is a leap year on the Persian calendar.
		  (let* ((y ; Years since start of 2820-year cycles
		          (if (< 0 p-year)
		              (- p-year 474)
		            (- p-year 473))); No year zero
		         (year ; Equivalent year in the range 474...3263
		          (+ (mod y 2820) 474)))
		    (< (mod ( * (+ year 38)
		               682)
		            2816)
		       682)))
		-*/
	public static boolean isLeapYear(int pYear) {
		int y = 0 < pYear ? pYear - 474 : pYear - 473;
		int year = mod(y, 2820) + 474;
		return mod((year + 38) * 682, 2816) < 682;
	}

		/*-
		(defun persian-year-from-fixed (date)
		  ;; TYPE fixed-date -> persian-year
		  ;; Persian year corresponding to the fixed date.
		  (let* ((d0      ; Prior days since start of 2820-year cycle
		                  ; beginning in Persian year 474
		          (- date (fixed-from-persian
		                   (persian-date 1 1 475))))
		         (n2820   ; Completed prior 2820-year cycles
		          (quotient d0 1029983))
		         (d1      ; Prior days not in n2820--that is, days
		                  ; since start of last 2820-year cycle
		          (mod d0 1029983))
		         (y2820 ; Years since start of last 2820-year cycle
		          (if (= d1 1029982)
		              ;; Last day of 2820-year cycle
		              2820
		            ;; Otherwise use cycle of years formula
		            (quotient (+ ( * 2816 d1) 1031337)
		                      1028522)
		            ;; If ( * 2816 d1) causes integers that are
		            ;; too-large, use instead:
		            ;; (let ((a (floor d1 366))
		            ;;       (b (mod d1 366)))
		            ;;  (+ 1 a (quotient
		            ;;          (+ ( * 2134 a) ( * 2816 b) 2815)
		            ;;          1028522)))
		            ))
		         (year    ; Years since Persian epoch
		          (+ 474     ; Years before start of 2820-year cycles
		             ( * 2820 n2820) ; Years in prior 2820-year cycles
		             y2820))); Years since start of last 2820-year
		                     ; cycle
		    (if (< 0 year)
		        year
		      (1- year)))); No year zero
		-*/
	public static int yearFromFixed(int date) {
		int d0 = date - toFixed(1, 1, 475);
		int n2820 = quotient(d0, 1029983);
		int d1 = mod(d0, 1029983);
		int y2820 = d1 == 1029982 ? 2820 : quotient(2816d * d1 + 1031337, 1028522);
		int year = 474 + 2820 * n2820 + y2820;
		return 0 < year ? year : year - 1;
	}
	
	//
	// auxiliary methods
	//

		/*-
		(defun naw-ruz (g-year)
		  ;; TYPE gregorian-year -> fixed-date
		  ;; Fixed date of Persian New Year (Naw-Ruz) in Gregorian
		  ;; year.
		  (let* ((persian-year
		          (1+ (- g-year
		                 (gregorian-year-from-fixed
		                  persian-epoch)))))
		    (fixed-from-persian
		     (persian-date 1 1 (if (<= persian-year 0)
		                           ;; No Persian year 0
		                           (1- persian-year)
		                         persian-year)))))
		-*/
	public static int nawRuz(int gYear) {
		int pYear = 1 + gYear - Gregorian.yearFromFixed(EPOCH);
		return toFixed(1, 1, pYear <= 0 ? pYear - 1 : pYear);
	}
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Persian))
			return false;
		
		return internalEquals(obj);
	}
}
