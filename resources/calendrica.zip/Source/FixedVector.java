package calendrica;

import java.util.Vector;


public class FixedVector extends Vector {
	//
	// constructors
	//
	
	public FixedVector(int initialCapacity, int capacityIncrement) {
		super(initialCapacity, capacityIncrement);
	}
	
	public FixedVector(int initialCapacity) {
		super(initialCapacity);
	}
	
	public FixedVector() { }
	
	public final synchronized void addFixed(int fixed) {
		super.addElement(new Integer(fixed));
	}
	
	public final synchronized int fixedAt(int index) {
		return ((Integer)super.elementAt(index)).intValue();
	}
}
