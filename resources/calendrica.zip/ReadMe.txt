Calendrica Java 1.0

********************************************************************************

CHANGE HISTORY

1.0 2/25/98
Only implementation of of the Cloneable interface was necessary.
providing an actual clone() routine was unnecessary and has been removed.

1.0b1 10/15/97
First test release.

********************************************************************************

GENERAL INFORMATION

Calendrica is a package for generalized manipulation and conversion of
dates through various modern and historical calendars. It is based on
the work of Nachum Dershowitz and Edward M. Reingold in their book
_Calendrical Calculations_, published by Cambridge University Press,
ISBN 0-521-56474-3. This Java translation was performed by Robert C.
McNally <ironwolf@dangerousgames.com>.

;;;; The Functions (code, comments, and definitions) contained in these
;;;; files (the "Program") were written by Nachum Dershowitz and Edward
;;;; M. Reingold (the "Authors"), who retain all rights to them except
;;;; as granted in the License and subject to the warranty and
;;;; liability limitations below.  These Functions are explained in
;;;; the Authors' book, "Calendrical Calculations" (Cambridge
;;;; University Press, 1997), and are subject to an international
;;;; copyright and a Patent Pending on certain functions.  
;;;;
;;;; The Authors' public service intent is more liberal than suggested
;;;; by the License below, as are their licensing policies for
;;;; otherwise nonallowed uses such as--without limitation--those in
;;;; commercial, web-site, and large-scale academic contexts.  Please
;;;; see the web-site
;;;; 
;;;;     http://emr.cs.uiuc.edu/~reingold/calendar-book/index.html
;;;; 
;;;; for all uses not authorized below; in case there is cause
;;;; for doubt about whether a use you contemplate is authorized,
;;;; please contact the Authors (e-mail: reingold@cs.uiuc.edu).
;;;; For commercial licensing information, contact the authors at
;;;; the Department of Computer Science, 1304 West Springfield
;;;; Avenue, University of Illinois at Urbana-Champaign, Urbana,
;;;; IL 61801-2987, USA.
;;;; 
;;;; 1. LICENSE.  The Authors grant you a license for personal
;;;; use only.  This means that for strictly personal use you may
;;;; copy and use the code, and keep a backup or archival copy
;;;; also.  Any other uses, including without limitation,
;;;; allowing the code or its output to be accessed, used, or
;;;; available to others, is not permitted.  
;;;;
;;;; 2. WARRANTY.
;;;; 
;;;; (a) THE AUTHORS PROVIDE NO WARRANTIES OF ANY KIND, EITHER
;;;;     EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITING THE
;;;;     GENERALITY OF THE FOREGOING, ANY IMPLIED WARRANTY OF
;;;;     MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
;;;; 
;;;; (b) THE AUTHORS SHALL NOT BE LIABLE TO YOU OR ANY THIRD PARTIES
;;;;     FOR DAMAGES OF ANY KIND, INCLUDING WITHOUT LIMITATION, ANY LOST
;;;;     PROFITS, LOST SAVINGS, OR ANY OTHER INCIDENTAL OR CONSEQUENTIAL
;;;;     DAMAGES ARISING OUT OF OR RELATED TO THE USE, INABILITY TO USE,
;;;;     OR INACCURACY OF CALCULATIONS, OF THE CODE AND FUNCTIONS
;;;;     CONTAINED HEREIN, OR THE BREACH OF ANY EXPRESS OR IMPLIED
;;;;     WARRANTY, EVEN IF THE AUTHORS OR PUBLISHER HAVE BEEN ADVISED OF
;;;;     THE POSSIBILITY OF THOSE DAMAGES.
;;;; 
;;;;   (c) The foregoing warranty may give you specific legal
;;;;   rights which may vary from state to state in the U.S.A.
;;;; 
;;;; 3. LIMITATION OF LICENSEE REMEDIES.  You acknowledge and
;;;; agree that your exclusive remedy (in law or in equity), and
;;;; Authors' entire liability with respect to
;;;; the material herein, for any breach of representation or for
;;;; any inaccuracy shall be a refund of the license fee or service 
;;;; and handling charge which you paid the Authors, if any. 
;;;; 
;;;; SOME STATES IN THE U.S.A. DO NOT ALLOW THE EXCLUSION OR
;;;; LIMITATION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES,
;;;; SO THE ABOVE EXCLUSIONS OR LIMITATION MAY NOT APPLY TO YOU.

;;;; 4. DISCLAIMER.  Except as expressly set forth above, the Authors:
;;;; 
;;;;   (a) make no other warranties with respect to the material in
;;;;   the Program and expressly disclaim any others;
;;;; 
;;;;   (b) do not warrant that the material contained in the Program
;;;;   will meet your requirements or that their operation shall be
;;;;   uninterrupted or error-free;
;;;; 
;;;;   (c) license this material on an "as is" basis, and the entire
;;;;   risk as to the quality, accuracy, and performance of the
;;;;   Program is yours, should the code prove defective (except as
;;;;   expressly warranted herein).  You alone assume the entire cost
;;;;   of all necessary corrections.
;;;; 
;;;; Sample values for the functions (useful for debugging) are
;;;; given in Appendix C of the book.  These sample values are
;;;; not available electronically.

********************************************************************************

JAVA IMPLEMENTATION

This implmentation requires Java 1.1 or later.

********************************************************************************

ORGANIZATION

Inheritance Hierarchy

java.lang.Object
	Time
	ProtoDate
		MayanHaab
		MayanTzolkin
		Date
			Bahai
			Chinese
			HinduLunar
			ISO
			MayanLongCount
			OldHinduLunar
			StandardDate
				Coptic
				Ethiopic
				French
				Gregorian
				Hebrew
				HinduSolar
				Islamic
				Julian
				ModifiedFrench
				OldHinduSolar
				Persian

--------------------------------------------------------------------------------

Calendar Classes

Each supported calendar has it's own class which encapsulates behavior
standard among all the calendar classes, as well as behavior specific to
the given calendar class.

All calendar classes are descended from the abstract class ProtoDate,
which encapsulates a large number of constants and general utility
routines relied on by many of the calendars. The only date conversion
behavior specified by ProtoDate which subclasses must implement is that
which converts fixed dates (R.D.) to the calendar instance fields. The
calendars MayanHaab and MayanTzolkin, which have no ability to convert
from their instance fields to a single fixed date, inherit directly from
ProtoDate.

The primary abstract subclass of ProtoDate is Date, which additionally
specifies that subclasses must implement behavior to convert from the
calendar's instance fields to a specific fixed date. Calendars such as
Bahai and Chinese which do not use the standard month, day, year format
inherit directly from Date. All the other calendars such as Gregorian
and Hebrew which do use the standard month, day, year format inherit
from the abstract subclass of Date StandardDate, which defines these
fields and the other non-calendar-specific behaviors which operate on
them.

NOTE: Because the class calendrica.Date has the same base name as
java.util.Date, classes in Java source files which import both
java.util.Date and calendrica.Date need to fully qualify those names
when referring to them.

--------------------------------------------------------------------------------

Member Visibility

All class members are declared public unless there is a specific reason
to make them protected or private. The only place protected visibility
is used is in the abstract classes described above. The only place
private visibility is used is for inner classes containing static final
arrays used only by specific utility routines.

--------------------------------------------------------------------------------

Instance Fields

Each calendar class encapsulates the instance fields used by a date of
that calendar. For example, the Gregorian calendar is supported by the
class Gregorian, and encapsulates the instance fields month, day and
year which it inherits from StandardDate. As another example, the class
Chinese encapsulates the instance fields cycle, year, month, leap and
day of the Chinese calendar. The instance fields of a calendar class are
declared public, and may be accessed and manipulated directly.

Each calendar class is used 1) for storing the fields of a date on the
given calendar, 2) to encapsulate the standard behavior needed to
convert from fixed dates to those fields and back (if applicable), and
3) to encapsulate methods related to the computation of holidays on that
calendar. There is no instance field to hold the fixed (R.D.) date
corresponding to the other fields-- this information is calculated on
demand with other methods (see below).

--------------------------------------------------------------------------------

Naming Conventions

When converting from the original Lisp, I followed the following naming
transformation guidelines:

1) Lisp function names such as daylight-savings-start were changed to
use the Java convention of intercapitalization with the first letter in
lower case, e.g., daylightSavingsStart, except for very short names
consisting of initials such as BCE, which remain unchanged.

2) Predicates such as short-kislev? are renamed using the Java
convention of prefixing the name with "is" or "has", e.g.,
hasShortKislev.

3) Constants such as arya-jovian-period are renamed using the Java
convention of all capitals with underscores for spaces, e.g.
ARYA_JOVIAN_PERIOD.

4) In general, wherever a name includes the name of the calendar it
deals with, such as bahai-epoch, and where that item is declared in the
class of the same name, the calendar-specific part of the name is
dropped. Thus, most of the calendar classes have a constant named EPOCH,
which is the epoch of that calendar, and which may be referred to by
clients and other calendars by its fully-qualified name, e.g.,
Bahai.EPOCH. Another example is the function name sunrise, which is
declared in ProtoDate, and also in HinduSolar, where in Lisp it was
called hindu-sunrise. Thus, wherever the unqualified method name sunrise
is called from within the HinduSolar class, it refers to the function
HinduSolar.sunrise(). Other classes which call sunrise() refer to
ProtoDate.sunrise().

--------------------------------------------------------------------------------

Constants

Each class may define one or more constants. A few of the more useful
constants to clients are found in ProtoDate, and include SUNDAY through
SATURDAY and JANUARY through DECEMBER. Clients can refer to them as
(e.g.) ProtoDate.SUNDAY or Date.SUNDAY, since Date inherits from
ProtoDate.

--------------------------------------------------------------------------------

Constructors

Each concrete calendar class contains four constructors:

1) a default constructor which initializes each instance field to zero
(or false),

2) a constructor which takes a fixed (R.D.) date and which initializes
the instance fields with the values corresponding to that fixed date,

3) a constructor which takes any object of class calendrica.Date (see
below), converts it to a fixed date, and then initializes the instance
fields with the values corresponding to that fixed date, and

4) a constructor which takes individual parameters corresponding to the
instance fields, and assigns those parameters directly to the instance
fields.

--------------------------------------------------------------------------------

Date Conversion Methods

All subclasses of ProtoDate support several instance methods whose names
begin with "from". These are fromFixed(), fromDate() and fromArray().

fromFixed() takes a fixed date, converts it into the calendar's format,
and assigns the result to the target object's fields.

fromDate() takes any subclass of Date, converts it to a fixed date and
then into the calendar's format, and assigns the result to the target
object's fields.

fromArray() initializes the target object's fields from the values in a
provided int[]. There must be one item in the array for each instance
field in the class, and the instance fields are initialized from the
array starting at element zero, in the same order they appear in the
class declaration. Classes which use boolean fields take zero to mean
false and any other value to mean true. Extra elements of the array are
ignored.

ProtoDate also defines the static method convert(), which converts any
given subclass of Date to any given subclass of ProtoDate.

All subclasses of Date also support two versions of the method
toFixed(), a static one which takes as its arguments the values of the
fields for it's calendar format, and which returns the corresponding
fixed date, and an instance version which uses the fields in the target
object from which to compute the fixed date.

Date also defines the instance function convertTo(), which converts the
target object to any given subclass of ProtoDate.

--------------------------------------------------------------------------------

Support Methods

Each calendar class may define one or more "support" methods, which
directly support the conversion between calendar dates and fixed dates.
These are declared public as they may be of use to clients in their own
right, especially those defined by ProtoDate, and include (for example)
methods for calculating the number of days between dates, mathematical
functions, and functions dealing with time and astronomy.

--------------------------------------------------------------------------------

Auxiliary Methods

Each calendar class may define one or more "auxiliary" methods, which do
not directly support date conversion, but which provide examples of how
holidays pertinant to that calendar may be computed.

--------------------------------------------------------------------------------

Object Methods

Each calendar class provides certain object methods which support
standard Java idioms. These include toString(), and equals(). In
addition, all calendar classes implement the Cloneable and Serializable
interfaces.

--------------------------------------------------------------------------------

Exceptions

Calendrica defines one exception class: BogusDateException. This class
may be thrown by any routine which declares it. Currently however, only
the following routines directly throw BogusDateException:

Hebrew.omer()
MayanTzolkin.haabTzolkinOnOrBefore()
HinduLunar.toFixed()
HinduSolar.toFixed()

Because toFixed() is inherited from the abstract Date class, Date
declares that toFixed() may throw BogusDateException.

Since the standard constructor which takes a Date as its argument
indirectly calls toFixed(), it declares it may throw BogusDateException.

Any constructors or other methods that directly or indirectly may call
the versions of toFixed that may throw BogusDateException declare that
they may throw BogusDateException.

--------------------------------------------------------------------------------

class Time

Time encapsulates the fields hour, minute, and second, and the behavior
needed to convert between these fields and a fixed fraction of a day.

--------------------------------------------------------------------------------

class FixedVector

Methods which return a list of zero or more fixed dates do so by
returning a FixedVector, which is a subclass of java.util.Vector with
two additional methods: addFixed(), which adds a fixed date element to
the vector, and fixedAt(), which retrieves the fixed date in the vector
at the given index.

--------------------------------------------------------------------------------

Source Files

The source files for the Calendrica package include:

BogusDateException.java
FixedVector.java
Time.java
ProtoDate.java
Date.java
StandardDate.java
Gregorian.java
ISO.java
Julian.java
Coptic.java
Ethiopic.java
Islamic.java
Bahai.java
Persian.java
Hebrew.java
MayanLongCount.java
MayanHaab.java
MayanTzolkin.java
OldHinduSolar.java
OldHinduLunar.java
French.java
ModifiedFrench.java
Chinese.java
HinduSolar.java
HinduLunar.java


********************************************************************************

CALENDAR CLASS TEMPLATES

--------------------------------------------------------------------------------

The following class template is used for calendars whose fields have the
form month, day, year.

--------------------------------------------------------------------------------
package calendrica;


public class Cal extends StandardDate {

	//
	// constructors
	//

	public Cal() { }
	
	public Cal(int date) {
		super(date);
	}
	
	public Cal(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Cal(int month, int day, int year) {
		super(month, day, year);
	}
	
	//
	// constants
	//
	
	//
	// date conversion methods
	//
	
	public static int toFixed(int month, int day, int year) {
		return 0;
	}

	public int toFixed() {
		return toFixed(month, day, year);
	}
	
	public void fromFixed(int date) {
		month = 0;
		day = 0;
		year = 0;
	}
	
	//
	// support methods
	//
	
	//
	// auxiliary methods
	//
	
	//
	// object methods
	//
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Cal))
			return false;
		
		return internalEquals(obj);
	}
}
--------------------------------------------------------------------------------

The following class template is used for calendars whose fields have a
non-standard arrangement.

--------------------------------------------------------------------------------
package calendrica;


public class Cal extends Date {
	
	//
	// fields
	//

	public int a;
	public int b;
	public int c;

	//
	// constructors
	//

	public Cal() { }
	
	public Cal(int date) {
		super(date);
	}
	
	public Cal(Date date)
		throws BogusDateException
	{
		super(date);
	}
	
	public Cal(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}
	
	//
	// constants
	//
	
	//
	// date conversion methods
	//
	
	public static int toFixed(int a, int b, int c) {
		return 0;
	}

	public int toFixed() {
		return toFixed(a, b, c);
	}
	
	public void fromFixed(int date) {
		a = 0;
		b = 0;
		c = 0;
	}
	
	public void fromArray(int[] a) {
		this.a	= a[0];
		this.b	= a[1];
		this.c	= a[2];
	}
	
	//
	// support methods
	//
	
	//
	// auxiliary methods
	//
	
	//
	// object methods
	//

	protected String toStringFields() {
		return "a=" + a + ",b=" + b + ",c=" + c;
	}
	
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		
		if(!(obj instanceof Cal))
			return false;
		
		Cal o = (Cal)obj;
		
		return
			o.a	== a		&&
			o.b	== b		&&
			o.c	== c		;
	}
}
--------------------------------------------------------------------------------
